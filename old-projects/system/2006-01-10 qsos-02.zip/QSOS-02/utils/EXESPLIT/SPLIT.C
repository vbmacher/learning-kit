/*
 * Extended Operating System Loader (XOSL)
 * Copyright (c) 1999 by Geurt Vos
 *
 * This code is distributed under GNU General Public License (GPL)
 *
 * The full text of the license can be found in the GPL.TXT file,
 * or at http://www.gnu.org
 */

#include <io.h>
#include <exestruc.h>

void WriteHeader(int ifh);
void WriteData(int ifh);

static const char *SrcFile = "qss.exe";
static char *DestFile = "qss.sys";

static char Buffer[32768];

void main()
{
	int ifh;
	TExeHeader ExeHeader;

	ifh = open(SrcFile,O_RDWR);
	if (ifh == -1) return;
	WriteHeader(ifh);
	WriteData(ifh);
	close(ifh);

}

void WriteHeader(int ifh)
{
	TExeHeader ExeHeader;
	unsigned short Count;

	read(ifh, &ExeHeader, sizeof(TExeHeader));

	Count = ExeHeader.HeaderSize * 16 - sizeof (TExeHeader);
	read(ifh,Buffer,Count);
}

void WriteData(int ifh)
{
	unsigned short Bytes;
	int ofh;

	while ((Bytes = read(ifh,Buffer,32768)) != 0) {
		ofh = creat(DestFile);
		write(ofh,Buffer,Bytes);
		close(ofh);
		++DestFile[6];
	}
}
