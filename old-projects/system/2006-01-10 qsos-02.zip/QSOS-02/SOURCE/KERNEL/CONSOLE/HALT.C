/*
 * HALT.C
 *
 * (c) Copyright 2005, vbmacher
 *
 */

#include <rtl.h>

// zastavi system
void commandHALT()
{
  halt();
}

