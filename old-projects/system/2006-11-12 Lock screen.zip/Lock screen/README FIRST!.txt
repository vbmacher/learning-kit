Before running the exe you must remember the password that is "pass1"
 followed by enter or just type in:
"disactivate access termination"

