function mvSurveyInvite() {
	var userAgent = navigator.appName + " " + navigator.appVersion;
	var notFound  = -1;
	userAgent     = userAgent.toUpperCase();

	if (userAgent.indexOf("WEBTV") == notFound && userAgent.indexOf("OPERA") == notFound)
	{
		if (!anet && isSelected())
		{
			return true;
		}
	}
	return false;
}

function showInvitation() {
	var theURL  = "https://esurvey.advanis.ca/applecare2/index.php?ep=";
	
	theURL = theURL + escape(location.href) + "&";
	
	var acid = readCookie('ACID');
	if (acid) {
	    theURL = theURL + "dsid=" + escape(encode(parser(acid, "~", 0))) + "&";
	}
	
	var chatexit = readCookie('chatexit');
	if (chatexit) {
	    var snVal = parser(chatexit, "%20%3A%20", 6);
	    snVal = parser(snVal, "%0A", 0);
	    theURL = theURL + "sn=" + escape(encode(snVal));
    }
	
	
	
	var winName = "invite";
	var winDesc = "toolbar=no,menubar=no,resizable=yes,scrollbars=1,top=0,left=0,width=770,height=675";
	var newWin  = open(theURL, winName, winDesc);
	window.focus(); 
}

function isSelected() {
	var mvCookieName  = "mv";
	var mvInviteGiven = "1";
	var mvCookieValue = getCookie(mvCookieName);

	if (mvCookieValue != mvInviteGiven)
	{
        var randVal = parseInt( (Math.random() * 50) + 1 );
		if (randVal == 2)
		{
			var expDate     = new Date();
			var threeMonths = 7 * 24 * 60 * 60 * 1000 * 14;
			expDate.setTime(expDate.getTime() + threeMonths);
			setCookie(mvCookieName, mvInviteGiven, expDate, "/", "apple.com");
			return true;
		}
	}

	return false;
}


function getCookie(name) {
	var result        = null;
	var myCookie      = " " + document.cookie + ";";
	var searchName    = " " + name + "=";
	var startOfCookie = myCookie.indexOf(searchName);
	var endOfCookie;

	if (startOfCookie != -1)
	{
		startOfCookie += searchName.length;
		endOfCookie    = myCookie.indexOf(";", startOfCookie);
		result         = unescape( myCookie.substring(startOfCookie, endOfCookie) );
	}

	return result;
}

function setCookie(name, value, expires, path, domain) {
	var expStr    = ( (expires == null) ? "" : ("; expires=" + expires.toGMTString()) );
	var pathStr   = ( (path    == null) ? "" : ("; path="    + path) );
	var domainStr = ( (domain  == null) ? "" : ("; domain="  + domain) );

	document.cookie = name + "=" + escape(value) + expStr + pathStr + domainStr;
}

function yes() {
    document.getElementById('surveytext').innerHTML="Thank you. The survey is available under your current browser window. Please wait until after you have completed your visit to take the survey.";
    document.getElementById('surveybuttons').innerHTML="<a href='javascript:closeit();' style='background: url(http://images.apple.com/support/images/survey_close.gif) left top no-repeat; display: block; padding-left: 13px;text-align:left; font-size:10px; color:#c7650c; text-decoration: underline;'>Close</a>";

    showInvitation();
}

function closeit() {
    document.getElementById('survey').style.visibility="hidden";
    document.getElementById('survey').style.display="none";
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

function parser(fullString, token, elementNum) {
    var fullArray = fullString.split(token);
    
    return fullArray[elementNum];
}


var keyStr = "ABCDEFGHIJKLMNOP" +
            "QRSTUVWXYZabcdef" +
            "ghijklmnopqrstuv" +
            "wxyz0123456789+/" +
            "=";

function encode(input) {
  var output = "";
  var chr1, chr2, chr3 = "";
  var enc1, enc2, enc3, enc4 = "";
  var i = 0;

  do {
     chr1 = input.charCodeAt(i++);
     chr2 = input.charCodeAt(i++);
     chr3 = input.charCodeAt(i++);

     enc1 = chr1 >> 2;
     enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
     enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
     enc4 = chr3 & 63;

     if (isNaN(chr2)) {
        enc3 = enc4 = 64;
     } else if (isNaN(chr3)) {
        enc4 = 64;
     }

     output = output + 
        keyStr.charAt(enc1) + 
        keyStr.charAt(enc2) + 
        keyStr.charAt(enc3) + 
        keyStr.charAt(enc4);
     chr1 = chr2 = chr3 = "";
     enc1 = enc2 = enc3 = enc4 = "";
  } while (i < input.length);

  return output;
}
