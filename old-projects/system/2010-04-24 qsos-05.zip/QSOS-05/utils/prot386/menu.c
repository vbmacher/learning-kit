// Prot386 Main menu
// (C) 2006-2007 Peter Ambroz
// This code is free software and is distributed under the terms of GNU GPL

#include "prototypes.h"

char *main_up = "Prot386 v2.1";
char *main_down = " \x18\x19 = Navigate in menu, <ENTER> = Action, <ESC> = Back \0!UNPROTECTED!";

char menu_s0[] = {"Menu\nSegmentation\nPage Directory\nTask State Segments\nExecute Code\nHex Editor\nInterrupt Handlers\nOther\n Exit & Reboot"};
char menu_s1[] = {"Other\nHEX <-> Decimal convert\nMemory mapping convert\nCPUID\nSystem Info\nData Protection\nCredits\nBack"};

int menu_old0, menu_old1;
int exec_old0;

int menu_x = 33, menu_y = 3;

extern int pos_y;
void key_test(void) {
  gotoxy(0,0);
  while (1) {
    write(inttostr(readkey(), "     "));
    write("    ");
    gotoxy(0,(pos_y > 23)?0:pos_y+1);
  }
}

void other_menu(void) {
  do {
    save_screen();
    switch (menu_old1=menu(menu_x,60,menu_y,0,112,menu_old1,0,AL_LEFT,menu_s1, 0)) {
      case 1: converter(); break;
      case 2: mapping(); break;
      case 3: cpuid_any(); break;
      case 4: okno_cpuinfo(); break;
      case 5: data_protect(); load_screen(); return;
      case 6: credits(); break;
      case 7:
      case -1: load_screen(); return;
    }
    load_screen();
  } while (1);
  return;
}

void app_main(void)
{
  use_eol = 0;
  menu_left_right = 0;
  menu_old0 = 1;
  init_menus();
  do {
    poz(main_up,main_down);
    switch(menu_old0=menu(7,menu_x-1,menu_y,0,112,menu_old0,1,AL_CENTER,menu_s0, NULL)) {
      case 1: descriptor_menu(); break;
      case 2: pagedir_menu(); break;
      case 3: ts_menu(); break;
      case 4: exec_old0=1; execute(); break;
      case 5: hexeditor_menu(); break;
      case 6: idescriptors(); break;
      case 7: menu_old1=1; other_menu(); break;
      case 8: rm_reboot(); break;
      case -1: return;
    }
  } while (1);
  return;
}
