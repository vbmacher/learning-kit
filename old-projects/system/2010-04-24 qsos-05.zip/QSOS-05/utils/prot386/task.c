// Prot386 Task State Segment manipulation
// (C) 2008-2009 Peter Ambroz
// This code is free software and is distributed under the terms of GNU GPL

#include "prototypes.h"

char ts_s0[450];
char ts_s1[256];
char ts_s2[128];
char ts_info[200];
char ts_regs[630];

char *ts_nl = "\n";
char *ts_pad = "    ";

int ts_old0;
int ts_old1 = 1;
int ts_old2;

int ts_cnt;

typedef struct s_tsetup {
  int enable;
  E_TYPE outer_type;   // CALL or JMP at first dispatch of this TSS
  int outer_rpl;       // RPL field of dispatched selector
  E_TYPE inner_type;   // CALL or JMP to the next TSS (see bellow)
  int next_selector;  // Selector (index, table, rpl) of TSS or task gate to call when inside task
  int this_gdt_index; // self-reference
} TS_SETUP;

#define TSS_MAX 16
TS_SETUP ts_setups[TSS_MAX];
DESCRIPTOR ts_dtmp;

// exec.c
extern char *e_types[];

// descriptor.c
extern char *dt0[];
extern char *dlg0;

// hex.c
extern int ed_seg3(void);

void dummy_task(void);

int ed_tseg2(void) {
  int val;
  val = menu_ex(3, 40, 7, 8, 48, NULL, 256, dt0[0], summary, NULL);
  if (val == -1) return 0;
  return val<<3;
}

void field_init(int index) {
  ts_setups[index].enable = 0;
  ts_setups[index].outer_type = E_CALL;
  ts_setups[index].outer_rpl = 0;
  ts_setups[index].inner_type = E_CALL;
  ts_setups[index].next_selector = 0x28;
  ts_setups[index].this_gdt_index = 0;
}

void task_setup(void) {
  int i;
  for (i=0; i<TSS_MAX; i++) field_init(i);
}

int enum_tss(char *data) {
  int i, cnt=0;
  char tmps[11];

  data[0] = '\0';
  strcat(data, "TSS descriptors\n", 0);

  for (i=1; i<249; i++) {
    load_descriptor(i, TB_GDT, &ts_dtmp);
    if (is_tss(&ts_dtmp)) {
      strcat(data, inttostr(i, tmps), ": ", 0);
      strcat(data, hextostr(ts_dtmp.base, tmps), ", ", 0);
      strcat(data, get_tss_state(&ts_dtmp), ts_nl, 0);
      if (ts_setups[cnt].this_gdt_index != i) field_init(cnt);
      if (i > gdt_protect)
	tss_reinit(i<<3, cnt, (void *)dummy_task);
      ts_setups[cnt++].this_gdt_index = i;
    }
    if (cnt == TSS_MAX) break;
  }
  strcat(data, "Back", 0);
  return cnt;
}

unsigned int *parse_tss(int sel, char *info) {
  char tmps[25];
  unsigned int *tss_ptr;

  info[0] = '\0';
  load_descriptor(sel, TB_GDT, &ts_dtmp);
  if (!is_tss(&ts_dtmp)) return NULL;
  tss_ptr = (unsigned int *)ts_dtmp.base;

  strcat(info, "TSS data - ", descriptor_name(sel<<3), ts_nl, 0);
  strcat(info, "Status: ", get_tss_state(&ts_dtmp), ts_nl, 0);
  strcat(info, "Task link: ", selector_show(tss_ptr[0], tmps, 0), ts_nl, 0);
  strcat(info, "LDT: ", selector_show(tss_ptr[24], tmps, 0), ts_nl, 0);
  strcat(info, "Trap: ", (tss_ptr[25] & 1)?"Enabled":"Disabled", ts_nl, 0);
  strcat(info, "I/O map at ", hextostr(tss_ptr[25] >> 16, tmps), ts_nl, 0);
  strcat(info, "Setup..\nDispatch", 0);
  return tss_ptr;
}

void parse_tss_regs(unsigned int *tss_ptr, char *regs) {
  char tmps[25];
  regs[0] = '\0';

  strcat(regs, " Segment registers\n", 0);
  strcat(regs, "CS: ", selector_show(tss_ptr[19], tmps, 15), 0);
  strcat(regs, " | SS: ", selector_show(tss_ptr[20], tmps, 15), ts_nl, 0);
  strcat(regs, "DS: ", selector_show(tss_ptr[21], tmps, 15), 0);
  strcat(regs, " | ES: ", selector_show(tss_ptr[18], tmps, 15), ts_nl, 0);
  strcat(regs, "FS: ", selector_show(tss_ptr[22], tmps, 15), 0);
  strcat(regs, " | GS: ", selector_show(tss_ptr[23], tmps, 15), ts_nl, 0);
  no0x=1;
  strcat(regs, " General purpose registers\n", 0);
  strcat(regs, "EAX: 0x", pad_right(8, hextostr(tss_ptr[10], tmps), '0'), ts_pad, 0);
  strcat(regs, " | ESP: 0x", pad_right(8, hextostr(tss_ptr[14], tmps), '0'), ts_nl, 0);
  strcat(regs, "EBX: 0x", pad_right(8, hextostr(tss_ptr[13], tmps), '0'), ts_pad, 0);
  strcat(regs, " | EBP: 0x", pad_right(8, hextostr(tss_ptr[15], tmps), '0'), ts_nl, 0);
  strcat(regs, "ECX: 0x", pad_right(8, hextostr(tss_ptr[11], tmps), '0'), ts_pad, 0);
  strcat(regs, " | ESI: 0x", pad_right(8, hextostr(tss_ptr[16], tmps), '0'), ts_nl, 0);
  strcat(regs, "EDX: 0x", pad_right(8, hextostr(tss_ptr[12], tmps), '0'), ts_pad, 0);
  strcat(regs, " | EDI: 0x", pad_right(8, hextostr(tss_ptr[17], tmps), '0'), ts_nl, 0);
  strcat(regs, " Stack pointers\n", 0);
  strcat(regs, "SS0: 0x", selector_show(tss_ptr[2], tmps, 13), 0);
  strcat(regs, "| ESP0: 0x", pad_right(8, hextostr(tss_ptr[1], tmps), '0'), ts_nl, 0);
  strcat(regs, "SS1: 0x", selector_show(tss_ptr[4], tmps, 13), 0);
  strcat(regs, "| ESP1: 0x", pad_right(8, hextostr(tss_ptr[3], tmps), '0'), ts_nl, 0);
  strcat(regs, "SS2: 0x", selector_show(tss_ptr[6], tmps, 13), 0);
  strcat(regs, "| ESP2: 0x", pad_right(8, hextostr(tss_ptr[5], tmps), '0'), ts_nl, 0);
  strcat(regs, " System registers\n", 0);
  strcat(regs, "EIP: 0x", pad_right(8, hextostr(tss_ptr[8], tmps), '0'), ts_pad, 0);
  strcat(regs, " | CR3: 0x", pad_right(8, hextostr(tss_ptr[7], tmps), '0'), ts_nl, 0);
  strcat(regs, "EFLAGS: 0x", pad_right(8, hextostr(tss_ptr[9], tmps), '0'), 0);
  no0x=0;
}

void parse_ts_options(int index, char *data) {
  char tmps[11];
  TS_SETUP *stmp;

  stmp = &ts_setups[index];
  data[0] = '\0';
  strcat(data, "Dispatch options\n", 0);
  strcat(data, "Dispatch type: ", e_types[stmp->outer_type], ts_nl, 0);
  strcat(data, "Dispatch with RPL: ", inttostr(stmp->outer_rpl, tmps), ts_nl, 0);
  strcat(data, "Chain tasks: ", stmp->enable?"Enabled":"Disabled", ts_nl, 0);
  if (!stmp->enable) {
    strcat(data, "Back", 0);
    return;
  }
  strcat(data, "Next dispatch type: ", e_types[stmp->inner_type], ts_nl, 0);
  strcat(data, "Next task sel.: ", hextostr(stmp->next_selector, tmps), ",", descriptor_name(stmp->next_selector), ts_nl, 0);
  strcat(data, "Next task RPL: ", inttostr(stmp->next_selector&3, tmps), ts_nl, 0);
  strcat(data, "Back", 0);
}

void ts_options(int index) {
  char temp[11];
  TS_SETUP *stmp;
  int val, end;

  ts_old2 = 1;
  end = 0;
  stmp = &ts_setups[index];
  do {
    save_screen();
    parse_ts_options(index, ts_s1);
    ts_old2 = menu(33,68,3,7,0x70,ts_old2,0,AL_LEFT,ts_s1,NULL);
    switch(ts_old2) {
      case 1: stmp->outer_type^=1; break;
      case 2: /* outer RPL */
	val = DIALOG(2,dlg0);
	if ((val < 0) || (val > 3)) break;
	stmp->outer_rpl = val;
	break;
      case 3: stmp->enable^=1; break;
      case 4: /* inner type or exit */
	if (!stmp->enable) {
	  end=1;
	  break;
	} else {
	  stmp->inner_type^=1;
	  break;
	}
      case 5: /* inner selector */
	val = ed_seg3();
	stmp->next_selector &= 3;
	stmp->next_selector += val;
	break;
      case 6: /* inner RPL */
	val = DIALOG(2,dlg0);
	if ((val < 0) || (val > 3)) break;
	stmp->next_selector &= 0xFFFC;
	stmp->next_selector += val;
	break;
      case 7:
      case -1: end=1; break;
    }
    load_screen();
    if (end) break;
  } while(1);
}

void edit_tss(int index) {
  unsigned int *tss_ptr;
  int sel, tmp, reparse, op;
  TS_SETUP *stmp;

  save_screen();
  poz(0,0);

  menu_left_right = 1;
  reparse = 1;

  do {
    stmp = &ts_setups[index];
    sel = stmp->this_gdt_index;
    tss_ptr = parse_tss(sel, ts_info);
    if (reparse) {
      parse_tss_regs(tss_ptr, ts_regs);
      okno(33,78,3,16,0x1F,"Saved registers",ts_regs);
      reparse = 0;
    }

    ts_old1 = menu(2,32,3,0,0x70,ts_old1,0,AL_LEFT,ts_info,NULL);
    if (ts_old1 == -1) break;
    switch(menu_lr_dir) {
      case 0:
       switch(ts_old1) {
         case 1: /* TSS state */
	   save_screen();
	   load_descriptor(sel, TB_GDT, &ts_dtmp);
	   ts_dtmp.type ^= 2;
	   store_descriptor(&ts_dtmp);
	   load_screen();
	   break;
         case 2: /* Task link */
	   if (enforce_protect && (sel <= gdt_protect)) break;
	   save_screen();
	   tss_ptr[0] = ed_tseg2();
	   load_screen();
	   break;
         case 3: /* LDT */
	   if (enforce_protect && (sel <= gdt_protect)) break;
	   save_screen();
	   tss_ptr[24] = ed_tseg2();
	   load_screen();
	   break;
         case 4: tss_ptr[25]^=1; break;
         case 5: /* IO map */ break;
         case 6: ts_options(index); break;
         case 7: /* Dispatch */
	   if (enforce_protect && (sel <= gdt_protect)) {
	     okno(3, 31, 6, 2, 0x74, 0, "Warning\nProtected TSS\ncan not be dispatched.");
	     _read_enter();
	     break;
	   }
	   tmp = (sel << 3) + (stmp->outer_rpl & 3);
	   op = (stmp->outer_type == E_CALL)?O_CALL:O_JMP;
	   save_screen();
	   tss_call(op, tmp);
	   ts_cnt=enum_tss(ts_s0); // cause reinit of all TSS
	   load_screen();
	   break;
       } break;
      case K_LEFT: if (index>0) index--; else index = ts_cnt-1; reparse = 1; break;
      case K_RIGHT: if (index<ts_cnt-1) index++; else index = 0; reparse = 1; break;
    }
  } while (1);
  menu_left_right = 0;

  load_screen();
}

void ts_menu(void) {
  ts_old0 = 1;
  ts_cnt = enum_tss(ts_s0);
  do {
    ts_old0 = menu(menu_x,65,menu_y,0,0x70,ts_old0,0,AL_LEFT,ts_s0,NULL);
    if (ts_old0 > ts_cnt+1) continue;
    if ((ts_old0 == -1) || (ts_old0 == ts_cnt+1)) break;
    edit_tss(ts_old0 - 1);
  } while (1);
  return;
}

int find_index(int sel) {
  int i,s;
  s=-1;
  sel>>=3;
  for (i=0;i<TSS_MAX;i++)
    if (ts_setups[i].this_gdt_index == sel) {
      s=i;
      break;
    }
  return s;
}

// This function is called as the dispatched task
void dummy_task(void) {
  char tmps[25];
  int atr, index, irt, op;
  DESCRIPTOR dtmp;
  TS_SETUP *stmp;
  unsigned int *tss_ptr;

  poz(0,0);
  ts_s2[0] = '\0';
  atr = load_tr();
  load_descriptor(atr>>3, (atr>>2)&1, &dtmp);
  tss_ptr = (unsigned int *)dtmp.base;
  index = find_index(atr);
  strcat(ts_s2, "Now running TSS: ", selector_show(atr, tmps, 0), ts_nl, 0);
  strcat(ts_s2, "Previous link: ", selector_show(tss_ptr[0], tmps, 0), ts_nl, 0);
  strcat(ts_s2, "Next TSS: ", 0);
  irt=0;
  if (index == -1) irt=1;
  else {
    stmp = &ts_setups[index];
    if (!stmp->enable) irt=1;
    else strcat(ts_s2, e_types[stmp->inner_type], " to ", selector_show(stmp->next_selector, tmps, 0), 0);
  }
  if (irt) strcat(ts_s2, "IRET to previous TSS", 0);
  okno(4,43,6,3,0x3F,"New task launched",ts_s2);
  read_enter();

  // Chain to next TSS if applicable
  if (!irt) {
    op = (stmp->inner_type == E_CALL)?O_CALL:O_JMP;
    tss_call(op, stmp->next_selector);
  }

  __asm__ __volatile__ ("iret");
}
