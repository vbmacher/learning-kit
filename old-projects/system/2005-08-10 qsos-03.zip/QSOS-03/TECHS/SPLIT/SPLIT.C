/*
 * SPLIT.C
 *
 * (c) Copyright 2002, P. Jakubco ml.
 *
 * Program rozdeli subor vacsi ako 65535 bytov na rovnake casti.
 */

#include <io.h>
#include <exestruc.h>

void WriteData(int ifh, TExeHeader &ExeHeader);
void puts(char *str);

static const char *SrcFile = "qsos.exe";
static char *DestFile = "qsos0.sys";

static char Buffer[32768];

void main()
{
	int ifh;
	TExeHeader ExeHeader;

	puts("\n\rAtheros Splitter v1.00\n\r(c) Copyright 2002, P. Jakubco ml.");
	puts("\n\r\n\rSearching for file QSOS.EXE...");

	ifh = open(SrcFile,O_RDWR);
	puts("\n\rWriting...");
	WriteData(ifh, ExeHeader); 
	close(ifh);
	puts("\n\r\n\rDone.");

}

void WriteData(int ifh, TExeHeader &ExeHeader)
{
	unsigned short Bytes;
	int ofh;

        ofh = creat(DestFile);
	read(ifh, Buffer, ExeHeader.HeaderSize*16);
	while ((Bytes = read(ifh,Buffer,32768)) != 0) {
		puts("\n\rCreating new file...");
		ofh = creat(DestFile);
		puts("\n\rWriting data...");
		write(ofh,Buffer,Bytes);
		close(ofh);
		++DestFile[4];
	}
	close(ofh);
}
