/*
 * Project.java
 *
 * Created on 21.5.2008, 11:46:57
 * hold to: KISS, YAGNI
 *
 */

package promemo.data;

import java.sql.Date;
import java.util.Calendar;

/**
 *
 * @author vbmacher
 */
public class Project {
    private int id;
    private String name;
    private String descr;
    private Date opened;
    private Date closed;
    
    public Project(int id, String name, String descr, Date opened, Date closed) {
        this.id = id;
        this.name = name;
        this.descr = descr;
        this.opened = opened;
        this.closed = closed;
    }
    
    public int getID() { return id; }
    
    public String getName() { return name; }

    public String getDescr() { return descr; }
    
    public Date getOpenedDate() { return opened; }
    
    public Date getClosedDate() { return closed; }
    
    public void close() {
        closed = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
        ProjectsDB.update(this);
    }
    
    public void open() {
        closed = null;
        opened = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
        ProjectsDB.update(this);
    }
}
