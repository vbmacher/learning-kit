/*
 * TaskList.java
 *
 * Created on 23.5.2008, 8:45:22
 * hold to: KISS, YAGNI
 *
 */

package promemo.data;

import java.sql.Date;
import java.util.Calendar;

/**
 *
 * @author vbmacher
 */
public class TaskList {
    private int id;
    private int project_id;
    private String name;
    private String descr;
    private Date created;
    private Date closed;
    
    public TaskList(int id, int project_id, String name, String descr,
            Date created, Date closed) {
        this.id = id;
        this.project_id = project_id;
        this.name = name;
        this.descr = descr;
        this.created = created;
        this.closed = closed;
    }
    
    public int getID() { return id; }
    
    public String getName() { return name; }

    public String getDescr() { return descr; }
    
    public Date getCreatedDate() { return created; }
    
    public Date getClosedDate() { return closed; }
    
    public int getProjectID() { return project_id; }
    
    public void close() {
        closed = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
        TaskListsDB.update(this);
    }
    
    public void reopen() {
        closed = null;
        TaskListsDB.update(this);
    }

}
