/*
 * TasksDB.java
 *
 * Created on 25.5.2008, 10:08:11
 * hold to: KISS, YAGNI
 *
 */

package promemo.data;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import promemo.DerbyHandler;
import promemo.StaticUtils;

/**
 *
 * @author vbmacher
 */
public class TasksDB {
    
    /**
     * Adds new task into database
     */
    public static void add(Task task) {
        if (task == null) return;

        DerbyHandler db = DerbyHandler.getInstance();
        ArrayList params = new ArrayList();

        params.add("tasklist_id"); params.add(task.getTaskListID());
        params.add("name"); params.add(task.getName());
        if (task.getDescr() != null) {
            params.add("descr"); params.add(task.getDescr());
        }
        if (task.getClosedDate() != null) {
            params.add("closed"); params.add(task.getClosedDate());
        }
        Object[] res = DerbyHandler.createInsertStat("Tasks",
                params.toArray());
        Object[] args = new Object[res.length-1];
        System.arraycopy(res, 1, args, 0, res.length-1);
        try { db.execute((String)res[0],args); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't create task !"
                    + "\n\n" + e.getMessage());
        }
    }
    
    /**
     * Remove task from database
     */
    public static void delete(int id) {
        DerbyHandler db = DerbyHandler.getInstance();
        try { db.execute("delete from Tasks where id=?", id); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't delete task !"
                    + "\n\n" + e.getMessage());
        }
    }

    /**
     * Update task in database
     */
    public static void update(Task task) {
        if (task == null) return;
        
        DerbyHandler db = DerbyHandler.getInstance();
        ArrayList<Object> params = new ArrayList<Object>();

        params.add("tasklist_id"); params.add(task.getTaskListID());
        params.add("name"); params.add(task.getName());
        params.add("descr"); params.add(task.getDescr());
        params.add("closed"); params.add(task.getClosedDate());
        ArrayList clo = new ArrayList(); clo.add("id"); clo.add(task.getID());
        Object[] res = DerbyHandler.createUpdateStat("Tasks", params.toArray(),
                clo.toArray());
        Object[] args = new Object[res.length-1];
        System.arraycopy(res, 1, args, 0, res.length-1);
        try { db.update((String)res[0], args); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't update task data !"
                    + "\n\n" + e.getMessage());
        }
    }
    
    public static Task[] getTasks(int tlist_id) {
        DerbyHandler db = DerbyHandler.getInstance();
        try {
            String s = "select * from Tasks";
            if (tlist_id != -1)
                s += " where tasklist_id=?";
            ResultSet r = db.query(s, tlist_id);
            
            ArrayList<Task> ps = new ArrayList<Task>();
            while (r.next()) {
                int id  = r.getInt("id");
                int tasklist_id = r.getInt("tasklist_id");
                String name = r.getString("name");
                String descr = r.getString("descr");
                Date created = r.getDate("created");
                Date closed = r.getDate("closed");
                ps.add(new Task(id, tasklist_id, name, descr,created,closed));
            }
            return ps.toArray(new Task[0]);
        } catch(SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't get list of tasks"
                    + "\n\n" + e.getMessage());
        }
        return null;
    }
    
    public static Task[] getTasksByProject(int project_id) {
        TaskList[] tlists = TaskListsDB.getTaskLists(project_id);
        if (tlists == null) return null;
        ArrayList<Task> tasks = new ArrayList<Task>();
        for (int i = 0; i < tlists.length; i++) {
            Task[] ts = getTasks(tlists[i].getID());
            if (ts == null) continue;
            for (int j = 0; j < ts.length; j++)
                tasks.add(ts[j]);
        }
        return tasks.toArray(new Task[0]);
    }
    
    public static Task get(int id) {
        DerbyHandler db = DerbyHandler.getInstance();
        try {
            ResultSet r = db.query("select * from Tasks where id=?", id);
            if (r.next()) {
                int tasklist_id = r.getInt("tasklist_id");
                String name = r.getString("name");
                String descr = r.getString("descr");
                Date created = r.getDate("created");
                Date closed = r.getDate("closed");
                return new Task(id,tasklist_id,name,descr,created,closed);
            }
        } catch(SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't get task with id: "
                    + id + "\n\n" + e.getMessage());
        }
        return null;
    }

}
