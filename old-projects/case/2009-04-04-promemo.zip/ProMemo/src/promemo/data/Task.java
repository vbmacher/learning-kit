/*
 * Task.java
 *
 * Created on 25.5.2008, 10:02:31
 * hold to: KISS, YAGNI
 *
 */

package promemo.data;

import java.sql.Date;
import java.util.Calendar;

/**
 *
 * @author vbmacher
 */
public class Task {
    private int id;
    private int tasklist_id;
    private String name;
    private String descr;
    private Date created;
    private Date closed;
    
    public Task(int id, int tasklist_id, String name, String descr,
            Date created, Date closed) {
        this.id = id;
        this.tasklist_id = tasklist_id;
        this.name = name;
        this.descr = descr;
        this.created = created;
        this.closed = closed;
    }
    
    public int getID() { return id; }
    
    public String getName() { return name; }

    public String getDescr() { return descr; }
    
    public Date getCreatedDate() { return created; }
    
    public Date getClosedDate() { return closed; }
    
    public int getTaskListID() { return tasklist_id; }
    
    public void close() {
        closed = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
        TasksDB.update(this);
    }
    
    public void reopen() {
        closed = null;
        TasksDB.update(this);
    }

}
