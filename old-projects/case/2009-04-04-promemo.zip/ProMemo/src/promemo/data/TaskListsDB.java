/*
 * TaskListsDB.java
 *
 * Created on 24.5.2008, 12:04:47
 * hold to: KISS, YAGNI
 *
 */

package promemo.data;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import promemo.DerbyHandler;
import promemo.StaticUtils;

/**
 *
 * @author vbmacher
 */
public class TaskListsDB {
    
    /**
     * Adds new tasklist into database
     */
    public static void add(TaskList tlist) {
        if (tlist == null) return;

        DerbyHandler db = DerbyHandler.getInstance();
        ArrayList params = new ArrayList();

        params.add("project_id"); params.add(tlist.getProjectID());
        params.add("name"); params.add(tlist.getName());
        if (tlist.getDescr() != null) {
            params.add("descr"); params.add(tlist.getDescr());
        }
        if (tlist.getClosedDate() != null) {
            params.add("closed"); params.add(tlist.getClosedDate());
        }
        Object[] res = DerbyHandler.createInsertStat("TaskLists",
                params.toArray());
        Object[] args = new Object[res.length-1];
        System.arraycopy(res, 1, args, 0, res.length-1);
        try { db.execute((String)res[0],args); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't create tasklist !"
                    + "\n\n" + e.getMessage());
        }
    }
    
    /**
     * Remove tasklist from database
     * also delete all tasks in tasklist
     */
    public static void delete(int id) {
        DerbyHandler db = DerbyHandler.getInstance();
        try { db.execute("delete from TaskLists where id=?", id); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't delete tasklist !"
                    + "\n\n" + e.getMessage());
        }
    }

    /**
     * Update tasklist in database
     */
    public static void update(TaskList tlist) {
        if (tlist == null) return;
        
        DerbyHandler db = DerbyHandler.getInstance();
        ArrayList<Object> params = new ArrayList<Object>();

        params.add("project_id"); params.add(tlist.getProjectID());
        params.add("name"); params.add(tlist.getName());
        params.add("descr"); params.add(tlist.getDescr());
        params.add("closed"); params.add(tlist.getClosedDate());
        ArrayList clo = new ArrayList(); clo.add("id"); clo.add(tlist.getID());
        Object[] res = DerbyHandler.createUpdateStat("TaskLists", params.toArray(),
                clo.toArray());
        Object[] args = new Object[res.length-1];
        System.arraycopy(res, 1, args, 0, res.length-1);
        try { db.update((String)res[0], args); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't update tasklist data !"
                    + "\n\n" + e.getMessage());
        }
    }
    
    public static TaskList[] getTaskLists(int proj_id) {
        DerbyHandler db = DerbyHandler.getInstance();
        try {
            String s = "select * from TaskLists";
            if (proj_id != -1) 
                s += " where project_id=?";
            ResultSet r = db.query(s,proj_id);
            ArrayList<TaskList> ps = new ArrayList<TaskList>();
            while (r.next()) {
                int id  = r.getInt("id");
                int project_id = r.getInt("project_id");
                String name = r.getString("name");
                String descr = r.getString("descr");
                Date created = r.getDate("created");
                Date closed = r.getDate("closed");
                ps.add(new TaskList(id, project_id, name, descr,created,closed));
            }
            return ps.toArray(new TaskList[0]);
        } catch(SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't get list of tasklists"
                    + "\n\n" + e.getMessage());
        }
        return null;
    }
    
    public static TaskList get(int id) {
        DerbyHandler db = DerbyHandler.getInstance();
        try {
            ResultSet r = db.query("select * from TaskLists where id=?", id);
            if (r.next()) {
                int project_id = r.getInt("project_id");
                String name = r.getString("name");
                String descr = r.getString("descr");
                Date created = r.getDate("created");
                Date closed = r.getDate("closed");
                return new TaskList(id,project_id,name,descr,created,closed);
            }
        } catch(SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't get tasklist with id: "
                    + id + "\n\n" + e.getMessage());
        }
        return null;
    }
}
