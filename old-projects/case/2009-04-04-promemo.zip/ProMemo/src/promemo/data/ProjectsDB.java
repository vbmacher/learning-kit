/*
 * ProjectsDB.java
 *
 * Created on 21.5.2008, 11:12:59
 * hold to: KISS, YAGNI
 *
 */

package promemo.data;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import promemo.DerbyHandler;
import promemo.StaticUtils;

/**
 *
 * @author vbmacher
 */
public class ProjectsDB {
    
    /**
     * Adds new project into database
     */
    public static void add(Project proj) {
        if (proj == null) return;

        DerbyHandler db = DerbyHandler.getInstance();
        ArrayList params = new ArrayList();

        params.add("name"); params.add(proj.getName());
        params.add("opened"); params.add(proj.getOpenedDate());
        if (proj.getDescr() != null) {
            params.add("descr"); params.add(proj.getDescr());
        }
        if (proj.getClosedDate() != null) {
            params.add("closed"); params.add(proj.getClosedDate());
        }
        Object[] res = DerbyHandler.createInsertStat("Projects",
                params.toArray());
        Object[] args = new Object[res.length-1];
        System.arraycopy(res, 1, args, 0, res.length-1);
        try { db.execute((String)res[0],args); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't create project !"
                    + "\n\n" + e.getMessage());
        }
    }
    
    /**
     * Remove project from database
     */
    public static void delete(int id) {
        DerbyHandler db = DerbyHandler.getInstance();
        try { db.execute("delete from Projects where id=?", id); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't delete project !"
                    + "\n\n" + e.getMessage());
        }
    }

    /**
     * Update project in database
     */
    public static void update(Project proj) {
        if (proj == null) return;
        
        DerbyHandler db = DerbyHandler.getInstance();
        ArrayList<Object> params = new ArrayList<Object>();

        params.add("name"); params.add(proj.getName());
        params.add("opened"); params.add(proj.getOpenedDate());
        params.add("descr"); params.add(proj.getDescr());
        params.add("closed"); params.add(proj.getClosedDate());
        ArrayList clo = new ArrayList(); clo.add("id"); clo.add(proj.getID());
        Object[] res = DerbyHandler.createUpdateStat("Projects", params.toArray(),
                clo.toArray());
        Object[] args = new Object[res.length-1];
        System.arraycopy(res, 1, args, 0, res.length-1);
        try { db.update((String)res[0], args); }
        catch (SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't update project data !"
                    + "\n\n" + e.getMessage());
        }
    }
    
    public static Project[] getProjects() {
        DerbyHandler db = DerbyHandler.getInstance();
        try {
            ResultSet r = db.query("select * from Projects");
            ArrayList<Project> ps = new ArrayList<Project>();
            while (r.next()) {
                int id  = r.getInt("id");
                String name = r.getString("name");
                String descr = r.getString("descr");
                Date opened = r.getDate("opened");
                Date closed = r.getDate("closed");
                ps.add(new Project(id, name, descr,opened,closed));
            }
            return ps.toArray(new Project[0]);
        } catch(SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't get project list"
                    + "\n\n" + e.getMessage());
        }
        return null;
    }
    
    public static Project get(int id) {
        DerbyHandler db = DerbyHandler.getInstance();
        try {
            ResultSet r = db.query("select * from Projects where id=?", id);
            if (r.next()) {
                String name = r.getString("name");
                String descr = r.getString("descr");
                Date opened = r.getDate("opened");
                Date closed = r.getDate("closed");
                return new Project(id,name,descr,opened,closed);
            }
        } catch(SQLException e) {
            StaticUtils.showErrorMessage(null, "Couldn't get project with id: "
                    + id + "\n\n" + e.getMessage());
        }
        return null;
    }
    
}
