/*
 * StaticUtils.java
 *
 * Created on 21.5.2008, 9:26:02
 * hold to: KISS, YAGNI
 *
 */

package promemo;

import java.awt.Component;
//import java.util.ArrayList;
//import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import promemo.gui.MainWindow;
import promemo.gui.ProjectsDialog;

/**
 *
 * @author vbmacher
 */
public class StaticUtils {

    public static void showErrorMessage(Component parent, String mes) {
        JOptionPane.showMessageDialog(parent, "Error: " + mes, "ProMemo",
                JOptionPane.ERROR_MESSAGE);
    }

    public static void openProject() {
        ProjectsDialog pd = new ProjectsDialog(null,true);
        pd.setVisible(true);
        
        if (pd.getOKp() == false) return;
        new MainWindow(pd.getID()).setVisible(true);        
    }
    
    public static void main(String[] args) {        
        // connect to/create a database
        DerbyHandler.getInstance();
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {}

        openProject();
    }
}
