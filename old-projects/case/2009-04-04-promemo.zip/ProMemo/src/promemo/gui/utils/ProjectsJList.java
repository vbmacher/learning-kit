/*
 * ProjectsJList.java
 *
 * Created on 23.5.2008, 8:52:40
 * hold to: KISS, YAGNI
 *
 */

package promemo.gui.utils;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.AbstractListModel;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import promemo.data.Project;

/**
 *
 * @author vbmacher
 */
public class ProjectsJList extends JList {

    private ProjectsLBM lbm;
    private Project[] projects;

    public ProjectsJList(Project[] projects) {
        this.projects = projects;
        orderProjects();
        lbm = new ProjectsLBM();
        final ProjectCellRenderer pcr = new ProjectCellRenderer();
        this.setModel(lbm);
        this.setBackground(Color.WHITE);
        this.setCellRenderer(pcr);
        this.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        
      
        this.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int index = locationToIndex(e.getPoint());
                if (index != -1 && e.getClickCount() == 2) {
                    if (isProjectClosed(index)) OpenProj(index);
                    else CloseProj(index);
                    orderProjects();
                    lbm.contentsChanged();
                }
            }
        });
    }

    private void OpenProj(int index) { projects[index].open(); }
    private void CloseProj(int index) { projects[index].close(); }
    
    public void projectAdded(Project[] projects) {
        this.projects = projects;
        orderProjects();
        lbm.addedElement();
    }
    
    public void projectRemoved(Project[] projects) {
        this.projects = projects;
        orderProjects();
        lbm.removedElement();
    }

    public void projectChanged(Project[] projects) {
        this.projects = projects;
        orderProjects();
        lbm.contentsChanged();
    }

    public int getIDAt(int index) {
        if (projects == null) return -1;
        return projects[index].getID();
    }
    
    public boolean isProjectClosed(int index) {
        return (projects[index].getClosedDate() == null) ? false : true;
    }

    /**
     * Method reorders projects to specific order: closed projects are last
     */
    private void orderProjects() {
        ArrayList<Project> p = new ArrayList<Project>();
        for (int i = 0; i < projects.length; i++)
            if (projects[i].getClosedDate() == null)
                p.add(projects[i]);
        for (int i = 0; i < projects.length; i++)
            if (projects[i].getClosedDate() != null)
                p.add(projects[i]);
        this.projects = p.toArray(new Project[0]);
    }
    
    private class ProjectsLBM extends AbstractListModel {
        public int getSize() {
            if (projects == null) return 0;
            return projects.length;
        }
        public Object getElementAt(int index) {
            if (projects == null) return null;
            if (projects[index].getClosedDate() == null)
                return "<html>" + projects[index].getName() + " <small>(opened: "
                        + projects[index].getOpenedDate().toString()
                        + ")</small>";
            else
                return "<html>" + projects[index].getName() + " <small>(closed: "
                        + projects[index].getClosedDate().toString()
                        + ")</small>";
        }
        
        public void addedElement() {
            this.fireIntervalAdded(this, 0, projects.length);
        }
        
        public void removedElement() {
            this.fireIntervalRemoved(this, 0, projects.length);
        }
        
        public void contentsChanged() {
            this.fireContentsChanged(this, 0, projects.length);
        }
    }

    private class ProjectCellRenderer extends JCheckBox implements ListCellRenderer {

        public Component getListCellRendererComponent(
            JList list,
            Object value,            // value to display
            int index,               // cell index
            boolean isSelected,      // is the cell selected
            boolean cellHasFocus)    // the list and the cell have the focus
        {
            setText(value.toString());
            if (isProjectClosed(index))
                this.setSelected(true);
            else
                this.setSelected(false);
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            }
            else {
                setBackground(list.getBackground());
                if (isProjectClosed(index))
                    setForeground(Color.DARK_GRAY);
                else
                    setForeground(Color.BLACK);
            }
            setEnabled(list.isEnabled());
            setFont(list.getFont());
            setOpaque(true);
            return this;
        }

 }
}
