/*
 * TListsJComboBox.java
 *
 * Created on 25.5.2008, 10:25:20
 * hold to: KISS, YAGNI
 *
 */

package promemo.gui.utils;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import promemo.data.TaskList;
import promemo.data.TasksDB;
import promemo.gui.MainWindow;

/**
 *
 * @author vbmacher
 */
public class TListsJComboBox extends JComboBox {
    private TListsLBM lbm;
    private TaskList[] tlists;
    private TListsJComboBox instance;
    private TasksJList tasks;
    private MainWindow mwin;

    public TListsJComboBox(TaskList[] tlists, final TasksJList tasks, 
            final MainWindow mwin) {
        this.tlists = tlists;
        this.mwin = mwin;
        this.tasks = tasks;
        orderTLists();
        lbm = new TListsLBM();
        final TListsRenderer pcr = new TListsRenderer();
        this.setModel(lbm);
        this.setEditable(false);
        this.setBackground(Color.WHITE);
        this.setRenderer(pcr);        
      
        this.addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    int id = getIDAt(getSelectedIndex());
                    if (id == -1) 
                        tasks.taskChanged(TasksDB
                                .getTasksByProject(mwin.getProjectID()));
                    else tasks.taskChanged(TasksDB.getTasks(id));
                }
            }
            
        });
        instance = this;
    }
   
    public void tlistAdded(TaskList[] tlists) {
        this.tlists = tlists;
        orderTLists();
        lbm.addedElement();
    }
    
    public void tlistRemoved(TaskList[] tlists) {
        this.tlists = tlists;
        orderTLists();
        lbm.removedElement();
    }

    public void tlistChanged(TaskList[] tlists) {
        this.tlists = tlists;
        orderTLists();
        lbm.contentsChanged();
    }

    public int getIDAt(int index) {
        if (tlists == null || index == 0) return -1;
        return tlists[index-1].getID();
    }
    
    public boolean isTListClosed(int index) {
        if (index <= 0) return false;
        return (tlists[index-1].getClosedDate() == null) ? false : true;
    }
    
    public void selectAtID(int id) {
        if (tlists == null) return;
        for (int i = 0; i < tlists.length; i++)
            if (tlists[i].getID() == id) {
                this.setSelectedIndex(i+1);
                return;
            }
    }

    /**
     * Method reorders tasklists to specific order: closed tasklists are last
     */
    private void orderTLists() {
        ArrayList<TaskList> p = new ArrayList<TaskList>();
        for (int i = 0; i < tlists.length; i++)
            if (tlists[i].getClosedDate() == null)
                p.add(tlists[i]);
        for (int i = 0; i < tlists.length; i++)
            if (tlists[i].getClosedDate() != null)
                p.add(tlists[i]);
        this.tlists = p.toArray(new TaskList[0]);
    }
    
    private class TListsLBM extends AbstractListModel implements ComboBoxModel {
        private Object selectedObject = null;
        public void setSelectedItem(Object item) {
            selectedObject = item;
            fireContentsChanged(this, -1, -1);
        }
        public Object getSelectedItem() {
                return selectedObject;
        }
        public int getSize() {
            if (tlists == null) return 1;
            return tlists.length + 1;
        }
        public Object getElementAt(int index) {
            if (index == 0)
                return "<html><em>(all tasks)</em>";
            if (tlists == null) return null;
            if (tlists[index-1].getClosedDate() == null)
                return "<html>" + tlists[index-1].getName() + " <small>(created: "
                        + tlists[index-1].getCreatedDate().toString()
                        + ")</small>";
            else
                return "<html>" + tlists[index-1].getName() + " <small>(closed: "
                        + tlists[index-1].getClosedDate().toString()
                        + ")</small>";
        }
        public void addedElement() {
            this.fireIntervalAdded(this, 0, tlists.length+1);
        }
        
        public void removedElement() {
            this.fireIntervalRemoved(this, 0, tlists.length+1);
        }
        
        public void contentsChanged() {
            this.fireContentsChanged(this, -1, -1);
        }
    }
    
    private class TListsRenderer extends JCheckBox implements ListCellRenderer {

        public Component getListCellRendererComponent(
            JList list,
            Object value,            // value to display
            int index,               // cell index
            boolean isSelected,      // is the cell selected
            boolean cellHasFocus)    // the list and the cell have the focus
        {
            if (value == null)
                setText("<html><em>(all tasks)</em>");
            else
                setText(value.toString());
            if (index == -1) index = instance.getSelectedIndex();
            if (isTListClosed(index))
                this.setSelected(true);
            else
                this.setSelected(false);
                    
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            }
            else {
                setBackground(list.getBackground());
                if (isTListClosed(index))
                    setForeground(Color.DARK_GRAY);
                else
                    setForeground(Color.BLACK);
            }
            setEnabled(list.isEnabled());
            setFont(list.getFont());
            setOpaque(true);
            return this;
        }
    }

}
