/*
 * TasksJList.java
 *
 * Created on 25.5.2008, 9:53:54
 * hold to: KISS, YAGNI
 *
 */

package promemo.gui.utils;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.AbstractListModel;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import promemo.data.Task;

/**
 * @author vbmacher
 * 
 * TODO: show description if available
 */
public class TasksJList extends JList {

    private TasksLBM lbm;
    private Task[] tasks;
    private TasksJList instance;

    public TasksJList(Task[] tasks) {
        this.tasks = tasks;
        orderTasks();
        instance = this;
        lbm = new TasksLBM();
        final TaskCellRenderer pcr = new TaskCellRenderer();
        this.setModel(lbm);
        this.setBackground(Color.WHITE);
        this.setCellRenderer(pcr);
        this.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        
      
        this.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int index = locationToIndex(e.getPoint());
                if (index != -1 && e.getClickCount() == 2) {
                    if (isTaskClosed(index)) OpenTask(index);
                    else CloseTask(index);
                    orderTasks();
                    lbm.contentsChanged();
                }
            }
        });
    }

    private void OpenTask(int index) { tasks[index].reopen(); }
    private void CloseTask(int index) { tasks[index].close(); }
    
    public void taskAdded(Task[] tasks) {
        this.tasks = tasks;
        orderTasks();
        lbm.addedElement();
    }
    
    public void taskRemoved(Task[] tasks) {
        this.tasks = tasks;
        orderTasks();
        lbm.removedElement();
    }

    public void taskChanged(Task[] tasks) {
        this.tasks = tasks;
        orderTasks();
        lbm.contentsChanged();
    }

    public int getIDAt(int index) {
        if (tasks == null) return -1;
        return tasks[index].getID();
    }
    
    public boolean isTaskClosed(int index) {
        return (tasks[index].getClosedDate() == null) ? false : true;
    }

    /**
     * Method reorders projects to specific order: closed projects are last
     */
    private void orderTasks() {
        ArrayList<Task> p = new ArrayList<Task>();
        for (int i = 0; i < tasks.length; i++)
            if (tasks[i].getClosedDate() == null)
                p.add(tasks[i]);
        for (int i = 0; i < tasks.length; i++)
            if (tasks[i].getClosedDate() != null)
                p.add(tasks[i]);
        this.tasks = p.toArray(new Task[0]);
    }
    
    private class TasksLBM extends AbstractListModel {
        public int getSize() {
            if (tasks == null) return 0;
            return tasks.length;
        }
        public Object getElementAt(int index) {
            if (tasks == null) return null;
            String s;
            if (tasks[index].getClosedDate() == null)
                s = "<html>" + tasks[index].getName() + " <small>(created: "
                        + tasks[index].getCreatedDate().toString()
                        + ")</small>";
            else
                s = "<html><strike>" + tasks[index].getName() 
                        + "</strike> <small>(closed: "
                        + tasks[index].getClosedDate().toString()
                        + ")</small>";
            if (tasks[index].getDescr() != null) {
                
                s += "<br/>"+tasks[index].getDescr();
            }
            System.out.println(s);
            return s;
        }
        
        public void addedElement() {
            this.fireIntervalAdded(this, 0, tasks.length);
        }
        
        public void removedElement() {
            this.fireIntervalRemoved(this, 0, tasks.length);
        }
        
        public void contentsChanged() {
            this.fireContentsChanged(this, 0, tasks.length);
        }
    }

    private class TaskCellRenderer extends JCheckBox implements ListCellRenderer {

        public Component getListCellRendererComponent(
            JList list,
            Object value,            // value to display
            int index,               // cell index
            boolean isSelected,      // is the cell selected
            boolean cellHasFocus)    // the list and the cell have the focus
        {
            setText(value.toString());
            if (isTaskClosed(index))
                this.setSelected(true);
            else
                this.setSelected(false);
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            }
            else {
                setBackground(list.getBackground());
                if (isTaskClosed(index))
                    setForeground(Color.DARK_GRAY);
                else
                    setForeground(Color.BLACK);
            }
            setEnabled(list.isEnabled());
            setFont(list.getFont());
            setOpaque(true);
            return this;
        }
    }
}
