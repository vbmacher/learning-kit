#include <stdio.h>
#include <string.h>
#include <ctype.h>

typedef struct {
  int gx_from;
  int gx_to;
} gx;

typedef struct {
  int gy_from;
  int gy_to;
} gy;


int main(int argc, char *argv[]) {
    FILE *fin;
    FILE *fout;
    int i,j,c,val,subtype,row;
    gx hrx[30];
    gy hry[30];

char ood[6];

  if (argc < 3) { 
    printf("Chyba(ju) argument(y) !\n");
    return 1;
  }
  subtype = atoi(argv[2]);
  if ((fin = fopen(argv[1],"r")) == NULL) {
    printf("Nepodarilo sa otvorit vstupny subor !\n");
    return 1;
  }
  if ((fout = fopen(strcat(argv[1],".sql"),"w")) == NULL) {
    printf("Nepodarilo sa otvorit vystupny subor !\n");
    return 1;
  }
  
  for (i = 0; i < 30; i++) {
      hrx[i].gx_from = 0;
      hrx[i].gx_to = 0;
  }
  for (i = 0; i < 30; i++) {
      hry[i].gy_from = 0;
      hry[i].gy_to = 0;
  }

      c = fgetc(fin);
      if (c != ';') { printf("error, expecting ';'\n"); return; }
      
      /* horne hranice - gx */
      j = 0; /* j - stlpec */
      c = fgetc(fin);
      while (!feof(fin) && (c != '\n')) {
          /* od */
          i = 0; /* i - pozicia v cisle*/
          while (!isdigit(c) && (c != ';') && (c != '\n')) c = fgetc(fin);
          if (c == ';') { /* dalsi stlpec ? */
              j++;
              c = fgetc(fin);
              continue;
          }
          if (c == '\n') break;
          while (isdigit(c)) {
              ood[i++] = c;
              c = fgetc(fin);
          }
          ood[i] = 0;
          hrx[j].gx_from = atoi(ood);

printf("identified: %d. gx_from = %d; ", j,hrx[j].gx_from);
          /* do */
          i = 0; /* i - pozicia v cisle*/
          while (!isdigit(c) && (c != ';')) c = fgetc(fin); /* POZOR: ignorujem pomlcku na oddelenie hranic !!*/
          if (c == ';') { /* dalsi stlpec ? - chyba do !! */
              printf("error, expecting TO boundary!\n");
              return;
          }
          while (isdigit(c)) {
              ood[i++] = c;
              c = fgetc(fin);
          }
          ood[i] = 0;
          hrx[j].gx_to = atoi(ood);
printf("%d. gx_to = %d\n", j,hrx[j].gx_to);
      }

      /* hranica gy a potom hodnoty */
      j = 0; /* j - stlpec */
      row = 0;
      while (!feof(fin) && (c = fgetc(fin)) != '\n') {
          /* od */
          i = 0; /* i - pozicia v cisle*/
          while (!isdigit(c) && (c != ';') && (c != '\n')) c = fgetc(fin);
          if (c == ';') { /* dalsi stlpec ? */
              j++;
              continue;
          }
          if (c == '\n') break;
          while (isdigit(c)) {
              ood[i++] = c;
              c = fgetc(fin);
          }
          ood[i] = 0;
          hry[row].gy_from = atoi(ood);
printf("identified: %d. gy_from = %d; ", row,hry[row].gy_from);
          /* do */
          i = 0; /* i - pozicia v cisle*/
          while (!isdigit(c) && (c != ';')) c = fgetc(fin); /* POZOR: ignorujem pomlcku na oddelenie hranic !!*/
          if (c == ';') { /* dalsi stlpec ? - chyba do !! */
              printf("error, expecting TO boundary!\n");
              return;
          }
          while (isdigit(c)) {
              ood[i++] = c;
              c = fgetc(fin);
          }
          ood[i] = 0;
          hry[row].gy_to = atoi(ood);
printf("%d. gy_to = %d\n", row,hry[row].gy_to);

          /* hodnoty */
          c = fgetc(fin);
          while (!feof(fin) && (c != '\n')) {
              while (!isdigit(c)) {
                  if (c == ';') /* dalsi stlpec ? */
                      j++;
                  else if (c == '\n') /* dalsi riadok ? */
                      break;
                  c = fgetc(fin);
              }
              if (c == '\n') {
                  row++;
                  j = 0;
                  break;
              }
              i = 0;
              while (isdigit(c)) {
                  ood[i++] = c;
                  c = fgetc(fin);
              }
              ood[i] = 0;
              val = atoi(ood);
              fprintf(fout, "insert into Windows(subtype_id,gx_from,gx_to,gy_from,gy_to,prize) values ");
              fprintf(fout, "%d, %d, %d, %d, %d, %d;\n", subtype, hrx[j].gx_from, hrx[j].gx_to, hry[row].gy_from,
                            hry[row].gy_to, val);
              fflush(fout);
          }
      }

  fclose(fin);
  fclose(fout);
 
}

