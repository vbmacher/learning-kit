/**
 * precision.h
 *
 * (c) Copyright 2011, P. Jakubčo <pjakubco@gmail.com>
 *
 * KISS, YAGNI
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef __PRECISION_H__
#define __PRECISION_H__

#include <stdio.h>

typedef unsigned char Component;

// This structure represents a number with any precision
typedef struct {
  Component *component; // the number components, little endian
  long exponent;
  int components_count;   // number of components taken by this number
  unsigned char sign;     // sign
} Number;


void print_number(FILE *out, const Number *number, int radix);
Number *new_number(double value, int max_floating_point);
void zero_number(Number *number);
void free_number(Number *number);

Number *add(const Number *term1, const Number *term2);
Number *sub(const Number *subtrahend, const Number *minuend);
Number *mul(const Number *factor1, const Number *factor2);

#define LOG102 0.30102999566398114

#endif
