/**
 * precision.c
 *
 * (c) Copyright 2011, P. Jakubčo <pjakubco@gmail.com>
 *
 * KISS, DRY, YAGNI
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
#include <math.h>
#include <memory.h>
#include <precision.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//#define DEBUG

static void print_integer_number(FILE *out, Component *components, int count, int radix);
static double own_floor(double value);
static double own_ceil(double value);
static double floating_part(double value, int max_floating_points);
static Component *int_to_components(Component* components, int start, double value, int bytes);


/**
 * Own function for computing floor. Avoids precision leaks.
 */
double own_floor(double value) {
  int k;
  char tmp[200]; // maximal digit count in floating point
  sprintf(tmp, "%.10lf", value);

  // if there is no floating point
  if (strchr(tmp, '.') == NULL) {
    return value;
  }

  // give away "."
  for (k = strlen(tmp)-1; k >= 0; k--) {
    if (tmp[k] == '.') {
      tmp[k] = 0;
      break;
    }
    tmp[k] = 0;
  }
  return (double)atol(tmp);
}

/**
 * Own function for computing ceil. Avoids precision leaks.
 */
double own_ceil(double value) {
  int k;
  char tmp[200]; // maximal digit count in floating point
  sprintf(tmp, "%.10lf", value);

  // if there is no floating point
  if (strchr(tmp, '.') == NULL) {
    return value;
  }

  // give away "."
  for (k = strlen(tmp)-1; k >= 0; k--) {
    if (tmp[k] == '.') {
      tmp[k] = 0;
      break;
    }
    tmp[k] = 0;
  }
  return (((double)atol(tmp)) + 1);
}

/**
 * Function that converts the floating-point part into integer part and cuts off the previous integer part. Avoids precision leaks.
 */
double floating_part(double value, int max_floating_points) {
  char tmp[200]; // maximal digit count in floating point
  char *p_tmp;

  char sformat[10]; // max length of string format
  sprintf(sformat, "%s", "%.");
  sprintf(sformat + strlen(sformat), "%d", max_floating_points);
  sprintf(sformat + strlen(sformat), "%s", "lf");
  value = value - own_floor(value);
  sprintf(tmp, sformat, value);

  // if there is no floating point, return 0 (value should == 0)
  if (strchr(tmp, '.') == NULL) {
    return 0;
  }

  // give away "."
  for (p_tmp = tmp; *p_tmp != 0; p_tmp++) {
    if (*p_tmp == '.') {
      p_tmp++;
      break;
    }
  }

  return (double)atol(p_tmp);
}


/**
 * Convert integer part to Number components. Private function.
 * Little endian.
 *
 * @param components - array of bytes where to store the result
 * @param start - starting index of the array
 * @param value - the integer value stored in double
 * @param bytes - max. no. of bytes taken by the value
 */
Component *int_to_components(Component* components, int start, double value, int bytes) {
  unsigned char byte = 0;
  double tst;
  int i,j;

  tst = own_floor(value);
  i = start;
  j = 0;
  bytes += start;
  do {
    byte |= ((((unsigned char)fmod(tst, 2.0))&1) << j); 
    tst = own_floor(tst/2.0);

    if (tst && (j < 7)) {
      j++;
    } else {
      components[i++] = byte;
      byte = 0;
      j = 0;
    }
  } while ((tst > 0.0) && (i < bytes));
  components[i++] = byte;
  return components;
}


/**
 * Converts double value to Number with highest possible precision
 *
 * @param value - value to convert
 * @param max_floating_point - maximal value of floating point numbers
 */
Number *new_number(double value, int max_floating_point) {
  int float_bytes = 0, int_bytes = 0;
  double tst,tst1;
  int sign = 0,i;

  Number *number = (Number *)malloc(sizeof(Number));

  if (value < 0) {
    sign = 1;
    value = -value;
  }

  // compute number of components taken by this value
  tst = own_floor(value);

  if (tst) {
    int_bytes = own_ceil(log2(tst) / 8); // integer part only
  }
  int_bytes = (int_bytes > 0) ? int_bytes : 1; // we need at least 1 byte

  tst = value - tst; // cut off integer part
  tst = floating_part(tst, max_floating_point);

  if (tst) {
    float_bytes = ceil(log2(tst) / 8); // floating-point part
    float_bytes = (float_bytes > 0) ? float_bytes : 1;
  }

  number->sign = sign;
  number->components_count = int_bytes + float_bytes;
  number->component = (unsigned char*)malloc(number->components_count * sizeof(unsigned char));
  zero_number(number);
  number->exponent = float_bytes;

#ifdef DEBUG
    fprintf(stderr, "Bytes count: %d\n", number->components_count);
    fprintf(stderr, "Exponent: %d\n", number->exponent);
#endif

  // convert floating-point part
  int_to_components(number->component, 0, tst, float_bytes);

  // convert integer part
  int_to_components(number->component, float_bytes, value, int_bytes);

  return number;
}

/**
 * Zeroes the number.
 */
void zero_number(Number *number) {
  memset(number->component, 0, number->components_count);
  number->exponent = 0;
}

/**
 * Frees memory for this number.
 */
void free_number(Number *number) {
  if (number && number->component) {
    free(number->component);
    free(number);
  } else if (number) {
    free(number);
  }
}

/**
 * Print a Number to output stream. Number of digits is computed as `bits * log_radix(2)`, i.e. for output radix=10 it is
 * `bits * log10(2)`.
 *
 * @param out the output stream (stdout or file)
 * @param number the Number to print
 * @param radix destination radix. Could be from 2-36. If none of these is specified, it uses default radix (10).
 */
void print_number(FILE *out, const Number *number, int radix) {
  if (radix < 2 || radix > 36) {
    radix = 10;
  }

  print_integer_number(out, number->component+ number->exponent, number->components_count- number->exponent, radix); 

  if (number->exponent > 0) {
    fprintf(out, ".");
    print_integer_number(out, number->component, number->exponent, radix); 
  }
  fprintf(out,"\n");
}


/**
 * Internal linkage.
 */
void print_integer_number(FILE *out, unsigned char *components, int count, int radix) {
  int bytes;
  int i,j,val;
  char *str;
  char *ts;
  int temp;
  int rem;
  int ip;
  int first;
  unsigned char *p_val;

  bytes = own_ceil((double)count * 8.0 * LOG102/log(radix))+2;
  str = (char *)malloc(bytes+1);
  ts = (char *)malloc(bytes+1);

  memset(str, 0, bytes+1);
  memset(ts, 0, bytes+1);
  ts[0] = 1;

#ifdef DEBUG
    for (p_val = components ; p_val < components + count; p_val++) {
      fprintf(stderr, "%x ", (int)*p_val);
    }
    fprintf(stderr,"\n\n");
#endif

  for (p_val = components; p_val < components + count; p_val++) {
    for (i = 0; i < 8; i++) {
      val = ((*p_val) >> i) & 1;
      for (j = 0; j < bytes; j++) {
        str[j] += ts[j] * val;
        temp = str[j];
        ip = j;
        do { // fix up any remainders in radix
          rem = temp / radix;
          str[ip++] = temp - rem * radix;
          str[ip] += rem;
          temp = str[ip];
        } while (temp >= radix);
      }

#ifdef DEBUG
        for (j = 0; j < bytes; j++) {
          fprintf(stderr, "%d ",(int)str[j]);
        }
        fprintf(stderr, "\n");
#endif

      //calculate the next power 2^i) in radix format
      for (j = 0; j < bytes; j++) {
        ts[j] = ts[j] * 2;
      }
      for(j = 0; j < bytes; j++) { //check for any remainders
        temp = ts[j];
        ip = j;
        do { //fix up any remainders
          rem = temp / radix;
          ts[ip++] = temp - rem * radix;
          ts[ip] += rem;
          temp = ts[ip];
        } while (temp >= radix);
      }
    }
  }

  //convert the output to string format (digits 0,to-1 converted to 0-Z characters) 
  first = 0; //leading zero flag
  for (i = bytes-1; i >= 0; i--) {
    if (str[i] != 0) {
      first = 1;
    }
    if (!first) {
      continue;
    }
    if (str[i] < 10) {
      fprintf(out, "%c", str[i] + '0');
    } else {
      fprintf(out, "%c", str[i] + 'A'-10);
    }
  }
  if (!first) {
    fprintf(out, "0");
  }
  free(ts);
  free(str);
}



/**
 * Add two terms (numbers). 
 *
 * @param term1
 *   First summand
 * @param term2
 *   Second summand
 * @return pointer to the sum of the summands.
 */

Number *add(const Number *term1, const Number *term2) {
/*
 11111111   255
 11111111   255
===============
111111110   510
===============
2^8+2^7+2^6+2^5+2^4+2^3+2^2+2=256+128+64+32+16+8+4+2=384+64+48+14=

384
 64
 48
 14
===
510
*/
}

/**
 * Subtracts two numbers, (subtrahend - minuend). 
 *
 * @param subtrahend
 *   Subtrahend
 * @param minuend
 *   Minuend
 * @return pointer to the subtraction result.
 */

Number *sub(const Number *subtrahend, const Number *minuend) {

}

/**
 * Multiplies two numbers.
 *
 * @param factor1
 *   First factor
 * @param factor2
 *   Second factor
 * @return pointer to the multiplication result.
 */

Number *mul(const Number *factor1, const Number *factor2) {

}


