#include <stdio.h>
#include <dos.h>
#include <conio.h>

void PrintMenu()
{
 clrscr();
 printf("\nElektronicka ladicka v1.00\n");
 printf("\n1 - C\n2 - C#\n3 - D\n4 - D#\n5 - E\n6 - F\n7 - F#\n8 - G");
 printf("\n9 - G#\na - A\nb - A#\nc - H\n\nd - Koniec\n?:");
}

void PutSound(double freq, int oct)
{
 double real_freq;

 real_freq = (freq / 4) * oct;
 sound(real_freq);

 printf("\nStlacte lubovolnu klavesu...");

 while (!kbhit()) ;
 nosound();
}

main()
{
 int ch;
 int octave;
 int a=0;

start:
 PrintMenu();
 if ((ch = getch()) > 'd')
   goto start;
 if (ch < '1')
   goto start;
 if ((ch > '9') && (ch < 'a'))
   goto start;

oktava:
 if (ch != 'd') {
   printf("\nVlozte cislo okravy (1 - ..):");
   if (((octave = getch()) < '1') || (octave > '9')) {
     printf("\nNespravna volba");
     goto oktava;
   }
   else
     octave -= '0';
 }

 switch (ch) {
   case '1': // C
     printf("C");
     PutSound(261.63, octave);
     break;
   case '2': // C#
     printf("C#");
     PutSound(277.18, octave);
     break;
   case '3': // D
     printf("D");
     PutSound(293.66, octave);
     break;
   case '4': // D#
     printf("D#");
     PutSound(311.13, octave);
     break;
   case '5': // E
     printf("E");
     PutSound(329.63, octave);
     break;
   case '6': // F
     printf("F");
     PutSound(349.23, octave);
     break;
   case '7': // F#
     printf("F#");
     PutSound(369.99, octave);
     break;
   case '8': // G
     printf("G");
     PutSound(392.00, octave);
     break;
   case '9': // G#
     printf("G#");
     PutSound(415.30, octave);
     break;
   case 'a': // A
     printf("A");
     PutSound(440.00, octave);
     break;
   case 'b': // A#
     printf("A#");
     PutSound(466.16, octave);
     break;
   case 'c': // H
     printf("H");
     PutSound(493.88, octave);
     break;
   case 'd': // END
     a=1;
 }
 if (a != 1)
   goto start;
}