package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

public class WaveformLinks   {
  
  private String self = null;
  private String interaction = null;

  /**
   * URI to get this waveforms metadata
   **/
  public WaveformLinks self(String self) {
    this.self = self;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get this waveforms metadata")
  @JsonProperty("self")
  public String getSelf() {
    return self;
  }
  public void setSelf(String self) {
    this.self = self;
  }

  /**
   * URI to get interaction metadata (root)
   **/
  public WaveformLinks interaction(String interaction) {
    this.interaction = interaction;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get interaction metadata (root)")
  @JsonProperty("interaction")
  public String getInteraction() {
    return interaction;
  }
  public void setInteraction(String interaction) {
    this.interaction = interaction;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    WaveformLinks waveformLinks = (WaveformLinks) o;
    return Objects.equals(self, waveformLinks.self) &&
        Objects.equals(interaction, waveformLinks.interaction);
  }

  @Override
  public int hashCode() {
    return Objects.hash(self, interaction);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class WaveformLinks {\n");
    
    sb.append("    self: ").append(toIndentedString(self)).append("\n");
    sb.append("    interaction: ").append(toIndentedString(interaction)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

