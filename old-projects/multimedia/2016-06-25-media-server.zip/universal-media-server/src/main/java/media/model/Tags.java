package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Tags   {
  
  private String status = null;
  private Integer audioIndex = null;
  private List<Tag> tags = new ArrayList<Tag>();
  private TagsLinks links = null;

  /**
   * \\\"OK\\\" or error enumeration value in case of error
   **/
  public Tags status(String status) {
    this.status = status;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "\\\"OK\\\" or error enumeration value in case of error")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Audio segment index owning the tag.
   **/
  public Tags audioIndex(Integer audioIndex) {
    this.audioIndex = audioIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Audio segment index owning the tag.")
  @JsonProperty("audioIndex")
  public Integer getAudioIndex() {
    return audioIndex;
  }
  public void setAudioIndex(Integer audioIndex) {
    this.audioIndex = audioIndex;
  }

  /**
   **/
  public Tags tags(List<Tag> tags) {
    this.tags = tags;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("tags")
  public List<Tag> getTags() {
    return tags;
  }
  public void setTags(List<Tag> tags) {
    this.tags = tags;
  }

  /**
   **/
  public Tags links(TagsLinks links) {
    this.links = links;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("_links")
  public TagsLinks getLinks() {
    return links;
  }
  public void setLinks(TagsLinks links) {
    this.links = links;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Tags tags = (Tags) o;
    return Objects.equals(status, tags.status) &&
        Objects.equals(audioIndex, tags.audioIndex) &&
        Objects.equals(tags, tags.tags) &&
        Objects.equals(links, tags.links);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, audioIndex, tags, links);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Tags {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    audioIndex: ").append(toIndentedString(audioIndex)).append("\n");
    sb.append("    tags: ").append(toIndentedString(tags)).append("\n");
    sb.append("    links: ").append(toIndentedString(links)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

