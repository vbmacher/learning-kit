package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

public class Tag   {
  
  private Integer audioIndex = null;
  private Integer tagIndex = null;
  private Long offset = null;
  private Long length = null;
  private String text = null;
  private Float confidence = null;
  private Integer channel = null;
  private TagLinks links = null;

  /**
   * Audio segment index owning the tag
   **/
  public Tag audioIndex(Integer audioIndex) {
    this.audioIndex = audioIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Audio segment index owning the tag")
  @JsonProperty("audioIndex")
  public Integer getAudioIndex() {
    return audioIndex;
  }
  public void setAudioIndex(Integer audioIndex) {
    this.audioIndex = audioIndex;
  }

  /**
   * Unique tag index withing all tags for the audio segment.
   **/
  public Tag tagIndex(Integer tagIndex) {
    this.tagIndex = tagIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Unique tag index withing all tags for the audio segment.")
  @JsonProperty("tagIndex")
  public Integer getTagIndex() {
    return tagIndex;
  }
  public void setTagIndex(Integer tagIndex) {
    this.tagIndex = tagIndex;
  }

  /**
   * Time offset relative to the audio segment when the tag starts, in milliseconds.
   **/
  public Tag offset(Long offset) {
    this.offset = offset;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Time offset relative to the audio segment when the tag starts, in milliseconds.")
  @JsonProperty("offset")
  public Long getOffset() {
    return offset;
  }
  public void setOffset(Long offset) {
    this.offset = offset;
  }

  /**
   * Length of the tag, in milliseconds.
   **/
  public Tag length(Long length) {
    this.length = length;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Length of the tag, in milliseconds.")
  @JsonProperty("length")
  public Long getLength() {
    return length;
  }
  public void setLength(Long length) {
    this.length = length;
  }

  /**
   * Text of the tag.
   **/
  public Tag text(String text) {
    this.text = text;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Text of the tag.")
  @JsonProperty("text")
  public String getText() {
    return text;
  }
  public void setText(String text) {
    this.text = text;
  }

  /**
   * Speech-recognizing confidence of the tag (percentage).
   **/
  public Tag confidence(Float confidence) {
    this.confidence = confidence;
    return this;
  }

  
  @ApiModelProperty(value = "Speech-recognizing confidence of the tag (percentage).")
  @JsonProperty("confidence")
  public Float getConfidence() {
    return confidence;
  }
  public void setConfidence(Float confidence) {
    this.confidence = confidence;
  }

  /**
   * Channel number within the audio segment
   **/
  public Tag channel(Integer channel) {
    this.channel = channel;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Channel number within the audio segment")
  @JsonProperty("channel")
  public Integer getChannel() {
    return channel;
  }
  public void setChannel(Integer channel) {
    this.channel = channel;
  }

  /**
   **/
  public Tag links(TagLinks links) {
    this.links = links;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("_links")
  public TagLinks getLinks() {
    return links;
  }
  public void setLinks(TagLinks links) {
    this.links = links;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Tag tag = (Tag) o;
    return Objects.equals(audioIndex, tag.audioIndex) &&
        Objects.equals(tagIndex, tag.tagIndex) &&
        Objects.equals(offset, tag.offset) &&
        Objects.equals(length, tag.length) &&
        Objects.equals(text, tag.text) &&
        Objects.equals(confidence, tag.confidence) &&
        Objects.equals(channel, tag.channel) &&
        Objects.equals(links, tag.links);
  }

  @Override
  public int hashCode() {
    return Objects.hash(audioIndex, tagIndex, offset, length, text, confidence, channel, links);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Tag {\n");
    
    sb.append("    audioIndex: ").append(toIndentedString(audioIndex)).append("\n");
    sb.append("    tagIndex: ").append(toIndentedString(tagIndex)).append("\n");
    sb.append("    offset: ").append(toIndentedString(offset)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("    text: ").append(toIndentedString(text)).append("\n");
    sb.append("    confidence: ").append(toIndentedString(confidence)).append("\n");
    sb.append("    channel: ").append(toIndentedString(channel)).append("\n");
    sb.append("    links: ").append(toIndentedString(links)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

