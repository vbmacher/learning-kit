package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

public class InteractionLinks   {
  
  private String self = null;
  private String audio = null;
  private String tags = null;
  private String screen = null;
  private String video = null;

  /**
   * URI to get this interaction metadata
   **/
  public InteractionLinks self(String self) {
    this.self = self;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get this interaction metadata")
  @JsonProperty("self")
  public String getSelf() {
    return self;
  }
  public void setSelf(String self) {
    this.self = self;
  }

  /**
   * URI to get mixed audio segments metadata
   **/
  public InteractionLinks audio(String audio) {
    this.audio = audio;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get mixed audio segments metadata")
  @JsonProperty("audio")
  public String getAudio() {
    return audio;
  }
  public void setAudio(String audio) {
    this.audio = audio;
  }

  /**
   * URI to get tags for the audio segment
   **/
  public InteractionLinks tags(String tags) {
    this.tags = tags;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get tags for the audio segment")
  @JsonProperty("tags")
  public String getTags() {
    return tags;
  }
  public void setTags(String tags) {
    this.tags = tags;
  }

  /**
   * URI to get screen segment metadata
   **/
  public InteractionLinks screen(String screen) {
    this.screen = screen;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get screen segment metadata")
  @JsonProperty("screen")
  public String getScreen() {
    return screen;
  }
  public void setScreen(String screen) {
    this.screen = screen;
  }

  /**
   * URI to get video segment metadata
   **/
  public InteractionLinks video(String video) {
    this.video = video;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get video segment metadata")
  @JsonProperty("video")
  public String getVideo() {
    return video;
  }
  public void setVideo(String video) {
    this.video = video;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InteractionLinks interactionLinks = (InteractionLinks) o;
    return Objects.equals(self, interactionLinks.self) &&
        Objects.equals(audio, interactionLinks.audio) &&
        Objects.equals(tags, interactionLinks.tags) &&
        Objects.equals(screen, interactionLinks.screen) &&
        Objects.equals(video, interactionLinks.video);
  }

  @Override
  public int hashCode() {
    return Objects.hash(self, audio, tags, screen, video);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InteractionLinks {\n");
    
    sb.append("    self: ").append(toIndentedString(self)).append("\n");
    sb.append("    audio: ").append(toIndentedString(audio)).append("\n");
    sb.append("    tags: ").append(toIndentedString(tags)).append("\n");
    sb.append("    screen: ").append(toIndentedString(screen)).append("\n");
    sb.append("    video: ").append(toIndentedString(video)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

