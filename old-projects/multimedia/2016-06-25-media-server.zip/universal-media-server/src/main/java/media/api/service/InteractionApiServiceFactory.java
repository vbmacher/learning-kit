package media.api.service;


import media.api.InteractionApiService;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-06-25T07:24:19.462Z")
public class InteractionApiServiceFactory {

   private final static InteractionApiService service = new InteractionApiServiceImpl();

   public static InteractionApiService getInteractionApi()
   {
      return service;
   }
}
