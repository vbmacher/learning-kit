package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

public class InteractionScreenSegments   {
  
  private Integer screenIndex = null;
  private Integer offset = null;
  private Integer length = null;

  /**
   * Screen segment unique index.
   **/
  public InteractionScreenSegments screenIndex(Integer screenIndex) {
    this.screenIndex = screenIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Screen segment unique index.")
  @JsonProperty("screenIndex")
  public Integer getScreenIndex() {
    return screenIndex;
  }
  public void setScreenIndex(Integer screenIndex) {
    this.screenIndex = screenIndex;
  }

  /**
   * Absolute time offset within the interaction, in milliseconds
   **/
  public InteractionScreenSegments offset(Integer offset) {
    this.offset = offset;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Absolute time offset within the interaction, in milliseconds")
  @JsonProperty("offset")
  public Integer getOffset() {
    return offset;
  }
  public void setOffset(Integer offset) {
    this.offset = offset;
  }

  /**
   * Length of the segment in milliseconds
   **/
  public InteractionScreenSegments length(Integer length) {
    this.length = length;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Length of the segment in milliseconds")
  @JsonProperty("length")
  public Integer getLength() {
    return length;
  }
  public void setLength(Integer length) {
    this.length = length;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InteractionScreenSegments interactionScreenSegments = (InteractionScreenSegments) o;
    return Objects.equals(screenIndex, interactionScreenSegments.screenIndex) &&
        Objects.equals(offset, interactionScreenSegments.offset) &&
        Objects.equals(length, interactionScreenSegments.length);
  }

  @Override
  public int hashCode() {
    return Objects.hash(screenIndex, offset, length);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InteractionScreenSegments {\n");
    
    sb.append("    screenIndex: ").append(toIndentedString(screenIndex)).append("\n");
    sb.append("    offset: ").append(toIndentedString(offset)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

