package media.api;

import io.swagger.annotations.ApiParam;
import media.api.exceptions.NotFoundException;
import media.model.Audio;
import media.model.ErrorModel;
import media.model.Interaction;
import media.model.Tag;
import media.model.Tags;
import media.model.Waveform;
import media.api.service.InteractionApiServiceFactory;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@Path("/interaction")
@Consumes({ "application/vnd.com.zoomint.mediaapi.v1+json" })
@Produces({ "application/json" })
@io.swagger.annotations.Api(description = "the interaction API")
public class InteractionApi  {
   private final InteractionApiService delegate = InteractionApiServiceFactory.getInteractionApi();

    @POST
    @Path("/{id}/audio/{audioIndex}/tags")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Insert new tag to given audio segment", response = Tag.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 201, message = "The tag was created", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Either the interaction, or audio segment has not been found.", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = Tag.class) })
    public Response createAudioTag(
        @ApiParam(value = "Implementation-specific identification of the interaction",required=true) @PathParam("id") String id,
        @ApiParam(value = "Index of the audio segment of the interaction",required=true) @PathParam("audioIndex") Integer audioIndex,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.createAudioTag(id,audioIndex,securityContext);
    }
    @GET
    @Path("/{id}/audio/{audioIndexes}")
    @Consumes({ "application/vnd.com.zoomint.mediaapi.v1+json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Returns metadata for given audio segments which will be mixed together, all within one particular interaction.", response = Audio.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "JSON with the \\\"mixage\\\" of given audio segments.", response = Audio.class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = Audio.class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = Audio.class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = Audio.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Interaction or some/all of provided audio segment indexes have not been found.", response = Audio.class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = Audio.class) })
    public Response getAudioMetadata(
        @ApiParam(value = "Implementation-specific identification of the interaction",required=true) @PathParam("id") String id,
        @ApiParam(value = "Dash-separated audio segment indexes for mixing (e.g. `0-1-2`).",required=true) @PathParam("audioIndexes") String audioIndexes,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getAudioMetadata(id,audioIndexes,securityContext);
    }
    @GET
    @Path("/{id}/audio/{audioIndexes}/stream/{chunkIndex}")
    @Consumes({ "audio/mpeg", "audio/wav" })
    @Produces({ "audio/mpeg", "audio/wav" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Returns a chunk of mixed stream of given audio segments. Offset and number of chunks can be easily computed. Time offset of the chunk is `offset = chunkLength * chunkIndex`, number of chunks is `chunks = ceil(segmentLength / chunkLength)`. Be aware of the length of the last chunk, which is `lastChunkLength = segmentLength - ((chunks - 1) * chunkLength)`.", response = byte[].class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "Requested audio stream. Be aware of the content-type.", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "One of the interaction, some/all of provided segment indexes, or chunk index has not been found.", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = byte[].class) })
    public Response getAudioStream(
        @ApiParam(value = "Implementation-specific identification of the interaction",required=true) @PathParam("id") String id,
        @ApiParam(value = "Dash-separated audio segment indexes for mixing (e.g. `0-1-2`).",required=true) @PathParam("audioIndexes") String audioIndexes,
        @ApiParam(value = "Chunk index, starting from 0.",required=true) @PathParam("chunkIndex") Integer chunkIndex,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getAudioStream(id,audioIndexes,chunkIndex,securityContext);
    }
    @GET
    @Path("/{id}/audio/{audioIndex}/tag/{tagIndex}")
    @Consumes({ "application/vnd.com.zoomint.mediaapi.v1+json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Returns a tag metadata.", response = Tag.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "JSON of the tag metadata", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "One of the interaction, audio segment, or tag index has not been found.", response = Tag.class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = Tag.class) })
    public Response getAudioTag(
        @ApiParam(value = "Implementation-specific identification of the interaction",required=true) @PathParam("id") String id,
        @ApiParam(value = "Index of the audio segment of the interaction",required=true) @PathParam("audioIndex") Integer audioIndex,
        @ApiParam(value = "Tag index within all tags of given audio segment",required=true) @PathParam("tagIndex") Integer tagIndex,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getAudioTag(id,audioIndex,tagIndex,securityContext);
    }
    @GET
    @Path("/{id}/audio/{audioIndex}/tag/{tagIndex}/icon")
    @Consumes({ "application/vnd.com.zoomint.mediaapi.v1+json" })
    @Produces({ "image/png" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Returns a tag icon.", response = byte[].class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "PNG stream of the tag icon", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "One of the interaction, audio segment, or tag index has not been found.", response = byte[].class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = byte[].class) })
    public Response getAudioTagIcon(
        @ApiParam(value = "Implementation-specific identification of the interaction",required=true) @PathParam("id") String id,
        @ApiParam(value = "Index of the audio segment of the interaction",required=true) @PathParam("audioIndex") Integer audioIndex,
        @ApiParam(value = "Tag index within all tags of given audio segment",required=true) @PathParam("tagIndex") Integer tagIndex,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getAudioTagIcon(id,audioIndex,tagIndex,securityContext);
    }
    @GET
    @Path("/{id}/audio/{audioIndex}/tags")
    @Consumes({ "application/vnd.com.zoomint.mediaapi.v1+json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Returns all tags of given audio segment.", response = Tags.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "JSON of all tags for given audio segment", response = Tags.class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = Tags.class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = Tags.class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = Tags.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Either the interaction, or audio segment has not been found.", response = Tags.class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = Tags.class) })
    public Response getAudioTags(
        @ApiParam(value = "Implementation-specific identification of the interaction",required=true) @PathParam("id") String id,
        @ApiParam(value = "Index of the audio segment within the interaction",required=true) @PathParam("audioIndex") Integer audioIndex,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getAudioTags(id,audioIndex,securityContext);
    }
    @GET
    @Path("/{id}/audio/{audioIndexes}/waveform")
    @Consumes({ "application/vnd.com.zoomint.mediaapi.v1+json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Returns waveforms of all given audio segments mixed together. The waveforms for particular segment chunks are already normalized. The waveforms always start at time 0, they must be aligned to already known offsets of particular audio segments.", response = Waveform.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "Waveforms values for given interaction and audio segments.", response = Waveform.class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = Waveform.class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = Waveform.class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = Waveform.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Either the interaction or some/all of provided audio segments have not been found.", response = Waveform.class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = Waveform.class) })
    public Response getAudioWaveform(
        @ApiParam(value = "Implementation-specific identification of the interaction",required=true) @PathParam("id") String id,
        @ApiParam(value = "Dash-separated audio segment indexes for mixing (e.g. `0-1-2`).",required=true) @PathParam("audioIndexes") String audioIndexes,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getAudioWaveform(id,audioIndexes,securityContext);
    }
    @GET
    @Path("/{id}")
    @Consumes({ "application/vnd.com.zoomint.mediaapi.v1+json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Returns the interaction metadata. It is the starting point of the client-server communication, initiated by the client.", response = Interaction.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "JSON with the interaction metadata (including operations).", response = Interaction.class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = Interaction.class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = Interaction.class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = Interaction.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "The interaction has not been found", response = Interaction.class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = Interaction.class) })
    public Response getInteractionMetadata(
        @ApiParam(value = "Implementation-specific identification of the interaction (e.g. a recorded call, or local media files, etc.).",required=true) @PathParam("id") String id,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getInteractionMetadata(id,securityContext);
    }
    @GET
    @Path("/{id}/screen/{screenIndex}")
    @Consumes({ "application/vnd.com.zoomint.mediaapi.v1+json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "Opens a WebSocket connection (or its emulation) to retrieve RECD stream.", response = ErrorModel.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "apikey")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 101, message = "WebSocket connection has been established. Now RECD stream can be sent in WebSocket frames.", response = ErrorModel.class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Given URL is malformed, or not parseable", response = ErrorModel.class),
        @io.swagger.annotations.ApiResponse(code = 401, message = "OAuth2 token is not provided in the request", response = ErrorModel.class),
        @io.swagger.annotations.ApiResponse(code = 403, message = "OAuth2 token is invalid/unknown", response = ErrorModel.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Either interaction, or screen segment has not been found.", response = ErrorModel.class),
        @io.swagger.annotations.ApiResponse(code = 200, message = "unexpected error", response = ErrorModel.class) })
    public Response getScreen(
        @ApiParam(value = "Implementation-specific identification of the interaction",required=true) @PathParam("id") String id,
        @ApiParam(value = "Screen segment index within the interaction",required=true) @PathParam("screenIndex") Integer screenIndex,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getScreen(id,screenIndex,securityContext);
    }
}
