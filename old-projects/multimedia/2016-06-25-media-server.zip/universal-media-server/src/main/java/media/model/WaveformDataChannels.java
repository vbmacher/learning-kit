package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class WaveformDataChannels   {
  
  private List<Integer> data = new ArrayList<Integer>();
  private Integer channel = null;

  /**
   **/
  public WaveformDataChannels data(List<Integer> data) {
    this.data = data;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("data")
  public List<Integer> getData() {
    return data;
  }
  public void setData(List<Integer> data) {
    this.data = data;
  }

  /**
   * Channel number within the audio segment \\\"mixage\\\".
   **/
  public WaveformDataChannels channel(Integer channel) {
    this.channel = channel;
    return this;
  }

  
  @ApiModelProperty(value = "Channel number within the audio segment \\\"mixage\\\".")
  @JsonProperty("channel")
  public Integer getChannel() {
    return channel;
  }
  public void setChannel(Integer channel) {
    this.channel = channel;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    WaveformDataChannels waveformDataChannels = (WaveformDataChannels) o;
    return Objects.equals(data, waveformDataChannels.data) &&
        Objects.equals(channel, waveformDataChannels.channel);
  }

  @Override
  public int hashCode() {
    return Objects.hash(data, channel);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class WaveformDataChannels {\n");
    
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    channel: ").append(toIndentedString(channel)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

