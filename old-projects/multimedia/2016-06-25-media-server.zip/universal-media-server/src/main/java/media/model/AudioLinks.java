package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

public class AudioLinks   {
  
  private String self = null;
  private String interaction = null;
  private String waveform = null;
  private String stream = null;

  /**
   * URI to get this audio \\\"mixage\\\" metadata
   **/
  public AudioLinks self(String self) {
    this.self = self;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get this audio \\\"mixage\\\" metadata")
  @JsonProperty("self")
  public String getSelf() {
    return self;
  }
  public void setSelf(String self) {
    this.self = self;
  }

  /**
   * URI to get interaction metadata (root)
   **/
  public AudioLinks interaction(String interaction) {
    this.interaction = interaction;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get interaction metadata (root)")
  @JsonProperty("interaction")
  public String getInteraction() {
    return interaction;
  }
  public void setInteraction(String interaction) {
    this.interaction = interaction;
  }

  /**
   * URI to get waveform for selected audio chunk.
   **/
  public AudioLinks waveform(String waveform) {
    this.waveform = waveform;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get waveform for selected audio chunk.")
  @JsonProperty("waveform")
  public String getWaveform() {
    return waveform;
  }
  public void setWaveform(String waveform) {
    this.waveform = waveform;
  }

  /**
   * URI to get selected audio chunk stream.
   **/
  public AudioLinks stream(String stream) {
    this.stream = stream;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "URI to get selected audio chunk stream.")
  @JsonProperty("stream")
  public String getStream() {
    return stream;
  }
  public void setStream(String stream) {
    this.stream = stream;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AudioLinks audioLinks = (AudioLinks) o;
    return Objects.equals(self, audioLinks.self) &&
        Objects.equals(interaction, audioLinks.interaction) &&
        Objects.equals(waveform, audioLinks.waveform) &&
        Objects.equals(stream, audioLinks.stream);
  }

  @Override
  public int hashCode() {
    return Objects.hash(self, interaction, waveform, stream);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AudioLinks {\n");
    
    sb.append("    self: ").append(toIndentedString(self)).append("\n");
    sb.append("    interaction: ").append(toIndentedString(interaction)).append("\n");
    sb.append("    waveform: ").append(toIndentedString(waveform)).append("\n");
    sb.append("    stream: ").append(toIndentedString(stream)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

