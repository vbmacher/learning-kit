package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Interaction   {
  
  private String status = null;
  private Integer chunkLength = null;
  private List<InteractionAudioSegments> audio = new ArrayList<>();
  private List<InteractionScreenSegments> screen = new ArrayList<>();
  private List<InteractionVideoSegments> video = new ArrayList<>();
  private InteractionLinks links = null;

  /**
   * \\\"OK\\\" or error enumeration value in case of error
   **/
  public Interaction status(String status) {
    this.status = status;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "\\\"OK\\\" or error enumeration value in case of error")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Audio chunk length in milliseconds (possibly except the last chunk)
   **/
  public Interaction chunkLength(Integer chunkLength) {
    this.chunkLength = chunkLength;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Audio chunk length in milliseconds (possibly except the last chunk)")
  @JsonProperty("chunkLength")
  public Integer getChunkLength() {
    return chunkLength;
  }
  public void setChunkLength(Integer chunkLength) {
    this.chunkLength = chunkLength;
  }

  /**
   * Array of audio segments
   **/
  public Interaction audio(List<InteractionAudioSegments> audio) {
    this.audio = audio;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Array of audio segments")
  @JsonProperty("audio")
  public List<InteractionAudioSegments> getAudio() {
    return audio;
  }
  public void setAudio(List<InteractionAudioSegments> audio) {
    this.audio = audio;
  }

  /**
   * Array of screen segments
   **/
  public Interaction screen(List<InteractionScreenSegments> screen) {
    this.screen = screen;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Array of screen segments")
  @JsonProperty("screen")
  public List<InteractionScreenSegments> getScreen() {
    return screen;
  }
  public void setScreen(List<InteractionScreenSegments> screen) {
    this.screen = screen;
  }

  /**
   * Array of video segments
   **/
  public Interaction video(List<InteractionVideoSegments> video) {
    this.video = video;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Array of video segments")
  @JsonProperty("video")
  public List<InteractionVideoSegments> getVideo() {
    return video;
  }
  public void setVideo(List<InteractionVideoSegments> video) {
    this.video = video;
  }

  /**
   **/
  public Interaction links(InteractionLinks links) {
    this.links = links;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("_links")
  public InteractionLinks getLinks() {
    return links;
  }
  public void setLinks(InteractionLinks links) {
    this.links = links;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Interaction interaction = (Interaction) o;
    return Objects.equals(status, interaction.status) &&
        Objects.equals(chunkLength, interaction.chunkLength) &&
        Objects.equals(audio, interaction.audio) &&
        Objects.equals(screen, interaction.screen) &&
        Objects.equals(video, interaction.video) &&
        Objects.equals(links, interaction.links);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, chunkLength, audio, screen, video, links);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Interaction {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    chunkLength: ").append(toIndentedString(chunkLength)).append("\n");
    sb.append("    audio: ").append(toIndentedString(audio)).append("\n");
    sb.append("    screen: ").append(toIndentedString(screen)).append("\n");
    sb.append("    video: ").append(toIndentedString(video)).append("\n");
    sb.append("    links: ").append(toIndentedString(links)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

