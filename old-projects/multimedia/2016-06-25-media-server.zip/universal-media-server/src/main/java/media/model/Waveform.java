package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Waveform   {
  
  private String status = null;
  private Integer waveformColumns = null;
  private List<WaveformData> waveformData = new ArrayList<WaveformData>();
  private WaveformLinks links = null;

  /**
   * \\\"OK\\\" or error enumeration value in case of error
   **/
  public Waveform status(String status) {
    this.status = status;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "\\\"OK\\\" or error enumeration value in case of error")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Number of columns of this waveform chunk
   **/
  public Waveform waveformColumns(Integer waveformColumns) {
    this.waveformColumns = waveformColumns;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Number of columns of this waveform chunk")
  @JsonProperty("waveformColumns")
  public Integer getWaveformColumns() {
    return waveformColumns;
  }
  public void setWaveformColumns(Integer waveformColumns) {
    this.waveformColumns = waveformColumns;
  }

  /**
   **/
  public Waveform waveformData(List<WaveformData> waveformData) {
    this.waveformData = waveformData;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("waveformData")
  public List<WaveformData> getWaveformData() {
    return waveformData;
  }
  public void setWaveformData(List<WaveformData> waveformData) {
    this.waveformData = waveformData;
  }

  /**
   **/
  public Waveform links(WaveformLinks links) {
    this.links = links;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("_links")
  public WaveformLinks getLinks() {
    return links;
  }
  public void setLinks(WaveformLinks links) {
    this.links = links;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Waveform waveform = (Waveform) o;
    return Objects.equals(status, waveform.status) &&
        Objects.equals(waveformColumns, waveform.waveformColumns) &&
        Objects.equals(waveformData, waveform.waveformData) &&
        Objects.equals(links, waveform.links);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, waveformColumns, waveformData, links);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Waveform {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    waveformColumns: ").append(toIndentedString(waveformColumns)).append("\n");
    sb.append("    waveformData: ").append(toIndentedString(waveformData)).append("\n");
    sb.append("    links: ").append(toIndentedString(links)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

