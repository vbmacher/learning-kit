package media.api;

import media.api.exceptions.NotFoundException;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

public abstract class InteractionApiService {
      public abstract Response createAudioTag(String id,Integer audioIndex,SecurityContext securityContext)
      throws NotFoundException;
      public abstract Response getAudioMetadata(String id,String audioIndexes,SecurityContext securityContext)
      throws NotFoundException;
      public abstract Response getAudioStream(String id,String audioIndexes,Integer chunkIndex,SecurityContext securityContext)
      throws NotFoundException;
      public abstract Response getAudioTag(String id,Integer audioIndex,Integer tagIndex,SecurityContext securityContext)
      throws NotFoundException;
      public abstract Response getAudioTagIcon(String id,Integer audioIndex,Integer tagIndex,SecurityContext securityContext)
      throws NotFoundException;
      public abstract Response getAudioTags(String id,Integer audioIndex,SecurityContext securityContext)
      throws NotFoundException;
      public abstract Response getAudioWaveform(String id,String audioIndexes,SecurityContext securityContext)
      throws NotFoundException;
      public abstract Response getInteractionMetadata(String id,SecurityContext securityContext)
      throws NotFoundException;
      public abstract Response getScreen(String id,Integer screenIndex,SecurityContext securityContext)
      throws NotFoundException;
}
