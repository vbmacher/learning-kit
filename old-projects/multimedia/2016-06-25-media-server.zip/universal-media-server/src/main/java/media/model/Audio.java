package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Audio   {
  
  private String status = null;
  private Long offset = null;
  private Long length = null;
  private List<Integer> audioIndexes = new ArrayList<Integer>();
  private AudioLinks links = null;

  /**
   * \\\"OK\\\" or error enumeration value in case of error
   **/
  public Audio status(String status) {
    this.status = status;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "\\\"OK\\\" or error enumeration value in case of error")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Relative offset from the beginning of the interaction, in milliseconds
   **/
  public Audio offset(Long offset) {
    this.offset = offset;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Relative offset from the beginning of the interaction, in milliseconds")
  @JsonProperty("offset")
  public Long getOffset() {
    return offset;
  }
  public void setOffset(Long offset) {
    this.offset = offset;
  }

  /**
   * Length of the audio \\\"mixage\\\" in milliseconds
   **/
  public Audio length(Long length) {
    this.length = length;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Length of the audio \\\"mixage\\\" in milliseconds")
  @JsonProperty("length")
  public Long getLength() {
    return length;
  }
  public void setLength(Long length) {
    this.length = length;
  }

  /**
   * Array of used audio segments within this \\\"mixage\\\"
   **/
  public Audio audioIndexes(List<Integer> audioIndexes) {
    this.audioIndexes = audioIndexes;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Array of used audio segments within this \\\"mixage\\\"")
  @JsonProperty("audioIndexes")
  public List<Integer> getAudioIndexes() {
    return audioIndexes;
  }
  public void setAudioIndexes(List<Integer> audioIndexes) {
    this.audioIndexes = audioIndexes;
  }

  /**
   **/
  public Audio links(AudioLinks links) {
    this.links = links;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("_links")
  public AudioLinks getLinks() {
    return links;
  }
  public void setLinks(AudioLinks links) {
    this.links = links;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Audio audio = (Audio) o;
    return Objects.equals(status, audio.status) &&
        Objects.equals(offset, audio.offset) &&
        Objects.equals(length, audio.length) &&
        Objects.equals(audioIndexes, audio.audioIndexes) &&
        Objects.equals(links, audio.links);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, offset, length, audioIndexes, links);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Audio {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    offset: ").append(toIndentedString(offset)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("    audioIndexes: ").append(toIndentedString(audioIndexes)).append("\n");
    sb.append("    links: ").append(toIndentedString(links)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

