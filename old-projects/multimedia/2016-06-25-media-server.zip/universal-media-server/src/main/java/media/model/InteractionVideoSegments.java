package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

public class InteractionVideoSegments   {
  
  private Integer videoIndex = null;
  private Integer offset = null;
  private Integer length = null;

  /**
   * Video segment unique index.
   **/
  public InteractionVideoSegments videoIndex(Integer videoIndex) {
    this.videoIndex = videoIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Video segment unique index.")
  @JsonProperty("videoIndex")
  public Integer getVideoIndex() {
    return videoIndex;
  }
  public void setVideoIndex(Integer videoIndex) {
    this.videoIndex = videoIndex;
  }

  /**
   * Absolute time offset within the interaction, in milliseconds
   **/
  public InteractionVideoSegments offset(Integer offset) {
    this.offset = offset;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Absolute time offset within the interaction, in milliseconds")
  @JsonProperty("offset")
  public Integer getOffset() {
    return offset;
  }
  public void setOffset(Integer offset) {
    this.offset = offset;
  }

  /**
   * Length of the segment in milliseconds
   **/
  public InteractionVideoSegments length(Integer length) {
    this.length = length;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Length of the segment in milliseconds")
  @JsonProperty("length")
  public Integer getLength() {
    return length;
  }
  public void setLength(Integer length) {
    this.length = length;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InteractionVideoSegments interactionVideoSegments = (InteractionVideoSegments) o;
    return Objects.equals(videoIndex, interactionVideoSegments.videoIndex) &&
        Objects.equals(offset, interactionVideoSegments.offset) &&
        Objects.equals(length, interactionVideoSegments.length);
  }

  @Override
  public int hashCode() {
    return Objects.hash(videoIndex, offset, length);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InteractionVideoSegments {\n");
    
    sb.append("    videoIndex: ").append(toIndentedString(videoIndex)).append("\n");
    sb.append("    offset: ").append(toIndentedString(offset)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

