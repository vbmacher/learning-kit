package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

public class InteractionAudioSegments   {
  
  private Integer audioIndex = null;
  private Integer offset = null;
  private Integer length = null;

  /**
   * Audio segment unique index.
   **/
  public InteractionAudioSegments audioIndex(Integer audioIndex) {
    this.audioIndex = audioIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Audio segment unique index.")
  @JsonProperty("audioIndex")
  public Integer getAudioIndex() {
    return audioIndex;
  }
  public void setAudioIndex(Integer audioIndex) {
    this.audioIndex = audioIndex;
  }

  /**
   * Absolute time offset within the interaction, in milliseconds
   **/
  public InteractionAudioSegments offset(Integer offset) {
    this.offset = offset;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Absolute time offset within the interaction, in milliseconds")
  @JsonProperty("offset")
  public Integer getOffset() {
    return offset;
  }
  public void setOffset(Integer offset) {
    this.offset = offset;
  }

  /**
   * Length of the segment in milliseconds
   **/
  public InteractionAudioSegments length(Integer length) {
    this.length = length;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Length of the segment in milliseconds")
  @JsonProperty("length")
  public Integer getLength() {
    return length;
  }
  public void setLength(Integer length) {
    this.length = length;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InteractionAudioSegments interactionAudioSegments = (InteractionAudioSegments) o;
    return Objects.equals(audioIndex, interactionAudioSegments.audioIndex) &&
        Objects.equals(offset, interactionAudioSegments.offset) &&
        Objects.equals(length, interactionAudioSegments.length);
  }

  @Override
  public int hashCode() {
    return Objects.hash(audioIndex, offset, length);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InteractionAudioSegments {\n");
    
    sb.append("    audioIndex: ").append(toIndentedString(audioIndex)).append("\n");
    sb.append("    offset: ").append(toIndentedString(offset)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

