package media.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class WaveformData   {
  
  private Integer audioIndex = null;
  private List<WaveformDataChannels> channels = new ArrayList<WaveformDataChannels>();

  /**
   * Audio segment index within the interaction.
   **/
  public WaveformData audioIndex(Integer audioIndex) {
    this.audioIndex = audioIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "Audio segment index within the interaction.")
  @JsonProperty("audioIndex")
  public Integer getAudioIndex() {
    return audioIndex;
  }
  public void setAudioIndex(Integer audioIndex) {
    this.audioIndex = audioIndex;
  }

  /**
   **/
  public WaveformData channels(List<WaveformDataChannels> channels) {
    this.channels = channels;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("channels")
  public List<WaveformDataChannels> getChannels() {
    return channels;
  }
  public void setChannels(List<WaveformDataChannels> channels) {
    this.channels = channels;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    WaveformData waveformData = (WaveformData) o;
    return Objects.equals(audioIndex, waveformData.audioIndex) &&
        Objects.equals(channels, waveformData.channels);
  }

  @Override
  public int hashCode() {
    return Objects.hash(audioIndex, channels);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class WaveformData {\n");
    
    sb.append("    audioIndex: ").append(toIndentedString(audioIndex)).append("\n");
    sb.append("    channels: ").append(toIndentedString(channels)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

