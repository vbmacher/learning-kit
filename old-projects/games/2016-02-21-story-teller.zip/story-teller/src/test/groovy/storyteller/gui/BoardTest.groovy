package storyteller.gui

import org.easymock.*;
import static org.easymock.EasyMock.*;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener

class BoardTest extends GroovyTestCase {

    void testSetRoom() {
/*        Room room  = createNiceMock(Room.class)
        room.addMouseMotionListener(EasyMock.<MouseMotionListener>anyObject())
        expectLastCall().once()
        room.addMouseListener(EasyMock.<MouseListener>anyObject())
        expectLastCall().once()
        replay(room)

        def canvas = new RoomCanvas(room)

        verify(room)*/
    }
}

