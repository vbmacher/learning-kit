package storyteller.rooms

import storyteller.gui.RoomComponent

class GameRoom extends RoomComponent {

    public GameRoom(room, board) {
        super(room, board)
    }

}

