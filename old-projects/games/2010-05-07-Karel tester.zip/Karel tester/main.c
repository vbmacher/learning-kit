#include <stdio.h>
#include "karel.h"

/**** POMOCNE FUNKCIE *****/
void turnRight() {
  turnLeft();
  turnLeft();
  turnLeft();  
}

void turnAround() {
  turnLeft();
  turnLeft();  
}

// zisti, ci sme v okne. Vrati 1 ak nie sme, 0 ak sme.
// Okno je povazovane ako priestor v stene o velkosti 1, kde nie je beeper
int not_window() {
  int nw = 1;
  if (rightIsClear() && frontIsClear()) {
    movek();
    if (rightIsBlocked()) {
      // je to okno
      turnAround();
      movek();
      turnAround();
      nw = 0;
    } else {
      turnAround();
      movek();
      turnAround();
    }
  } else if (rightIsClear() && frontIsBlocked())
    nw = 0;  
  return nw;
}

// vracia 1 ak karol nie je vo vchodovych dverach, inak 0
int not_home() {
  if (beepersPresent()) {
    pickBeeper();
    turnRight();
    return 0;
  }
  return 1;
}

/**********************************************************************/

// zatvori okno, ak v pravo od karla nejake je
// ak viem ze tam je okno, tak window=2, aby zbytocne
// nehatil...
void closeWindow() {
  turnRight();
  movek();
  if (noBeepersPresent())
    putBeeper();
  turnAround();
  movek();
  turnRight();
}

int main(){
  turnOn("18-c-in.kw");
  
  setStepDelay(0);
  
// system("pause");
/*  putBeeper(); // vchodove dvere oznacim beeperom

  // a ideme...
  int window = 0;
  do {
    if ((window == 2) || !not_window()) {
      closeWindow();
      // pohne sa dalej
      while (frontIsBlocked())
        turnLeft();
      movek();
    }
    if (rightIsClear() && not_window()) {
      turnRight();
      movek();
    }
    while (frontIsBlocked())
      turnLeft();
    movek();
  } while (window = not_home());*/
    
  turnOff();

  return 0;
}
