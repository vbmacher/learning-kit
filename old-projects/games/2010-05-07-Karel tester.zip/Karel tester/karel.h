/*
 * karol.h
 *
 *  Created on: 9.1.2010
 *      Author: mirek
 *  $Id: karel.h 36 2010-02-28 13:55:05Z mirek $
 */

#ifndef KAROL_H_
#define KAROL_H_

#define MAX_WIDTH   30
#define MAX_HEIGHT  30

#define VERSION 0.1

#define WINDOWS

#ifdef LINUX
    #define MULTIPLIER 1000
#else
    #define MULTIPLIER 1
#endif


typedef enum DIRECTION{
    EAST = 0,
    NORTH = 90,
    WEST = 180,
    SOUTH = 270
} Direction;

typedef enum BLOCK {
    CLEAR,
    WALL = 9
} Block;

typedef struct WORLD{
    int width, height;
    int map[MAX_WIDTH][MAX_HEIGHT];
} World;

World world;

typedef struct ROBOT{
    int posX, posY;
    int oldPosX, oldPosY;
    Direction direction;
    int steps;
    int beepers;
    int isOn;
    char lastCommand[10];
} Robot;

Robot karel;

// primitives
void movek();
void turnLeft();
void turnOn( char* path );
void turnOff();

void putBeeper();
void pickBeeper();

// sensors
int beepersPresent();
int noBeepersPresent();
int beepersInBag();
int noBeepersInBag();

int frontIsClear();
int frontIsBlocked();
int leftIsClear();
int leftIsBlocked();
int rightIsClear();
int rightIsBlocked();

int facingNorth();
int notFacingNorth();
int facingEast();
int notFacingEast();
int facingWest();
int notFacingWest();
int facingSouth();
int notFacingSouth();

// misc
void setStepDelay( int delay );
int getStepDelay();

//void draw();
//void redraw();

#endif /* KAROL_H_ */
