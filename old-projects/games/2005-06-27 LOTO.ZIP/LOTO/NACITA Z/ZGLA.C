/*
   GLA.C
   (c) Copyright 2005, Peter Jakubco

   max. 496 - sestiek bez opakovania trojak sa da dosiahnut
   1442 - vsetky sestky aj s opakovanim, nepouzite ostavaju 1642

   � - 218
   � - 196
   � - 194
   � - 195
   � - 191
   � - 179
   � - 193
   � - 180
   � - 192
   � - 217

*/

#include <stdio.h>
#include <conio.h>

#define MAX 49
#define MAX_tr 20020
#define MAX_nep 10000
#define MAX_se 5000

// video
#define LCx 1
#define LCy 1

// pocet3
#define P3x (LCx+2)
#define P3y (LCy+1)

// pocet6
#define P6x (LCx+16)
#define P6y (LCy+1)

// pocet3n
#define P3nx (LCx+30)
#define P3ny (LCy+1)

// faza
#define Fx (LCx+2)
#define Fy (LCy+3)

// popis
#define LAx (LCx+2)
#define LAy (LCy+6)

// 6-tica
#define Sx (LCx+16)
#define Sy (LCy+3)

typedef unsigned char byte;

typedef struct {
  byte cislo[3];
} trojica;

typedef struct {
  byte cislo[6];
} sestica;

// prototypy funkcii
void nepouzite3();
void vymaz3(trojica*,int,int);

trojica huge trojice[MAX_tr];
trojica huge ntrojice[MAX_nep];
sestica huge sestice[MAX_se];

int pocet3;  // index novej trojice - cize pocet trojic
int pocet3n;
int pocet6;
int index_o; // index trojic, odkadial sa zacinaju opakovat

/* docasna pamat
   ~~~~~~~~~~~~~
   Do nej sa ukladaju trojice ktore obsahuje aktualna sestica. Pomocou
   nej sa tak da porovnat, ci jedna sestica neobsahuje tie iste trojice.
   Pamat sa pouziva pri vytvarani sestic
*/
trojica strojice[20];

void kresli_menu()
{
 int i;
 gotoxy(LCx,LCy);
 printf("��� Pocet 3 ����� Pocet 6 ����� Pocet nep. 3 �Ŀ");
 gotoxy(LCx,LCy+1);
 printf("�             �             �                  �");
 gotoxy(LCx,LCy+2);
 printf("��� Faza �������������������������������������Ĵ");
 gotoxy(LCx,LCy+3);
 printf("�             �                                �");
 gotoxy(LCx,LCy+4);
 printf("������������������������������������������������");
 gotoxy(LCx,LCy+5);
 printf("��� Popis cinnosti ���������������������������Ŀ");
 gotoxy(LCx,LCy+6);
 printf("�                                              �");
 gotoxy(LCx,LCy+7);
 printf("������������������������������������������������");
}


// fcia vymaze trojku na pozicii index
void vymaz3(trojica *tr, int index, int mMAX)
{
  int i;
  for (i = index; i < (mMAX-1); i++) {
    tr[i].cislo[0] = tr[i+1].cislo[0];
    tr[i].cislo[1] = tr[i+1].cislo[1];
    tr[i].cislo[2] = tr[i+1].cislo[2];
  }
  tr[i].cislo[0] = 0;
  tr[i].cislo[1] = 0;
  tr[i].cislo[2] = 0;
}

// fcia vymaze opakujuce sa trojky v databaze
void vymaz_opak()
{
  int i,j,l;
  byte m,n,o;
  for (i = 0; (i < MAX_tr) && (trojice[i].cislo[0]); i++) {
    m = trojice[i].cislo[0];
    n = trojice[i].cislo[1];
    o = trojice[i].cislo[2];
    for (j = i+1; (j < MAX_tr) && (trojice[j].cislo[0]); j++)
      if ((m == trojice[j].cislo[0]) || (m == trojice[j].cislo[1]) || (m == trojice[j].cislo[2]))
	if ((n == trojice[j].cislo[0]) || (n == trojice[j].cislo[1]) || (n == trojice[j].cislo[2]))
	  if ((o == trojice[j].cislo[0]) || (o == trojice[j].cislo[1]) || (o == trojice[j].cislo[2])) {
	    for (l = j; (l < (MAX_tr-1)) && (trojice[l+1].cislo[0]); l++) {
	      trojice[l].cislo[0] = trojice[l+1].cislo[0];
	      trojice[l].cislo[1] = trojice[l+1].cislo[1];
	      trojice[l].cislo[2] = trojice[l+1].cislo[2];
	    }
	    trojice[--pocet3].cislo[0] = 0;
	    trojice[pocet3].cislo[1] = 0;
	    trojice[pocet3].cislo[2] = 0;
	    gotoxy(P3x,P3y);
	    printf("%d    ",pocet3);
	    j--;
	  }
  }
}

// fcia vymaze z databazy nepouzitych trojic tie, ktore
// uz su pouzite
void vymaz_nep(byte a, byte b, byte c, byte d, byte e, byte f)
{
 int i,j,k;
 for (i = 0; (i < MAX_nep) && (ntrojice[i].cislo[0]); i++)
   if ((a == ntrojice[i].cislo[0]) || (b == ntrojice[i].cislo[0]) || (c == ntrojice[i].cislo[0])
    || (d == ntrojice[i].cislo[0]) || (e == ntrojice[i].cislo[0]) || (f == ntrojice[i].cislo[0]))
     if ((a == ntrojice[i].cislo[1]) || (b == ntrojice[i].cislo[1]) || (c == ntrojice[i].cislo[1])
      || (d == ntrojice[i].cislo[1]) || (e == ntrojice[i].cislo[1]) || (f == ntrojice[i].cislo[1]))
       if ((a == ntrojice[i].cislo[2]) || (b == ntrojice[i].cislo[2]) || (c == ntrojice[i].cislo[2])
	|| (d == ntrojice[i].cislo[2]) || (e == ntrojice[i].cislo[2]) || (f == ntrojice[i].cislo[2])) {
	 for (k = i; (k < (MAX_nep-1)) && (ntrojice[k+1].cislo[0]); k++) {
	   ntrojice[k].cislo[0] = ntrojice[k+1].cislo[0];
	   ntrojice[k].cislo[1] = ntrojice[k+1].cislo[1];
	   ntrojice[k].cislo[2] = ntrojice[k+1].cislo[2];
	 }
	 ntrojice[--pocet3n].cislo[0] = 0;
	 ntrojice[pocet3n].cislo[1] = 0;
	 ntrojice[pocet3n].cislo[2] = 0;
	 i--;
	 gotoxy(P3nx,P3ny);
	 printf("%d    ",pocet3n);
       }
}

// funkcia trojka plni nasledujuce ulohy:
// parameter koef:
// koef = 0:  porovnava vsetky trojice v databaze s pouzitim docasnej pamate
//            s parametrami a,b,c (ktore tvoria vlastne trojicu)
// koef = 1:  vymaze docasnu pamat a nic neporovnava
// koef = 2:  vymaze z docasnej pamate vsetky trojice, ktore inciduju s
//            cislom v a
// koef = 3:  porovnava vsetky trojice v databaze bez pouzitia docasnej pamate
int trojka(byte a, byte b, byte c, int koef)
{
  int i,k;           // indexove premenne
  byte p1,p2,p3;     // pomocne premenne na uchovanie porovnavacej trojice
  static index = 0;  // index v docasnej pamati

  if (!koef) {
    // najprv skontrolujem docasnu pamat - ak sa v nej trojka {a,b,c} nenachadza,
    // skontrolujem, ci sa nenachadza v celej databaze a ak ani tam nie,
    // pridam ju do docasnej pamate pre aktualnu sesticu
    for (i = 0; i < index; i++) {
      p1 = strojice[i].cislo[0];
      p2 = strojice[i].cislo[1];
      p3 = strojice[i].cislo[2];
      if ((p1 == a) && (p2 == b) && (p3 == c)) return 1;  // tu sa porovnavaju
      else if ((p1 == a) && (p2 == c) && (p3 == b)) return 1;  // vsetky moznosti
      else if ((p1 == b) && (p2 == a) && (p3 == c)) return 1;  // s danou trojicou
      else if ((p1 == b) && (p2 == c) && (p3 == a)) return 1;  // aby nevznikli
      else if ((p1 == c) && (p2 == a) && (p3 == b)) return 1;  // problemy ako napr.
      else if ((p1 == c) && (p2 == b) && (p3 == a)) return 1;  // 123,321,...
    }
    // ok. teraz kontrola v celej databaze
    for (i = 0; (i < MAX_tr) && (trojice[i].cislo[0]); i++) {
      p1 = trojice[i].cislo[0];
      p2 = trojice[i].cislo[1];
      p3 = trojice[i].cislo[2];
      if ((p1 == a) && (p2 == b) && (p3 == c)) return 1;
      else if ((p1 == a) && (p2 == c) && (p3 == b)) return 1;
      else if ((p1 == b) && (p2 == a) && (p3 == c)) return 1;
      else if ((p1 == b) && (p2 == c) && (p3 == a)) return 1;
      else if ((p1 == c) && (p2 == a) && (p3 == b)) return 1;
      else if ((p1 == c) && (p2 == b) && (p3 == a)) return 1;
    }
    // ak program dosiel az sem, tak trojica sa v databaze nenachadza.
    // pridam ju do docasnej pamate.
    strojice[index].cislo[0] = a;
    strojice[index].cislo[1] = b;
    strojice[index++].cislo[2] = c;
  }
  else if (koef == 1) {
    // ak bola skontrolovana cela sestica, docasna pamat sa vymaze
    strojice[0].cislo[0] = 0;
    strojice[0].cislo[1] = 0;
    strojice[0].cislo[2] = 0;
    index = 0;
  }
  else if (koef == 2) {
    // vymazem vsetky trojice z docasnej pamate incidentne s cislom v "a"
    for (i = 0; i < index; i++)
      if ((strojice[i].cislo[0] == a) || (strojice[i].cislo[1] == a) || (strojice[i].cislo[2] == a)) {
	vymaz3(strojice,i,index);
	index--;
	i--;
      }
  }
  else if (koef == 3) {
    // kontrola len v celej databaze
    for (i = 0; (i < MAX_tr) && (trojice[i].cislo[0]); i++) {
      p1 = trojice[i].cislo[0];
      p2 = trojice[i].cislo[1];
      p3 = trojice[i].cislo[2];
      if ((p1 == a) && (p2 == b) && (p3 == c)) return 1;
      else if ((p1 == a) && (p2 == c) && (p3 == b)) return 1;
      else if ((p1 == b) && (p2 == a) && (p3 == c)) return 1;
      else if ((p1 == b) && (p2 == c) && (p3 == a)) return 1;
      else if ((p1 == c) && (p2 == a) && (p3 == b)) return 1;
      else if ((p1 == c) && (p2 == b) && (p3 == a)) return 1;
    }
  }
  return 0;
}

// fcia prida vsetky trojice zo sestice tvorenej premennymi {a,b,c,d,e,f}
// (cize kombinacie 3 cif. cisel sestice) do databazy trojic
// a prida celu sesticu do databazy sestic
void pridaj(byte a, byte b, byte c, byte d, byte e, byte f)
{
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = b;
  trojice[pocet3++].cislo[2] = c;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = b;
  trojice[pocet3++].cislo[2] = d;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = b;
  trojice[pocet3++].cislo[2] = e;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = b;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = c;
  trojice[pocet3++].cislo[2] = d;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = c;
  trojice[pocet3++].cislo[2] = e;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = c;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = d;
  trojice[pocet3++].cislo[2] = e;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = d;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = a;
  trojice[pocet3].cislo[1] = e;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = b;
  trojice[pocet3].cislo[1] = c;
  trojice[pocet3++].cislo[2] = d;
  trojice[pocet3].cislo[0] = b;
  trojice[pocet3].cislo[1] = c;
  trojice[pocet3++].cislo[2] = e;
  trojice[pocet3].cislo[0] = b;
  trojice[pocet3].cislo[1] = c;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = b;
  trojice[pocet3].cislo[1] = d;
  trojice[pocet3++].cislo[2] = e;
  trojice[pocet3].cislo[0] = b;
  trojice[pocet3].cislo[1] = d;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = b;
  trojice[pocet3].cislo[1] = e;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = c;
  trojice[pocet3].cislo[1] = d;
  trojice[pocet3++].cislo[2] = e;
  trojice[pocet3].cislo[0] = c;
  trojice[pocet3].cislo[1] = d;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = c;
  trojice[pocet3].cislo[1] = e;
  trojice[pocet3++].cislo[2] = f;
  trojice[pocet3].cislo[0] = d;
  trojice[pocet3].cislo[1] = e;
  trojice[pocet3++].cislo[2] = f;

  sestice[pocet6].cislo[0] = a;
  sestice[pocet6].cislo[1] = b;
  sestice[pocet6].cislo[2] = c;
  sestice[pocet6].cislo[3] = d;
  sestice[pocet6].cislo[4] = e;
  sestice[pocet6++].cislo[5] = f;
}

// FAZA2: nepouzite trojice
void nepouzite3()
{
  byte m,n,o;
  int i;

  // vynulovanie pola
  for (i = 0; i < MAX_nep; i++) {
    ntrojice[i].cislo[0] = 0;
    ntrojice[i].cislo[1] = 0;
    ntrojice[i].cislo[2] = 0;
  }
  pocet3n = 0;
  for (m = 1; m <= MAX-2; m++)
    for (n = m+1; n <= MAX-1; n++)
      for (o = n+1; o <= MAX;o++)
	if ((m != n) && (m != o) && (n != o))
	  if (!trojka(m,n,o,3)) {
	    ntrojice[pocet3n].cislo[0] = m;
	    ntrojice[pocet3n].cislo[1] = n;
	    ntrojice[pocet3n++].cislo[2] = o;
	    gotoxy(P3nx,P3ny);
	    printf("%d    ",pocet3n);
	  }
}

// fcia zisti, kolko dane trojice c1(a,b,c) a c2(d,e,f) obsahuju
// rovnakych cisel - ak v c2(d,e,f) je cislo, ktore nie je v c1(a,b,c)
// tak v p sa vrati pozicia
int komb3(byte c1[3], byte c2[3], int *p) {
  int i,j,k,l,m,n;
  int pocet;
  *p = 0;

  for (i = 0; i < 3; i++)
    for (j = 0; j < 3; j++)
      if (c1[i] == c2[j]) {
	for (k = 0; k < 3; k++)
	  for (l = 0; l < 3; l++)
	    if ((i != k) && (j != l))
	      if (c1[k] == c2[l]) {
		// teraz potrebujem vypocitat, aby m a n obsahovali
		// taky index z 0,1,2 ktory este nebol
		// 2-1 = 1, 2-0 = 2 (3-2 = 1, 3-1 = 2)
		// 1+0 = 1 (2+1 = 3)
		if (k == 2) {
		  m = k-i;
		  m--;
		}
		else if (i == 2) {
		  m = i-k;
		  m--;
		}
		else {
		  m = i+k;
		  m++;
		}
		if (j == 2) {
		  n = j-l;
		  n--;
		}
		else if (l == 2) {
		  n = l-j;
		  n--;
		}
		else {
		  n = l+j;
		  n++;
		}
		if (c1[m] == c2[n]) {
		  *p = 0;
		  return 3;
		} else {
		  *p = n;
		  return 2;
		}
	      }
	*p = k-1;
	return 1;
      }
  *p = 0;
  return 0;
}

int main()
{
  byte m,n,o,p,q,r; // indexy pre pocitanie sestic
  int im,in,io,ip,iq,ir;
  int i,j,a,b,c,d,k; // pomocne premenne, vacsinou indexove
  sestica pom6; // pomocna sestica;
  trojica pom3;
  int bola;
  FILE *f;

  // vynulovanie pola
  for (i = 0; i < MAX_tr; i++) {
    trojice[i].cislo[0] = 0;
    trojice[i].cislo[1] = 0;
    trojice[i].cislo[2] = 0;
  }
  for (i = 0; i < MAX_se; i++)
    for (j = 0; j < 6; j++)
      sestice[i].cislo[j] = 0;
  pocet3 = 0;
  pocet6 = 0;
  index_o = 0;

  printf("\n\nPocet 3-jic od 1 po 49: (49!)/((49-3)!3!) = 18424");
  printf("\nTeoreticky pocet 6-tic urobenych z tychto trojic je: 18424/20 = 922\n");
  printf("\nVyskumom sa zistilo nasledujuce tvrdenie:");
  printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
  printf("Da sa dosiahnut max. 496 sestic bez opakovania trojak v jednej sestici\n");
  getchar();
  clrscr();
  kresli_menu();

  gotoxy(Fx,Fy);
  printf("1  ");
  gotoxy(LAx,LAy);
  printf("Pocitam sestice - bez opakovania           ");

  f = fopen("6b.txt","r");

  while (!feof(f)) {
    fscanf(f, "%d %d %d %d %d %d\n",&im,&in,&io,&ip,&iq,&ir);
    m = im; n = in; o = io; p = ip; q = iq; r = ir;
    pridaj(m,n,o,p,q,r);
    index_o += 20;
    if (pocet3 > 18424) vymaz_opak();
    gotoxy(P3x,P3y);
    printf("%d    ",pocet3);
    gotoxy(P6x,P6y);
    printf("%d    ",pocet6);
    gotoxy(Sx,Sy);
    printf("%2d %2d %2d %2d %2d %2d  ",m,n,o,p,q,r);
  }
  fclose(f);

  f = fopen("6.txt","w+");

/*
  j = 0;
  for (m = 1; m <= MAX-5; m++)  // MAX-5
    for (n = m+1; n <= MAX-4; n++)  // MAX-4
      for (o = n+1; o <= MAX-3; o++) { // MAX-3
	if ((m != n) && (m != o) && (n != o))
	  if (!trojka(m,n,o,0))
	    for (p = o+1; p <= MAX-2; p++) { // MAX-2
	      if ((m != p) && (n != p) && (o != p))
		if ((!trojka(m,n,p,0)) && (!trojka(n,o,p,0)) && (!trojka(m,o,p,0))) {
		  for (q = p+1; q <= MAX-1; q++) {  // MAX-1
		    if ((m != q) && (n != q) && (o != q) && (p != q))
		      if ((!trojka(m,n,q,0)) && (!trojka(m,o,q,0)) && (!trojka(m,p,q,0)) && (!trojka(n,o,q,0)) && (!trojka(n,p,q,0)) && (!trojka(o,p,q,0))) {
			for (r = q+1; r <= MAX; r++) { // MAX
			  if ((m != r) && (n != r) && (o != r) && (p != r) && (q != r))
			    if ((!trojka(m,n,r,0)) && (!trojka(m,o,r,0)) && (!trojka(m,p,r,0))
				&& (!trojka(m,q,r,0)) && (!trojka(n,o,r,0))
				&& (!trojka(n,p,r,0)) && (!trojka(n,q,r,0))
				&& (!trojka(o,p,r,0)) && (!trojka(o,q,r,0))
				&& (!trojka(p,q,r,0))) {
			      trojka(0,0,0,1);
			      pridaj(m,n,o,p,q,r);
			      fprintf(f,"%d %d %d %d %d %d\n",m,n,o,p,q,r);
			      fflush(f);
			      gotoxy(P3x,P3y);
			      printf("%d    ",pocet3);
			      gotoxy(P6x,P6y);
			      printf("%d    ",pocet6);
			      gotoxy(Sx,Sy);
			      printf("%2d %2d %2d %2d %2d %2d ",m,n,o,p,q,r);
			      j = 1;
			      break;
			    }
			  trojka(r,0,0,2);
			}
			trojka(r,0,0,2);
			if (j == 1) {
			  trojka(q,0,0,2);
			  break;
			}
		      }
		    trojka(q,0,0,2);
		  }
		  if (j == 1) {
		    j =0;
		    trojka(p,0,0,2);
		    break;
		  }
		}
	      trojka(p,0,0,2);
	    }
	trojka(o,0,0,2);
      }
*/
phase2:
  gotoxy(Fx,Fy);
  printf("2  ");
  gotoxy(LAx,LAy);
  printf("Hladam nepouzite trojice...                ");
  nepouzite3();

phase3:
  gotoxy(Fx,Fy);
  printf("3  ");
  gotoxy(LAx,LAy);
  printf("Pocitam druhu cast sestic - s opakovanim   ");
  // i - index celej nepouzitej trojice, prva cast novej sestice
  // j - pomocny index pri hladani dalsej nep. trojice
  // c - pozicia cisla v novej sestici, ktora sa spracuvava (3,4,5)
  // b - premenna oznacuje aktualnu kombinaciu trojice v novej sestici,
  //     ktora obsahuje cislo na pozicii v c.
  // a - pomocne premenne pre log. operacie
  i = 0;
  while (pocet3n > 0) {
    pom6.cislo[0] =ntrojice[i].cislo[0];
    pom6.cislo[1] =ntrojice[i].cislo[1];
    pom6.cislo[2] =ntrojice[i].cislo[2];

    // mam trojicu. Do druhej casti sestice potrebujem najst take
    // kombinacie trojic, aby 2 boli z tejto trojice a jedno z inej,
    // ale tak, aby spolu tvorili dalsiu nepouzitu trojicu.

    pom3.cislo[0] = ntrojice[i].cislo[0];
    pom3.cislo[1] = ntrojice[i].cislo[1];
    pom3.cislo[2] = ntrojice[i].cislo[2];
    c = 3;
    b = 0;
hl:
    for (j = i+1; j < pocet3n; j++)
      if (komb3(pom3.cislo,ntrojice[j].cislo,&a) == 2) {
	bola = 0;
	for (d = 0; d <= c; d++)
	  if (pom6.cislo[d] == ntrojice[j].cislo[a])
	    bola =1;
	if (bola == 0) {
	  pom6.cislo[c] = ntrojice[j].cislo[a];
	  // vymazem j-tu nepouzitu trojicu
	  vymaz3(ntrojice,j,MAX_nep);
	  pocet3n--;
	  break;
	}
       }

    if (pom6.cislo[c]) c++;
    else i++;

    if (c > 5) {
      // dalsia sestka, tuto mam plnu
      goto kon;
    }
    if ((c-1) > 4) {
      if (!b) {
	pom3.cislo[0] = pom6.cislo[0];
	pom3.cislo[1] = pom6.cislo[4];
	pom3.cislo[2] = pom6.cislo[c-1];
      } else if (b == 1) {
	pom3.cislo[0] = pom6.cislo[1];
	pom3.cislo[1] = pom6.cislo[4];
	pom3.cislo[2] = pom6.cislo[c-1];
      } else if (b == 2) {
	pom3.cislo[0] = pom6.cislo[2];
	pom3.cislo[1] = pom6.cislo[4];
	pom3.cislo[2] = pom6.cislo[c-1];
      } else if (b == 3) {
	pom3.cislo[0] = pom6.cislo[3];
	pom3.cislo[1] = pom6.cislo[4];
	pom3.cislo[2] = pom6.cislo[c-1];
      }
      b++;
      if (b > 3) {
	break;
      }
      goto hl;
    }
    if ((c-1) > 3) {
      if (!b) {
	pom3.cislo[0] = pom6.cislo[0];
	pom3.cislo[1] = pom6.cislo[3];
	pom3.cislo[2] = pom6.cislo[c-1];
      } else if (b == 1) {
	pom3.cislo[0] = pom6.cislo[1];
	pom3.cislo[1] = pom6.cislo[3];
	pom3.cislo[2] = pom6.cislo[c-1];
      } else if (b == 2) {
	pom3.cislo[0] = pom6.cislo[2];
	pom3.cislo[1] = pom6.cislo[3];
	pom3.cislo[2] = pom6.cislo[c-1];
      }
      b++;
      if (b > 2) {
	if ((c-1) < 4) break;
      }
      goto hl;
    }
    if ((c-1) > 2) {
      if (!b) {
	pom3.cislo[0] = pom6.cislo[0];
	pom3.cislo[1] = pom6.cislo[1];
	pom3.cislo[2] = pom6.cislo[c-1];
      } else if (b == 1) {
	pom3.cislo[0] = pom6.cislo[0];
	pom3.cislo[1] = pom6.cislo[2];
	pom3.cislo[2] = pom6.cislo[c-1];
      } else if (b == 2) {
	pom3.cislo[0] = pom6.cislo[1];
	pom3.cislo[1] = pom6.cislo[2];
	pom3.cislo[2] = pom6.cislo[c-1];
      }
      b++;
      if (b > 2) {
	if ((c-1) < 4) break;
      }
      goto hl;
    }

kon:
    // koniec: sestka hotova
    pridaj(pom6.cislo[0],pom6.cislo[1],pom6.cislo[2],pom6.cislo[3],pom6.cislo[4],pom6.cislo[5]);
    fprintf(f,"%d %d %d %d %d %d\n",pom6.cislo[0],pom6.cislo[1],pom6.cislo[2],pom6.cislo[3],pom6.cislo[4],pom6.cislo[5]);
    fflush(f);
    gotoxy(P3x,P3y);
    printf("%d    ",pocet3);
    gotoxy(P6x,P6y);
    printf("%d    ",pocet6);
    gotoxy(Sx,Sy);
    printf("%2d %2d %2d %2d %2d %2d ",pom6.cislo[0],pom6.cislo[1],pom6.cislo[2],pom6.cislo[3],pom6.cislo[4],pom6.cislo[5]);
    if (i >= pocet3n) break;
    gotoxy(Fx,Fy);
    printf("4  ");
    gotoxy(LAx,LAy);
    printf("Mazem opakujuce sa trojice...              ");
    if (pocet3 > 19990) vymaz_opak();
    gotoxy(Fx,Fy);
    printf("2.1");
    gotoxy(LAx,LAy);
    printf("Mazem opakujuce sa trojice z nepouzitych...");
    vymaz_nep(pom6.cislo[0],pom6.cislo[1],pom6.cislo[2],pom6.cislo[3],pom6.cislo[4],pom6.cislo[5]);
    goto phase3;
  }
  gotoxy(Fx,Fy);
  printf("4  ");
  gotoxy(LAx,LAy);
  printf("Mazem opakujuce sa trojice...              ");
  vymaz_opak();
  gotoxy(Fx,Fy);
  printf("5  ");
  gotoxy(LAx,LAy);
  printf("Hladam nepouzite trojice...                ");
  nepouzite3();

  fprintf(f, "\nPocet: %d\n",pocet6);
  fclose(f);

  clrscr();
  printf("\n\nPocet3: %d\nPocet 6: %d\nPocet nep.3: %d",pocet3,pocet6,pocet3n);

  f = fopen("3c.txt","w+");
  for (i =0; (i < pocet3) && (trojice[i].cislo[0]); i++)
    fprintf(f,"%2d %2d %2d\n",trojice[i].cislo[0],trojice[i].cislo[1],trojice[i].cislo[2]);
  fclose(f);

  getchar();

  return 0;
}
