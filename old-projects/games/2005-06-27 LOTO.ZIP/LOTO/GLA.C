/*
   GLA.C
   (c) Copyright 2005, Peter Jakubco

   max. 496 - sestiek bez opakovania trojak sa da dosiahnut
   1695 - vsetky sestky aj s opakovanim, nepouzite ostavaju 0

   � - 218, � - 196, � - 194, � - 195, � - 191, � - 179, � - 193
   � - 180, � - 192, � - 217

*/

#include <stdio.h>
#include <conio.h>

// Definicie a konstanty
  #define MAX 49
  #define MAX_U3 9000
  #define MAX_6 5000

  #define LCx 1         // pociatocne suradnice GUI
  #define LCy 1
  #define P3x (LCx+2)   // sur. pocet 3
  #define P3y (LCy+1)
  #define P6x (LCx+16)  // sur. pocet 6
  #define P6y (LCy+1)
  #define P3nx (LCx+30) // sur. pocet nep.3
  #define P3ny (LCy+1)
  #define Fx (LCx+2)    // sur. faza
  #define Fy (LCy+3)
  #define LAx (LCx+2)   // sur. popis
  #define LAy (LCy+6)
  #define Sx (LCx+16)   // sur. sestica
  #define Sy (LCy+3)

  typedef int byte;     // typ pouzity pre ukladanie hodnot sestic (niekedy bolo 'unsigned char')

  typedef struct {
    byte num[3];
  } trinity;            // struktura jednej trojice cisel

  typedef struct {
    byte num[6];
  } senary;            // struktura jednej sestice cisel

// Globalne premenne
  trinity huge U3[MAX_U3]; // pole nepouzitych trojic
  senary huge S6[MAX_6];   // pole vsetkych sestic
  int countU3;              // pocet nep. trojic
  int countS6;              // pocet sestic


// Funkcie - su rozdelene do 3 skupin: - GUI funkcie
//                                     - Vseobecne funkcie
//                                     - Funkcie podla faz


// GUI Funkcie
void DrawGUI()
{
 int i;

 gotoxy(LCx,LCy);
 printf("��� Pocet 3 ����� Pocet 6 ����� Pocet nep. 3 �Ŀ");
 gotoxy(LCx,LCy+1);
 printf("�             �             �                  �");
 gotoxy(LCx,LCy+2);
 printf("��� Faza �������������������������������������Ĵ");
 gotoxy(LCx,LCy+3);
 printf("�             �                                �");
 gotoxy(LCx,LCy+4);
 printf("������������������������������������������������");
 gotoxy(LCx,LCy+5);
 printf("��� Popis cinnosti ���������������������������Ŀ");
 gotoxy(LCx,LCy+6);
 printf("�                                              �");
 gotoxy(LCx,LCy+7);
 printf("������������������������������������������������");
}

// Funkcie vseobecne

// funkcia vymaze trojku na pozicii index v poli tr. Maximum pola je
// v premennej mMAX
void Erase3(trinity *tr, int index, int mMAX, int ShowU3)
{
  int i;
  for (i = index; i < (mMAX-1); i++) {
    tr[i].num[0] = tr[i+1].num[0];
    tr[i].num[1] = tr[i+1].num[1];
    tr[i].num[2] = tr[i+1].num[2];
  }
  tr[i].num[0] = 0;
  tr[i].num[1] = 0;
  tr[i].num[2] = 0;
  if (ShowU3 == 1) {
    gotoxy(P3nx,P3ny);
    printf("%d    ",countU3);
  }
}

// fcia prida 6-tku a vymaze z nepouzitych 3-jic tie,
// ktore su zahrnute v tejto sestke
void Add6(byte a, byte b, byte c, byte d, byte e, byte f)
{
  int i;    // indexova premenna
  int bola; // pomocna premenna

  // pridanie sestice do databazy
  S6[countS6].num[0] = a;
  S6[countS6].num[1] = b;
  S6[countS6].num[2] = c;
  S6[countS6].num[3] = d;
  S6[countS6].num[4] = e;
  S6[countS6++].num[5] = f;

  bola = 0;
  for (i = 0; i < countU3; i++) {
    if ((a == U3[i].num[0]) || (a == U3[i].num[1]) || (a == U3[i].num[2])) {
      if ((b == U3[i].num[0]) || (b == U3[i].num[1]) || (b == U3[i].num[2])) {
	if ((c == U3[i].num[0]) || (c == U3[i].num[1]) || (c == U3[i].num[2])) {
	  bola = 1;
	} else if ((d == U3[i].num[0]) || (d == U3[i].num[1]) || (d == U3[i].num[2])) {
	  bola = 1;
	} else if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	  bola = 1;
	} else if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  bola = 1;
	}
      } else if ((c == U3[i].num[0]) || (c == U3[i].num[1]) || (c == U3[i].num[2])) {
	if ((d == U3[i].num[0]) || (d == U3[i].num[1]) || (d == U3[i].num[2])) {
	  bola = 1;
	} else if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	  bola = 1;
	} else if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  bola = 1;
	}
      } else if ((d == U3[i].num[0]) || (d == U3[i].num[1]) || (d == U3[i].num[2])) {
	if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	  bola = 1;
	} else if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  bola = 1;
	}
      } else if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  countU3--;
	  Erase3((trinity *)U3,i,countU3+1,1);
	  i--;
	  continue;
	}
      }
    } else if ((b == U3[i].num[0]) || (b == U3[i].num[1]) || (b == U3[i].num[2])) {
      if ((c == U3[i].num[0]) || (c == U3[i].num[1]) || (c == U3[i].num[2])) {
	if ((d == U3[i].num[0]) || (d == U3[i].num[1]) || (d == U3[i].num[2])) {
	  bola = 1;
	} else if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	  bola = 1;
	} else if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  bola = 1;
	}
      } else if ((d == U3[i].num[0]) || (d == U3[i].num[1]) || (d == U3[i].num[2])) {
	if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	  bola = 1;
	} else if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  bola = 1;
	}
      } else if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  countU3--;
	  Erase3((trinity *)U3,i,countU3+1,1);
	  i--;
	  continue;
	}
      }
    } else if ((c == U3[i].num[0]) || (c == U3[i].num[1]) || (c == U3[i].num[2])) {
      if ((d == U3[i].num[0]) || (d == U3[i].num[1]) || (d == U3[i].num[2])) {
	if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	  bola = 1;
	} else if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  bola = 1;
	}
      } else if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2])) {
	if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  countU3--;
	  Erase3((trinity *)U3,i,countU3+1,1);
	  i--;
	  continue;
	}
      }
    } else if ((d == U3[i].num[0]) || (d == U3[i].num[1]) || (d == U3[i].num[2])) {
      if ((e == U3[i].num[0]) || (e == U3[i].num[1]) || (e == U3[i].num[2]))
	if ((f == U3[i].num[0]) || (f == U3[i].num[1]) || (f == U3[i].num[2])) {
	  countU3--;
	  Erase3((trinity *)U3,i,countU3+1,1);
	  i--;
	  continue;
	}
    }
    if (bola == 1) {
      bola = 0;
      countU3--;
      Erase3((trinity *)U3,i,countU3+1,1);
      i--;
      continue;
    }
  }
}

// fcia skontroluje, ci sa dana trinity nachadza v sestkach
int InSenary(byte a, byte b, byte c)
{
  int i,k;           // indexove premenne
  byte p1,p2,p3;     // pomocne premenne na uchovanie porovnavacej trojice
  byte p4,p5,p6;

  for (i = 0; i < countS6; i++) {
    p1 = S6[i].num[0];
    p2 = S6[i].num[1];
    p3 = S6[i].num[2];
    p4 = S6[i].num[3];
    p5 = S6[i].num[4];
    p6 = S6[i].num[5];
    if ((p1 == a) || (p2 == a) || (p3 == a) || (p4 == a) || (p5 == a) || (p6 == a))
      if ((p1 == b) || (p2 == b) || (p3 == b) || (p4 == b) || (p5 == b) || (p6 == b))
	if ((p1 == c) || (p2 == c) || (p3 == c) || (p4 == c) || (p5 == c) || (p6 == c))
	  return 1;
  }
  return 0;
}

// FAZA 1:

// Fcia skontroluje, ci sa dana kombinacia trojky nenachadza
// v docasnej pamati
int P1_Trinity(byte a, byte b, byte c, int koef)
{
  static trinity s[20];
  static index = 0;  // index v docasnej pamati
  int i,k;           // indexove premenne
  byte p1,p2,p3;     // pomocne premenne na uchovanie porovnavacej trojice

  if (!koef) {
    for (i = 0; i < index; i++) {
      p1 = s[i].num[0];
      p2 = s[i].num[1];
      p3 = s[i].num[2];
      if ((p1 == a) && (p2 == b) && (p3 == c)) return 1;  // tu sa porovnavaju
      else if ((p1 == a) && (p2 == c) && (p3 == b)) return 1;  // vsetky moznosti
      else if ((p1 == b) && (p2 == a) && (p3 == c)) return 1;  // s danou trojicou
      else if ((p1 == b) && (p2 == c) && (p3 == a)) return 1;  // aby nevznikli
      else if ((p1 == c) && (p2 == a) && (p3 == b)) return 1;  // problemy ako napr.
      else if ((p1 == c) && (p2 == b) && (p3 == a)) return 1;  // 123,321,...
    }
    // ak program dosiel az sem, tak trojica sa v databaze nenachadza.
    // pridam ju do docasnej pamate.
    s[index].num[0] = a;
    s[index].num[1] = b;
    s[index++].num[2] = c;
  }
  else if (koef == 1) {
    // ak bola skontrolovana cela sestica, docasna pamat sa vymaze
    s[0].num[0] = 0;
    s[0].num[1] = 0;
    s[0].num[2] = 0;
    index = 0;
  }
  else if (koef == 2) {
    // vymazem vsetky trojice z docasnej pamate incidentne s cislom v "a"
    for (i = 0; i < index; i++)
      if ((s[i].num[0] == a) || (s[i].num[1] == a) || (s[i].num[2] == a)) {
	Erase3(s,i,index,0);
	index--;
	i--;
      }
  }
  return 0;
}

void P1_Find6Wh(FILE *f)
{
  int j;
  int m,n,o,p,q,r; // indexy pre pocitanie sestic
  int count3;

  gotoxy(Fx,Fy);
  printf("1  ");
  gotoxy(LAx,LAy);
  printf("Pocitam S6 - bez opakovania           ");

  j = 0;
  count3 = 0;
  for (m = 1; m <= MAX-5; m++)
    for (n = m+1; n <= MAX-4; n++)
      for (o = n+1; o <= MAX-3; o++) {
	if ((m != n) && (m != o) && (n != o))
	  if (!P1_Trinity(m,n,o,0) && !InSenary(m,n,o))
	    for (p = o+1; p <= MAX-2; p++) {
	      if ((m != p) && (n != p) && (o != p))
		if (!P1_Trinity(m,n,p,0) && !P1_Trinity(n,o,p,0) && !P1_Trinity(m,o,p,0))
		  if (!InSenary(m,n,p) && !InSenary(n,o,p) && !InSenary(m,o,p)) {
		    for (q = p+1; q <= MAX-1; q++) {
		      if ((m != q) && (n != q) && (o != q) && (p != q))
			if (!P1_Trinity(m,n,q,0) && !P1_Trinity(m,o,q,0) && !P1_Trinity(m,p,q,0) && !P1_Trinity(n,o,q,0) && !P1_Trinity(n,p,q,0) && !P1_Trinity(o,p,q,0))
			  if (!InSenary(m,n,q) && !InSenary(m,o,q) && !InSenary(m,p,q) && !InSenary(n,o,q) && !InSenary(n,p,q) && !InSenary(o,p,q)) {
			    for (r = q+1; r <= MAX; r++) { // MAX
			      if ((m != r) && (n != r) && (o != r) && (p != r) && (q != r))
				if (!P1_Trinity(m,n,r,0) && !P1_Trinity(m,o,r,0) && !P1_Trinity(m,p,r,0)
				    && !P1_Trinity(m,q,r,0) && !P1_Trinity(n,o,r,0)
				    && !P1_Trinity(n,p,r,0) && !P1_Trinity(n,q,r,0)
				    && !P1_Trinity(o,p,r,0) && !P1_Trinity(o,q,r,0)
				    && !P1_Trinity(p,q,r,0))
				  if (!InSenary(m,n,r) && !InSenary(m,o,r) && !InSenary(m,p,r)
				      && !InSenary(m,q,r) && !InSenary(n,o,r)
				      && !InSenary(n,p,r) && !InSenary(n,q,r)
				      && !InSenary(o,p,r) && !InSenary(o,q,r)
				      && !InSenary(p,q,r)) {
				    P1_Trinity(0,0,0,1);
				    Add6(m,n,o,p,q,r);
				    count3 += 20;
				    fprintf(f,"%d %d %d %d %d %d\n",m,n,o,p,q,r);
				    fflush(f);
				    gotoxy(P3x,P3y);
				    printf("%d    ",count3);
				    gotoxy(P6x,P6y);
				    printf("%d    ",countS6);
				    gotoxy(Sx,Sy);
				    printf("%2d %2d %2d %2d %2d %2d ",m,n,o,p,q,r);
				    j = 1;
				    break;
				  }
			      P1_Trinity(r,0,0,2);
			    }
			    P1_Trinity(r,0,0,2);
			    if (j == 1) {
			      P1_Trinity(q,0,0,2);
			      break;
			    }
			  }
		      P1_Trinity(q,0,0,2);
		    }
		    if (j == 1) {
		      j =0;
		      P1_Trinity(p,0,0,2);
		      break;
		    }
		  }
	      P1_Trinity(p,0,0,2);
	    }
	  P1_Trinity(o,0,0,2);
      }
}

// FAZA 2:

// fcia zisti nepouzite trojice
void P2_FindU3()
{
  byte m,n,o;
  int i;

  gotoxy(Fx,Fy);
  printf("2  ");
  gotoxy(LAx,LAy);
  printf("Hladam nepouzite trojice...                ");
  // vynulovanie pola databazy nepouzitych trojic
  for (i = 0; i < MAX_U3; i++) {
    U3[i].num[0] = 0;
    U3[i].num[1] = 0;
    U3[i].num[2] = 0;
  }
  countU3 = 0;
  for (m = 1; m <= MAX-2; m++)
    for (n = m+1; n <= MAX-1; n++)
      for (o = n+1; o <= MAX;o++)
	if ((m != n) && (m != o) && (n != o))
	  if (!InSenary(m,n,o)) {
	    U3[countU3].num[0] = m;
	    U3[countU3].num[1] = n;
	    U3[countU3++].num[2] = o;
	    gotoxy(P3nx,P3ny);
	    printf("%d    ",countU3);
	  }
}

// FAZA 3:

// fcia zisti, kolko dane trojice c1(a,b,c) a c2(d,e,f) obsahuju
// rovnakych cisel - ak v c2(d,e,f) je num, ktore nie je v c1(a,b,c)
// tak v p sa vrati pozicia => pouziva sa pri zistovani opakovanych sestic
int P3_Comb3(byte c1[3], byte c2[3], int *p) {
  int i,j,k,l,m,n;
  *p = 0;

  for (i = 0; i < 3; i++)
    for (j = 0; j < 3; j++)
      if (c1[i] == c2[j]) {
	for (k = 0; k < 3; k++)
	  for (l = 0; l < 3; l++)
	    if ((i != k) && (j != l))
	      if (c1[k] == c2[l]) {
		// teraz potrebujem vypocitat, aby m a n obsahovali
		// taky index z 0,1,2 ktory este nebol
		// 2-1 = 1, 2-0 = 2 (3-2 = 1, 3-1 = 2)
		// 1+0 = 1 (2+1 = 3)
		if (k == 2) {
		  m = k-i;
		  m--;
		}
		else if (i == 2) {
		  m = i-k;
		  m--;
		}
		else {
		  m = i+k;
		  m++;
		}
		if (j == 2) {
		  n = j-l;
		  n--;
		}
		else if (l == 2) {
		  n = l-j;
		  n--;
		}
		else {
		  n = l+j;
		  n++;
		}
		if (c1[m] == c2[n]) {
		  *p = 0;
		  return 3;
		} else {
		  *p = n;
		  return 2;
		}
	      }
	*p = k-1;
	return 1;
      }
  *p = 0;
  return 0;
}

// Fcia najde sestky s opakovanim vyuzitim
// vyhladavacieho algoritmu, ktory sa snazi vyuzit
// co najviac nepouzitych trojic do jednej sestice
void P3_Find6Wi(FILE *f)
{
  int i,j,k,a,d;
  int newD,Comb;
  int bola;
  senary H6;
  trinity H3;

phase3:
  gotoxy(Fx,Fy);
  printf("3  ");
  gotoxy(LAx,LAy);
  printf("Pocitam druhu cast sestic - s opakovanim   ");
  // i     - index celej nepouzitej trojice, prva cast novej S6
  // j     - pomocny index pri hladani dalsej nep. trojice
  // newD  - pozicia cisla v novej sestici, ktora sa spracuvava (3,4,5)
  // nComb - premenna oznacuje aktualnu kombinaciu trojice v novej sestici,
  //         ktora obsahuje num na pozicii v c.
  // k     - pomocne premenne pre log. operacie
  i = 0;
  while (countU3 > 0) {
    H6.num[0] = U3[i].num[0];
    H6.num[1] = U3[i].num[1];
    H6.num[2] = U3[i].num[2];
    H6.num[3] = 0;
    H6.num[4] = 0;
    H6.num[5] = 0;

    // mam trojicu. Do druhej casti H6 potrebujem najst take
    // kombinacie trojic, aby 2 boli z tejto trojice a jedno z inej,
    // ale tak, aby spolu tvorili dalsiu nepouzitu trojicu.

    H3.num[0] = U3[i].num[0];
    H3.num[1] = U3[i].num[1];
    H3.num[2] = U3[i].num[2];
    newD = 3;  // najprv je stvrte cislo (prve tri mam)
    Comb = 0;  // v Comb je aktualne poradie moznej kombinacie
	       // nasledujucej trojice
hl:
    for (j = i+1; j < countU3; j++)
      if (P3_Comb3(H3.num,U3[j].num,&k) == 2) {
	bola = 0;
	for (d = 0; d <= newD; d++)
	  if (H6.num[d] == U3[j].num[k])
	    bola = 1;
	if (!bola) {
	  H6.num[newD] = U3[j].num[k];
	  // vymazem j-tu nepouzitu trojicu
	  countU3--;
	  Erase3((trinity *)U3,j,MAX_U3,1);
	  break;
	}
      }

    // Ak cislo na novej poz. nie je nulove (cize som ho nasiel)
    // idem hladat cislo do dalsej pozicie
    // inak: pouzijem dalsiu kombinaciu
    if (H6.num[newD]) newD++;
    else i++;

    // dalsia sestka, tuto mam plnu
    if (newD > 5) goto kon;

    if (i > countU3) break;

    if ((newD-1) > 4) {
      if (!Comb) {
	H3.num[0] = H6.num[0];
	H3.num[1] = H6.num[4];
	H3.num[2] = H6.num[newD-1];
      } else if (Comb == 1) {
	H3.num[0] = H6.num[1];
	H3.num[1] = H6.num[4];
	H3.num[2] = H6.num[newD-1];
      } else if (Comb == 2) {
	H3.num[0] = H6.num[2];
	H3.num[1] = H6.num[4];
	H3.num[2] = H6.num[newD-1];
      } else if (Comb == 3) {
	H3.num[0] = H6.num[3];
	H3.num[1] = H6.num[4];
	H3.num[2] = H6.num[newD-1];
      }
      Comb++;
      if (Comb > 3) break;
      goto hl;
    }
    if ((newD-1) > 3) {
      if (!Comb) {
	H3.num[0] = H6.num[0];
	H3.num[1] = H6.num[3];
	H3.num[2] = H6.num[newD-1];
      } else if (Comb == 1) {
	H3.num[0] = H6.num[1];
	H3.num[1] = H6.num[3];
	H3.num[2] = H6.num[newD-1];
      } else if (Comb == 2) {
	H3.num[0] = H6.num[2];
	H3.num[1] = H6.num[3];
	H3.num[2] = H6.num[newD-1];
      }
      Comb++;
      if (Comb > 2)
	if ((newD-1) < 4) break;
      goto hl;
    }
    if ((newD-1) > 2) {
      if (!Comb) {
	H3.num[0] = H6.num[0];
	H3.num[1] = H6.num[1];
	H3.num[2] = H6.num[newD-1];
      } else if (Comb == 1) {
	H3.num[0] = H6.num[0];
	H3.num[1] = H6.num[2];
	H3.num[2] = H6.num[newD-1];
      } else if (Comb == 2) {
	H3.num[0] = H6.num[1];
	H3.num[1] = H6.num[2];
	H3.num[2] = H6.num[newD-1];
      }
      Comb++;
      if (Comb > 2)
	if ((newD-1) < 4) break;
      goto hl;
    }

kon:
    // koniec: sestka hotova
    Add6(H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
    fprintf(f,"%d %d %d %d %d %d\n",H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
    fflush(f);
    gotoxy(P3x,P3y);
    printf("%d    ",18424- countU3);
    gotoxy(P6x,P6y);
    printf("%d    ",countS6);
    gotoxy(Sx,Sy);
    printf("%2d %2d %2d %2d %2d %2d ",H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
    i = 0;
}
  // faza 3.1: mame tu nejaku nedokoncenu sestku
  gotoxy(Fx,Fy);
  printf("3.1");
  gotoxy(LAx,LAy);
  printf("Pocitam nedokoncenu sestku...              ");
  if (i > countU3) {
    for (j = 1; j <= MAX; j++) {
      bola = 0;
      for (d = 0; d <= newD; d++)
	if (H6.num[d] == j)
	  bola = 1;
      if (!bola) {
	H6.num[newD] = j;
	newD++;
	if (newD > 5) {
	  Add6(H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
	  fprintf(f,"%d %d %d %d %d %d\n",H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
	  fflush(f);
	  gotoxy(P3x,P3y);
	  printf("%d    ",18424- countU3);
	  gotoxy(P6x,P6y);
	  printf("%d    ",countS6);
	  gotoxy(Sx,Sy);
	  printf("%2d %2d %2d %2d %2d %2d ",H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
	  break;
	}
      }
    }
  }
  // v tejto faze sa uz nedaju vytvorit ziadne ine kombinacie nep. trojek
  // iba surovo dat jednu vedla druhej (aj ked je tam nejaka optimalizacia
  // - kontrola, ci sa v jednej sestke nenachadzaju viac rovnakych cisel
  gotoxy(Fx,Fy);
  printf("3.2");
  gotoxy(LAx,LAy);
  printf("Pocitam posledne sestky...                 ");
  for (j = 0; j < countU3; j+=2) {
    H6.num[0] = U3[j].num[0];
    H6.num[1] = U3[j].num[1];
    H6.num[2] = U3[j].num[2];
    H6.num[3] = U3[j+1].num[0];
    H6.num[4] = U3[j+1].num[1];
    H6.num[5] = U3[j+1].num[2];
    newD = 0;

kon2:
    for (a = 0; a < 5; a++)
      for (d = a+1; d < 4; d++)
	if ((H6.num[a] == H6.num[d]) && (H6.num[d] != 0)) {
	  for (i = d; i < 4; i++)
	    H6.num[i] = H6.num[i+1];
	  for (i = i; i < 6; i++)
	    H6.num[i] = 0;
	  goto kon2;
	}
    bola = 0;
    for (a = 0; a < 6; a++)
      if (!H6.num[a]) {
	newD = a;
	bola = 1;
	break;
      }
    if (!bola) {
      Add6(H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
      if (InSenary(U3[j].num[0],U3[j].num[1],U3[j].num[2])) {
	Erase3((trinity *)U3,j,countU3,1);
	P2_FindU3();
	j=-2;
      }
      if (InSenary(U3[j+1].num[0],U3[j+1].num[1],U3[j+1].num[2])) {
	Erase3((trinity *)U3,j+1,countU3,1);
	P2_FindU3();
	j=-2;
      }
      fprintf(f,"%d %d %d %d %d %d\n",H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
      fflush(f);
      gotoxy(P3x,P3y);
      printf("%d    ",18424- countU3);
      gotoxy(P6x,P6y);
      printf("%d    ",countS6);
      gotoxy(Sx,Sy);
      printf("%2d %2d %2d %2d %2d %2d ",H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
      continue;
    }

    for (a = 1; a <= MAX; a++) {
      bola = 0;
      for (d = 0; d <= newD; d++)
	if (H6.num[d] == a)
	  bola = 1;
      if (!bola) {
	H6.num[newD] = a;
	newD++;
	if (newD > 5) {
	  Add6(H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
	  if (InSenary(U3[j].num[0],U3[j].num[1],U3[j].num[2])) {
	    Erase3((trinity *)U3,j,countU3,1);
	    P2_FindU3();
	    j=-2;
	  }
	  if (InSenary(U3[j+1].num[0],U3[j+1].num[1],U3[j+1].num[2])) {
	    Erase3((trinity *)U3,j+1,countU3,1);
	    P2_FindU3();
	    j=-2;
	  }
	  fprintf(f,"%d %d %d %d %d %d\n",H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
	  fflush(f);
	  gotoxy(P3x,P3y);
	  printf("%d    ",18424- countU3);
	  gotoxy(P6x,P6y);
	  printf("%d    ",countS6);
	  gotoxy(Sx,Sy);
	  printf("%2d %2d %2d %2d %2d %2d ",H6.num[0],H6.num[1],H6.num[2],H6.num[3],H6.num[4],H6.num[5]);
	  break;
	}
      }
    }
  }
  // No a tato faza je uz skutocne poslednou, vyuzije sa pri uplne
  // poslednej sestke, ked zostala len 1 trojka
  gotoxy(Fx,Fy);
  printf("3.3");
  gotoxy(LAx,LAy);
  printf("Ukoncenie...                               ");

  // ani ju netreba, lebo to vyjde presne...
}

int main()
{
  int i,j,c,d;
  senary H6; // pomocna sestica;
  int bola;
  FILE *f; // do suboru sa ukladaju vsetky hotove S6

  // vynulovanie pola - databazy sestic
  for (i = 0; i < MAX_6; i++)
    for (j = 0; j < 6; j++)
      S6[i].num[j] = 0;
  countS6 = 0;

  // nakreslenie grafickeho zobrazenia
  clrscr();
  DrawGUI();

  f = fopen("6.txt","w+");

phase1:
  P1_Find6Wh(f);

phase2:
  P2_FindU3();

phase3:
  P3_Find6Wi(f);

phase4:
  gotoxy(P3nx,P3ny);
  printf("%d    ",countU3);
  gotoxy(Fx,Fy);
  printf("4  ");
  gotoxy(LAx,LAy);
  printf("Hladam nepouzite trojice...                ");
  countU3=0;
  P2_FindU3();
  gotoxy(P3nx,P3ny);
  printf("%d    ",countU3);

  fprintf(f, "\nPocet 6: %d\n",countS6);
  fclose(f);

  clrscr();
  printf("\n\nPocet 3: %d\nPocet 6: %d\nPocet nep.3: %d",18424-countU3,countS6,countU3);
  getchar();

  return 0;
}
