//package main;

public class Main {

    private native void hello();
	
    static {
        // Call up the static library libmycodeinc.so created from ccode.c
        System.loadLibrary("hello");
    }
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 System.out.println("-- We are in the Java program JavaCode --");

         System.out.println("Call the C code");
	     new Main().hello();
	     System.out.println("-- We are back in Java --");
	}

}
