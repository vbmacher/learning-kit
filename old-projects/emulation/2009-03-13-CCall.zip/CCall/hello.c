#include <stdio.h>
#include "Main.h"  // Required header for JNI


// When calling C code from Java, main() must be replaced by a declaration
// similar to below, where the function name is given by "Java_" + the name
// of the class in the Java code that calls this C code, in this case
// "JavaCode", + "_" + the name of this C function called from Java, in this
// case "sumsquaredc".  This is followed by at least two parameters as below,
// plus possibly more if more are required.

JNIEXPORT void JNICALL Java_Main_hello (JNIEnv *env, jobject obj) {
    printf("-- We are now in the C program CCode --\n");
}

