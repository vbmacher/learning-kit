/*
 * emucl.hpp
 *
 * (c) Copyright 2010, P. Jakubco <pjakubco@gmail.com>
 *
 * KISS, YAGNI
 */

#ifndef __EMUCL__
#define __EMUCL__

int cl_execute(const char *prog, int ram_size, int cmd_options, FILE *flog);


#endif
