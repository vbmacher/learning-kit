/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package microcode;

import directexecute.Environment;

/**
 *
 * @author vbmacher
 */
public class Microcode {

    public static void addRR() {
        Environment.R1 = Environment.R1 + Environment.R2;
    }

    public static void subRR() {
        Environment.R1 = Environment.R1 + Environment.R2;
    }

    public static void movR1R2() {
        Environment.R1 = Environment.R2;
    }
    
    public static void movR2R1() {
        Environment.R2 = Environment.R1;
    }


}
