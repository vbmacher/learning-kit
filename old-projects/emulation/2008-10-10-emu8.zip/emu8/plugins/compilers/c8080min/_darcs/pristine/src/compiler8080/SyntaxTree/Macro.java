/*
 * Macro.java
 * 
 * Created on Sobota, 2007, december 22, 17:51
 *
 * KEEP IT SIMPLE, STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 * 
 */

package compiler8080.SyntaxTree;

import compiler8080.CompEnv;
import java.util.Hashtable;
import java.util.Vector;

public class Macro {
    private Vector operands;
    private CodeStatement stat;
    private int curadr;
    private boolean curadr_resolved;
    private int level;
    
    private int src_row;
    private int src_col;
    
    public Macro(Vector operands, int curadr, 
            boolean curadr_resolved, int level,
            int row, int col) {
        this.operands = operands;
        this.curadr = curadr;
        this.curadr_resolved = curadr_resolved;
        this.level = level;
        this.src_row = row;
        this.src_col = col;
    }
    
    public void set_statement(CodeStatement stat) {
        this.stat = stat;
    }
    
    public int get_curadr() { return curadr; }
    public boolean get_curadr_resolved() { return curadr_resolved; }
    public int get_level() { return level; }
    
    public int get_row() { return src_row; }
    public int get_col() { return src_col; }
    
    public Vector get_operands() { return operands; }
    
    public void resolve_macro(int address, CompEnv env, Vector parameters) {
        // TODO: resolve macro
        /*
         * 1. set equs to macro statement level (define parameters)
         * 2. resolve statement with this current address (for this macro call)
         * 
         */
    }
    
    /**
     * Must to be called after resolve_macro() call (second pass)
     */
    public Hashtable get_code() {
        if (stat == null) return null;
        return stat.get_code();
    }
    
    public boolean is_code_available() {
        if (stat == null) return false;
        return stat.is_available(true);
    }
}
