/*
 * AddressKeeper.java
 *
 * Created on Štvrtok, 2007, december 27, 22:40
 *
 * KEEP IT SIMPLE, STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 * 
 */

package compiler8080.SyntaxTree;

/**
 *
 * @author vbmacher
 */
public class AddressKeeper {
    private int adr;
    private boolean adr_resolved;
    public AddressKeeper(int adr, boolean adr_resolved) {
        this.adr = adr;
        this.adr_resolved = adr_resolved;
    }
    public int get_adr() { return adr; }
    public boolean get_adr_resolved() { return adr_resolved; }
}
