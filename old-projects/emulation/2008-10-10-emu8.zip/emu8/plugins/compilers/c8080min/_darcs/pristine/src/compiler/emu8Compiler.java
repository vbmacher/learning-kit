/*
 * emu8Compiler.java
 *
 * Created on Nedeľa, 2007, august 12, 18:48
 *
 * KEEP IT SIMPLE STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 */
package compiler;

/**
 *
 * @author vbmacher
 */
public interface emu8Compiler {
    public String getDescription();
    public String getVersion();
    public String getName();
    public String getCopyright();

    public emu8Lexer getLexer(java.io.Reader in, messageReporter reporter);
    public boolean compile(String filename);
}
