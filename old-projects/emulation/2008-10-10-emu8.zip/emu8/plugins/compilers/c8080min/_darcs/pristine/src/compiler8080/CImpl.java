/*
 * CImpl.java
 *
 * Created on Piatok, 2007, august 10, 8:22
 *
 * KEEP IT SIMPLE, STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 */

package compiler8080;
import compiler.*;
import compiler8080.SyntaxTree.*;

import java.util.*;

/**
 *
 * @author vbmacher
 */
public class CImpl implements emu8Compiler {
    private lexer8080 lex;
    private parser8080 par;
    private messageReporter reporter;
        
    // create lexer and parser, return lexer
    public emu8Lexer getLexer(java.io.Reader in, messageReporter reporter) { 
        lex = new lexer8080(in);
        par = new parser8080(lex, reporter);
        this.reporter = reporter;
        return lex;
    }
    
    private void print_text(String mes) {
        if (reporter != null) reporter.reportMessage(mes);
        else System.out.println(mes);
    }
    
    public boolean compile(String filename) {
        if (par == null) return false;

        Object s = null;
        HEXFileHandler hex = new HEXFileHandler();

        print_text(getName()+", version "+getVersion());
        try { s = par.parse().value; }
        catch(Exception e) {
            print_text(e.getMessage());
            return false;
        } catch (Error e) {}
        if (s == null) {
            print_text("Unexpected end of file");
            return false;
        }
        
        if (par.errorCount != 0) {
            print_text("Compile was unsuccessfull. Fix errors and then try again");
            return false;
        }
        // do several passes for compiling
        try {
            CodeStatement stat = (CodeStatement)s;

            if (stat.is_available(false) == false) {
                print_text("Second pass needed");
            } else {
                hex.putCode(stat.get_code());
                hex.generateFile(filename);
                
            }
        } catch(Exception e) {
            print_text(e.getMessage());
            return false;
        }
        print_text("Compile was sucessfull. Output: " + filename);
        return true;
    }
    
    public String getName() { return "Intel 8080 Compiler"; }
    public String getVersion() { return "1.1 beta"; }
    public String getCopyright() { return "Copyright (c) 2007, Peter Jakubčo"; }
    public String getDescription() {
        return "Optimized compiler for 8080 assembler. For assembler syntax look at original manual: "
                + "http://www.tech-systems-labs.com/booksdata/8080-asbly-pro.pdf";
    }

}
