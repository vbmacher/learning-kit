/*
 * ValueStatement.java
 *
 * Created on Nedeľa, 2007, december 23, 10:36
 *
 * KEEP IT SIMPLE, STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 *
 */

package compiler8080.SyntaxTree;

import java.util.Hashtable;

/**
 *
 * @author vbmacher
 */
public abstract class ValueStatement extends Statement {
    protected Integer value;
    protected String name; // for identifier needs
    
    public ValueStatement(int level, Integer val, int row, int col) {
        super(level,row,col);
        value = val;
        if (val == null) value_resolved = false;
        else {
            value_resolved = true;
            if (val.intValue() < 256 && val.intValue() >= -128) size = 1;
            else size = 2;
        }
    }
    
    public ValueStatement(int level, Integer val, String name, int row, int col) {
        this(level, val, row, col);
        this.name = name;
    }

    @Override
    public int get_type() { return Statement.VALUE_ORIENTED; }

    @Override
    protected Hashtable gget_code() { return null; }

    @Override
    protected Integer gget_val() { return value; }

    @Override
    protected boolean iis_available(boolean relative_enough) {
        return value_resolved;
    }

}
