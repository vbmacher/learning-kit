/*
 * CompEnv.java
 *
 * Created on Pondelok, 2007, okt�ber 8, 18:08
 *
 * KEEP IT SIMPLE, STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 *
 * Compile environment stores all labels, equs, sets and macros in some level.
 * This is something like symbol table
 */

package compiler8080;

import java.util.*;
import compiler8080.SyntaxTree.*;


/**
 * Compiler environment on one compile level.
 * 
 */
public class CompEnv {
    private Hashtable labels = new Hashtable();
    private Hashtable macros = new Hashtable();
    private Hashtable equs = new Hashtable();
    private Hashtable sets = new Hashtable();
    
    // temp address used for macro definitions and calls
    public int tmpadr = 0;

    
    // check if id is already defined (as whatever)
    private boolean id_exists(String name) {
        if (labels.containsKey(name)) return true;
        if (macros.containsKey(name)) return true;
        if (equs.containsKey(name)) return true;
        if (sets.containsKey(name)) return true;
        return false;
    }
    
    /**
     * Method adds label definition to compile environment
     * @param name Name of identifier
     * @return true if label was added successfuly, false if not
     */
    public boolean add_label(String name, ValueStatement address) {
        String un = name.toUpperCase();
        if (id_exists(un)) return false;
        labels.put(un, address);
        return true;
    }
    
    
    /**
     * Method gets address of an existing label
     * @param name Name of label
     * @return address of label
     */
    public ValueStatement get_label(String name) {
        String un = name.toUpperCase();
        return (ValueStatement)labels.get(un);
    }
    
    /**
     * Method adds macro definition to compile environment
     * @param name Name of identifier
     * @return true if macro was added successfuly, false if not
     */
    public boolean add_macro(String name, Macro macro) {
        String un = name.toUpperCase();
        if (id_exists(un)) return false;
        macros.put(un, macro);
        return true;
    }
    
    /**
     * Method gets existing macro
     * @param name Name of the macro
     * @return Macro
     */
    public Macro get_macro(String name) {
        String un = name.toUpperCase();
        return (Macro)macros.get(un);
    }
    
    
    /**
     * Method adds equ definition to compile environment
     * @param name Name of identifier
     * @return true if equ was added successfuly, false if not
     */
    public boolean add_equ(String name, ValueStatement stat) {
        String un = name.toUpperCase();
        if (id_exists(un)) return false;
        if (stat.get_type() != Statement.VALUE_ORIENTED) return false;
        equs.put(un, stat);
        return true;
    }
    
    /**
     * Method gets statement of an existing equ
     * @param name Name of equ
     * @return statement of equ
     */
    public ValueStatement get_equ(String name) {
        String un = name.toUpperCase();
        return (ValueStatement)equs.get(un);
    }

    
    /**
     * Method adds or rewrite set definition to compile environment
     * @param name Name of identifier
     * @return true if equ was added successfuly, false if not
     */
    public boolean add_set(String name, ValueStatement stat) {
        String un = name.toUpperCase();
        if (stat.get_type() != Statement.VALUE_ORIENTED) return false;
        sets.remove(un);
        sets.put(un, stat);
        return true;
    }
    
    /**
     * Method gets statement of an existing set
     * @param name Name of set
     * @return statement of set
     */
    public ValueStatement get_set(String name) {
        String un = name.toUpperCase();
        return (ValueStatement)sets.get(un);
    }
    
}
