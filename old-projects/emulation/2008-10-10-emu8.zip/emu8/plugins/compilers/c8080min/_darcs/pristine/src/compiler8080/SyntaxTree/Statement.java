/*
 * Statement.java
 *
 * Created on Sobota, 2007, december 22, 15:51
 *
 * KEEP IT SIMPLE, STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 *
 */

package compiler8080.SyntaxTree;

import java.util.ArrayList;
import java.util.Hashtable;

/**
 * Abstract class for statement (syntax tree node)
 */
public abstract class Statement {
    // values for statement type
    public static final int VALUE_ORIENTED = 0;
    public static final int CODE_ORIENTED = 1;
    
    protected int src_row;
    protected int src_col;

    // for value oriented statements
    protected int size = 0;
    protected boolean value_resolved = false;

    // for code oriented statements
    protected int address = 0;
    protected boolean address_resolved = false;
    protected boolean code_resolved = false;
    
    // on what level this statement exists (0-global,1-first macro, etc.)
    private int level;
    protected ArrayList<Statement> resolve_needs = null;

    public Statement(int level, int row, int col) {
        this.level = level;
        this.src_col = col;
        this.src_row = row;
    }
    
    public Statement(int level, Integer adr, boolean adr_resolved, int row, int col) {
        this(level,row,col);
        if (adr != null) {
            this.address = adr;
            this.address_resolved = adr_resolved;
        }
    }
    
    /**
     * Gets macro embeded level. 0 is global level, 1 first macro, etc.
     * @return macro level
     */
    public int get_level() { return level; }

    /**
     * Gets size of this node. Has mean only for value oriented statements.
     * @return byte count of value
     */
    public int get_size() { return size; }
    
    /**
     * Get statement type - if it is code or value oriented
     */
    public abstract int get_type();
    
    /**
     * Gets result code of instruction
     * @return assembled code if it is available, null if not
     */
    public Hashtable get_code() {
        if (code_resolved == false) return null;
        return gget_code();
    }
    
    /**
     * Abstract method for getting result code of instruction
     */
    protected abstract Hashtable gget_code();
    
    /**
     * Gets result value of this statement
     * @return value if it is available, null if not
     */
    public Integer get_val() {
        if (value_resolved == false) return null;
        return gget_val();
    }
    
    /**
     * Abstract method for getting value of this statement
     */
    protected abstract Integer gget_val();
    
    /**
     * Get address of this statement. Has a mean only if this statement
     * is code oriented.
     * @return address if it is available, null if not
     */
    public Integer get_adr() { 
        if (address_resolved == false) return null;
        return address; 
    }
        

    /**
     * Add resolve-needing object for completing result of this statement
     * (producing compiled code or evaluating a value depending on orientetion
     * of the statement)
     */
    public void add_resolve_need(Statement stat) {
        if (resolve_needs == null) resolve_needs = new ArrayList<Statement>();
        resolve_needs.add(stat);
    }
    
    /**
     * Determine if this statement is complete resolved, or available (either
     * code is produced or value is evaluated). If parameter relative_enough
     * is true, then return true even if this statement isn't resolved completely.
     * But be careful for getting relative values, first don't forget to "relative
     * resolve call"
     * @param relative_enough
     * @return true if results are available, false if not 
     */
    public boolean is_available(boolean relative_enough) {
        if (resolve_needs != null && resolve_needs.isEmpty() == false) {
            if (relative_enough == false) return false;
            else {
                // search for all problem objects if they are relatively available
                for (int i = 0; i < resolve_needs.size(); i++) {
                    if (resolve_needs.get(i).is_available(true) == false)
                        return false;
                }
            }
        }
        return iis_available(relative_enough);
    }
    
    /**
     * Abstract method for getting information about availability of
     * results of this statement
     * @param relative_enough tells if availability of relative results is enough
     * @return true if result is available
     */
    protected abstract boolean iis_available(boolean relative_enough);
    
    /**
     * This is method for try to resolve problems. If all refferenced problems
     * were resolved, then call void method rresolve that perform code-specific
     * operation and finish resolving. It regards relative/absolute addresses.
     * @return true if all problems were resolved, otherwise false
     */
    public boolean resolve(int adr) {
        if ((this.level == 0) && (is_available(false)))
            return true;
        
        address = adr; // set new address (absolute or relative)
        if (this.level == 0) address_resolved = true;
        else {
            // adress is relative
            address_resolved = false;
        }

        int tmpadr = adr;

        // first try to resolve all value oriented statements and only that code
        // statements if all code statements before were resolved successfully
        boolean all = true;
        boolean allCode = true;
        for (int i = 0; i < resolve_needs.size(); i++) {
           Statement st = (Statement)resolve_needs.get(i);
           if (st.get_type() == Statement.VALUE_ORIENTED) {
               if (st.resolve(0) == false) all = false;
           } else if (st instanceof CodeStatement) {
               CodeStatement cst = (CodeStatement)st;
               if (allCode == true && cst.resolve(tmpadr) == false) {
                   all = false;
                   allCode = false;
               }
               // only if code statement was resolved, then move to the next
               // address. Otherwise use the same address and ignore unresolved
               // code statement. So yes, there are only two passes.
               if (allCode == true) tmpadr = cst.this_address();
           }
        }
        // if all statement were successfully resolved, then clear array
        // and do specific oper
        if (all) {
            rresolve();
            if (this.level == 0) resolve_needs.clear();        
        }
        return all;
    }
    
    /**
     * Abstract method for code-specific operation (for finish resolving this
     * statement)
     */
    protected abstract void rresolve();
}
