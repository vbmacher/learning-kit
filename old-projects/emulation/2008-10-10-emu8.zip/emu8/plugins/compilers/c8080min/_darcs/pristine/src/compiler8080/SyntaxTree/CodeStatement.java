/*
 * CodeStatement.java
 *
 * Created on Sobota, 2007, december 22, 22:13
 *
 * KEEP IT SIMPLE, STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 *
 */

package compiler8080.SyntaxTree;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

/**
 *
 * @author vbmacher
 */
public abstract class CodeStatement extends Statement {
    /**
     * This hashtable is supposed to be code handler. Its keys are addresses
     * of compiled code and its values are Code class objects
     */
    protected Hashtable code = null;
    
    // for macro call needs
    protected Macro macro;
    protected Vector parameters;


    public class Code {
        private String code;
        private int size;
        public Code(String code, int size) {
            this.code = code;
            this.size = size;
        }
        public String getCode() { return code; }
        public int getSize() { return size; }
    }
    /**
     * This constructor tries to join codes of both statements
     * @param level compiler level (0-global, 1-first macro, etc.)
     * @param stat1 first statement, can't be null
     * @param stat2 second statement, can be null
     */
    public CodeStatement(int level, Statement stat1, Statement stat2,
            int row, int col) {
        super(level, stat1.get_adr(), stat1.address_resolved, row,col);
        code = new Hashtable();
        
        // here relative availability is not enough, because
        // then will be lost all resolve_need objects for relative resolving
        if ((stat1.is_available(false) == false)
                || ((stat2 != null) && (stat2.is_available(false) == false))) {
            add_resolve_need(stat1);
            if (stat2 != null) add_resolve_need(stat2);
            code_resolved = false;
        } else {
            try { code.putAll(stat1.get_code()); }
            catch(NullPointerException e) {}
            if (stat2 != null)
                try { code.putAll(stat2.get_code()); }
                catch(NullPointerException e) {}
            code_resolved = true;
        }
    }
    
    public CodeStatement(int level, Statement stat1, int row, int col) {
        this(level, stat1, null, row, col);
    }
    
    public CodeStatement(int level, Integer adr, boolean adr_resolved,int row, int col) {
        super(level, adr, adr_resolved, row,col);
        this.code = new Hashtable();
        this.code_resolved = false;
    }
    
    public CodeStatement(int level, int adr, boolean adr_res, int row, int col,
            Macro macro_deep_copy, Vector parameters) {
        this(level, adr, adr_res, row, col);
        this.macro = macro_deep_copy;
        this.parameters = parameters;
    }

    public CodeStatement(int level, int adr, boolean adr_res, int row, int col,
            Macro macro) {
        this(level, adr, adr_res, row, col);
        this.macro = macro;
    }
            
    
    public void add_code(int address, String co, int size, boolean resolved) {
        code.put(address, new Code(co,size));
        this.code_resolved = resolved;
    }
    
    public void add_code(int address, Code c, boolean resolved) {
        code.put(address, c);
        this.code_resolved = resolved;
    }
    
    /**
     * Method is used for empty code statements
     */
    public void resolve_code() { code_resolved = true; }

    @Override
    public int get_type() { return Statement.CODE_ORIENTED; }
    @Override
    protected Hashtable gget_code() { return code; }
    @Override
    protected Integer gget_val() { return null; }
    @Override
    protected boolean iis_available(boolean relative_enough) { 
        if (relative_enough) return code_resolved;
        return (code_resolved && address_resolved);
    }
    
    /**
     * For code statements, size represents the opcode length in bytes.
     * It is size of all code elements with respect of their address.
     * It is supposed that codes in hashtable are sorted. Then size is
     * computed like this:
     * 
     * size = last_item_address + last_item_size - first_item_address
     * 
     * But what if addresses aren't sorted ?
     * 
     * size = max_address + max_address_item_size - min_address
     * 
     * max_address - address+size is maximal
     * min_address - address is minimal
     * @return size of this code statement
     */
    @Override
    public int get_size() {
        int max_adrsize = 0;
        int min_adr = -1;
        int s = 0;
        
        for (Enumeration e  = code.keys(); e.hasMoreElements(); ) {
            int adr = (Integer)e.nextElement();
            Code c = (Code)code.get(adr);
            if (adr + c.getSize() > max_adrsize)
                max_adrsize = adr + c.getSize();
            if ((min_adr == -1) || (adr < min_adr)) min_adr = adr;
        }
        s = max_adrsize - min_adr;
        if (min_adr == -1) return 0;
        return s;
    }
    
    /**
     * Method determine start address of this code statement. It is a minimal
     * address from hashtable
     * @return address of this code statement (but be careful, this address can
     * be also relative)
     */
    public int this_address() {
        int min_adr = -1;
        for (Enumeration e  = code.keys(); e.hasMoreElements(); ) {
            int adr = (Integer)e.nextElement();
            Code c = (Code)code.get(adr);
            if ((min_adr == -1) || (adr < min_adr)) min_adr = adr;
        }
        return min_adr;
    }

}

