#!/bin/bash
~/bin/jflex-1.4.1/bin/jflex lexer8080.flex