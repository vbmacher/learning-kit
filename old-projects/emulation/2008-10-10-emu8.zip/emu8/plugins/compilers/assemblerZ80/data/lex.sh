#!/bin/bash
~/bin/jflex-1.4.2/bin/jflex lexer.flex
