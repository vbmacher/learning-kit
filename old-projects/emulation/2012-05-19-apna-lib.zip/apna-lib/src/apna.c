/**
 * apna.c
 *
 * (c) Copyright 2011, P. Jakubčo
 *
 * KISS, YAGNI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <pthread.h>

#include "include/apna.h"
#include "include/apna_vars.h"
#include "include/cunit.h"

volatile unsigned char *pmem; // program memory
volatile unsigned char *dmem; // data memory

static volatile int run_state;
pthread_t apna_thread;

// prototypes
void *run(void *arg);


/**
 * Initializes the APNA emulator library. This procedure should be called first, before other function calls.
 *
 * @param program_memory Allocated program memory
 * @param data_memory Allocated data memory
 */
void apna_init(unsigned char *program_memory, unsigned char*data_memory) {
  run_state = STATE_STOPPED_BREAK;
  pmem = program_memory;
  dmem = data_memory;
  cu_init();
}

/**
 * Get APNA emulator thread.
 *
 * @return thread address if APNA emulator is running, NULL otherwise
 */
pthread_t *apna_get_thread() {
  if (run_state != STATE_RUNNING)
    return NULL;
  return &apna_thread;
}

/**
 * Destroys the APNA emulator library. This should be called when finishing program.
 */
void apna_destroy() {
 pthread_exit(NULL);
}

/**
 * Get copytight of the APNA emulator.
 *
 * @return string representation of copyright
 */
const char *apna_get_copyright() {
  return COPY_STRING;
}

/**
 * Get title of the APNA emulator.
 *
 * @return string representation of title
 */
const char *apna_get_title() {
  return TITLE_STRING;
}

/**
 * Get version of the APNA emulator.
 *
 * @return string representation of version
 */
const char *apna_get_version() {
  return VERSION_STRING;
}

/**
 * Reset the APNA emulator. Set it to the breakpoint state.
 */
void apna_reset() {
  apna_stop();
  cu_reset();
  run_state = STATE_STOPPED_BREAK;
}

/**
 * Perform single step of APNA emulator.
 *
 * If the emulator is not in the breakpoint state, nothing will be performed.
 */
void apna_step() {
  if (run_state == STATE_STOPPED_BREAK) {
    run_state = STATE_RUNNING;
    run_state = cu_step(run_state, 0);
    if (run_state == STATE_RUNNING) {
      run_state = STATE_STOPPED_BREAK;
    }
  }
}

/**
 * Pause APNA emulator (set to breakpoint state).
 */
void apna_pause() {
  run_state = STATE_STOPPED_BREAK;
}

/**
 * Force to stop APNA emulator.
 */
void apna_stop() {
  run_state = STATE_STOPPED_NORMAL;
}

/**
 * Starts APNA emulator in separate thread.
 *
 * If the emulator is not in the breakpoint state, nothing will be performed.
 */
void apna_execute() {
  long t;
  int rc;
  pthread_attr_t attr;

  if (run_state != STATE_STOPPED_BREAK)
    return;
  
  run_state = STATE_RUNNING;
  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
  rc = pthread_create(&apna_thread, &attr, run, (void *)t);
  pthread_attr_destroy(&attr);
  if (rc) {
    fprintf(stderr,"Error(%d): can't create main thread.\n", rc);
    run_state = STATE_STOPPED_NORMAL;
  }
}

/**
 * Thread working function.
 */
void *run(void *arg) {
  run_state = STATE_RUNNING;
  int cu_rs = STATE_RUNNING;

  while ((run_state == STATE_RUNNING) && (cu_rs == STATE_RUNNING)) {
    cu_rs = cu_step(run_state, 1);
  }
  if (run_state != STATE_STOPPED_BREAK) 
    cu_stop();
  if ((cu_rs != STATE_RUNNING) && (run_state == STATE_RUNNING))
    run_state = cu_rs;
  pthread_exit(NULL);
}

