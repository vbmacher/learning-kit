/**
 * pe.c
 *
 * (c) Copyright 2011, P. Jakubčo
 *
 * KISS, YAGNI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include "include/apna_vars.h"
#include "include/cunit.h"
#include "include/pe.h"

static volatile unsigned char PC[PE_MAX]; // program counter inside private program memory
static volatile unsigned char flags[PE_MAX]; // flags

static volatile unsigned long A[PE_MAX];
static volatile unsigned long B[PE_MAX];
static volatile unsigned long P[PE_MAX];
static volatile unsigned long M[PE_MAX];

pthread_t PE[PE_MAX];

volatile unsigned char memory[PE_MAX][PRIVATE_MEMORY_SIZE];
volatile unsigned char pe_run_state[PE_MAX];

/* For future disassembler */
static volatile unsigned char* mnemo[] = { "exit", "loadb", "loadm", "loadp", "loadsp", "loadi", "store", "storeb", "storem", "storep", "storesp",
                                           "push", "pushpn", "pop", "poppn", "add", "sub", "and", "or", "xor", "not", "shr", "shl", "ret", "cas", 
                                           "setg0","setg1","setg2","clrg0","clrg1","clrg2","cg0s","cg0z","cg0p","cg0c","cg1s","cg1z","cg1p","cg1c",
                                           "cg2s","cg2z","cg2p","cg2c","test","cmp","mul","div","load","inc","dec","call","sqrt" };

static volatile unsigned char runned[PE_MAX];

// prototypes
void *pe_run(void *ip);
void pe_setlogical(int i, unsigned long reg);
void pe_setarith(int i,unsigned long reg);
void pe_ssetarith(int i, unsigned long reg, unsigned char carry);
void pe_evalInstr(int i);

/**
 * Initializes all PEs. Should be called first, before other functions call.
 */
void pe_init() {
  int i;
  for (i = 0; i < PE_MAX; i++) {
    pe_run_state[i] = STATE_STOPPED_BREAK;
    runned[i] = 0;
  }
}

/**
 * Resets this PE. Should be run before execution, or after marking update.
 *
 * @param i index of PE
 * @param clear_memory 1 if private memory should be cleared, 0 otherwise.
 */
void pe_reset(int i, unsigned char clear_memory) {
  pe_stop(i,1);
  PC[i] = 0;
  flags[i] = 0;
  A[i] = B[i] = P[i] = M[i] = 0;
  pe_run_state[i] = STATE_STOPPED_BREAK;

  int j;
  if (clear_memory)
    for (j = 0; j < PRIVATE_MEMORY_SIZE; j++) {
        memory[i][j] = 0;
    }
}

/**
 * Stops a PE.
 *
 * @param i index of PE
 * @param force 1 if a stop should be forced, 0 otherwise
 */
void pe_stop(int i, unsigned char force) {
  pe_run_state[i] = STATE_STOPPED_NORMAL;
  if (force && runned[i]) {
    pthread_testcancel();
    int rc = pthread_join(PE[i], NULL);
    fprintf(stderr, "Joining thread PE[%d], error: %d\n", i, rc);
    while (rc = pthread_cancel(PE[i]));
    fprintf(stderr, "Cancelling thread PE[%d], error: %d\n", i, rc);
    runned[i] = 0;
  }
}

/**
 * Starts a PE in a thread.
 *
 * @param i index of the PE
 */
void pe_start(int i) {
  int rc;
  pthread_attr_t attr;  
  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

  if (runned[i])
    pe_stop(i, 1);
  rc = pthread_create(&PE[i], &attr, pe_run, (void *)i);
  pthread_attr_destroy(&attr);
  if (rc)
    fprintf(stderr,"Error(%d): can't create thread for PE[%d]\n", rc, i);
  runned[i] = 1;
}

/**
 * Get a run state of a PE.
 *
 * @param i index of the PE
 * @return STOPPED_BREAK, STOPPED_NORMAL, STOPPED_BAD_INSTR, STOPPED_ADDR_FALLOUT, RUNNING
 */
unsigned char pe_get_run_state(int i) {
  return pe_run_state[i];
}

/**
 * Thread working function for PE execution
 *
 * @param ip index of the PE.
 */
void *pe_run(void *ip) {
  int i = (int)ip;
  pe_run_state[i] = STATE_RUNNING;

  while ((PC[i] < PRIVATE_MEMORY_SIZE) && (pe_run_state[i] == STATE_RUNNING)) {
    pe_evalInstr(i);
//    if (pe_getBreakpoint(PC) == 1) {
//    run_state = STATE_STOPPED_BREAK;
//        break;
  //     }
  }

  // is this necessary?
  if (pe_run_state[i] = STATE_RUNNING) {
    pe_run_state[i] = STATE_STOPPED_NORMAL;
  }
  runned[i] = 0;
//fprintf(stderr, "Exiting PE[%d].\n", i);
  pthread_exit(0);
}

/**
 * Set arithmetical flags.
 *
 * @param i the PE index
 * @param reg the value
 */
void pe_setarith(int i,unsigned long reg) {
  pe_ssetarith(i,reg,1);
}
    
/**
 * Set the <C>arry, <S>ign, <Z>ero and <P>arity flags following
 * an arithmetic operation on 'reg'.
 *
 * @param i the PE index
 * @param reg the value
 * @param carry 1 if carry flag should be updated, 0 otherwise
 */
void pe_ssetarith(int i, unsigned long reg, unsigned char carry) {
  if (carry) {
    if ((reg & 0x100000000L) != 0)
      flags[i] |= FLAG_CARRY;
    else
      flags[i] &= (~FLAG_CARRY);
  }
  if ((reg & 0x8000) != 0)
    flags[i] |= FLAG_SIGN;
  else
    flags[i] &= (~FLAG_SIGN);

  if ((reg & 0xFFFFFFFFL) == 0)
    flags[i] |= FLAG_ZERO;
  else
    flags[i] &= (~FLAG_ZERO);

  reg = (reg & 1) ^ (reg & 2) ^ (reg & 4) ^ (reg & 8) ^ (reg & 0x10) ^ (reg & 0x20)
        ^ (reg & 0x40) ^ (reg & 0x80) ^ (reg & 0x100) ^ (reg & 0x200) ^ (reg & 0x400) ^ (reg & 0x800)
        ^ (reg & 0x1000) ^ (reg & 0x2000) ^ (reg & 0x4000) ^ (reg & 0x8000) ^ (reg & 0x10000) ^ (reg & 0x20000)
        ^ (reg & 0x40000) ^ (reg & 0x80000) ^ (reg & 0x100000) ^ (reg & 0x200000) ^ (reg & 0x400000) ^ (reg & 0x800000)
        ^ (reg & 0x1000000) ^ (reg & 0x2000000) ^ (reg & 0x4000000) ^ (reg & 0x8000000) ^ (reg & 0x10000000) ^ (reg & 20000000)
        ^ (reg & 0x40000000) ^ (reg & 0x80000000);
  if (reg == 0)
    flags[i] |= FLAG_PARITY;
  else
    flags[i] &= (~FLAG_PARITY);
}

/**
 * Set the <C>arry, <S>ign, <Z>ero amd <P>arity flags following
 * a logical (bitwise) operation on 'reg'.
 *
 * @param i the PE index
 * @param reg the value
 */
void pe_setlogical(int i, unsigned long reg) {
  flags[i] &= (~FLAG_CARRY);
  if ((reg & 0x8000) != 0)
    flags[i] |= FLAG_SIGN;
  else
    flags[i] &= (~FLAG_SIGN);
  if ((reg & 0xFFFFFFFFL) == 0)
    flags[i] |= FLAG_ZERO;
  else
    flags[i] &= (~FLAG_ZERO);

  reg = (reg & 1) ^ (reg & 2) ^ (reg & 4) ^ (reg & 8) ^ (reg & 0x10) ^ (reg & 0x20)
        ^ (reg & 0x40) ^ (reg & 0x80) ^ (reg & 0x100) ^ (reg & 0x200) ^ (reg & 0x400) ^ (reg & 0x800)
        ^ (reg & 0x1000) ^ (reg & 0x2000) ^ (reg & 0x4000) ^ (reg & 0x8000) ^ (reg & 0x10000) ^ (reg & 0x20000)
        ^ (reg & 0x40000) ^ (reg & 0x80000) ^ (reg & 0x100000) ^ (reg & 0x200000) ^ (reg & 0x400000) ^ (reg & 0x800000)
        ^ (reg & 0x1000000) ^ (reg & 0x2000000) ^ (reg & 0x4000000) ^ (reg & 0x8000000) ^ (reg & 0x10000000) ^ (reg & 20000000)
        ^ (reg & 0x40000000) ^ (reg & 0x80000000);
  if (reg == 0)
    flags[i] |= FLAG_PARITY;
  else
    flags[i] &= (~FLAG_PARITY);
}

/**
 * Execute single instruction of a PE.
 *
 * @param i the PE index
 */
inline void pe_evalInstr(int i) {
  unsigned long X, tmp;
  unsigned char eta = cu_getEta();
  unsigned char opcode = memory[i][PC[i]++];
  int j;

  switch (opcode) {
    case 0x01: // LOADB
      A[i] = B[i];
      pe_ssetarith(i,B[i],0);
      break;
    case 0x02: // LOADM
      A[i] = M[i];
      pe_ssetarith(i,M[i],0);
      break;
    case 0x03: // LOADP
      A[i] = P[i];
      pe_ssetarith(i,P[i],0);
      break;
    case 0x04: // LOADSP
      while (T) {
        // wait
      }
      T = 1;
      A[i] = SP & 0xFFFFFFFFL;
      pe_ssetarith(i,A[i],0);
      T = 0;
      break;
    case 0x06: // STORE
      while (T) {
        // wait
      }
      T = 1;
      dmem[M[i]] = A[i] & 0xFF;
      dmem[M[i]+1] = ((A[i] >> 8) & 0xFF);
      dmem[M[i]+2] = ((A[i] >> 16) & 0xFF);
      dmem[M[i]+3] = ((A[i] >> 24) & 0xFF);
      T = 0;
      break;
    case 0x07: // STOREB
      B[i] = A[i];
      break;
    case 0x08: // STOREM
      M[i] = A[i];
      break;
    case 0x09: // STOREP
      P[i] = A[i];
      break;
    case 0x0A: // STORESP
      while (T) {
        // wait
      }
      T = 1;
      SP = A[i] & 0xFFFFFFFFL;
      T = 0;
      break;
    case 0x0B: // PUSH
      while (T) {
        // wait
      }
      T = 1;
      dmem[(SP-1)&0xFFFFFFFFL] = (A[i] >> 24) & 0xFF;
      dmem[(SP-2)&0xFFFFFFFFL] = (A[i] >> 16) & 0xFF;
      dmem[(SP-3)&0xFFFFFFFFL] = (A[i] >> 8) & 0xFF;
      dmem[(SP-4)&0xFFFFFFFFL] = A[i] & 0xFF;
      SP = (SP - 4)&0xFFFFFFFFL;
      T = 0;
      break;
    case 0x0C: // PUSHPN
      while (T) {
        // wait
      }
      T = 1;
      for (j = 0; j < eta; j++) {
        dmem[(SP-1)&0xFFFFFFFFL] = cu_getU(j) & 0xFF;
        SP = (SP - 1)&0xFFFFFFFFL;
      }
      dmem[(SP-1)&0xFFFFFFFFL] = 0;
      dmem[(SP-2)&0xFFFFFFFFL] = 0;
      dmem[(SP-3)&0xFFFFFFFFL] = (cu_getGuards() >> 8) & 0xFF;
      dmem[(SP-4)&0xFFFFFFFFL] = cu_getGuards() & 0xFF;
      SP = (SP - 4)&0xFFFFFFFFL;
      T = 0;
      break;
    case 0x0D: // POP
      while (T) {
        // wait
      }
      T = 1;
      A[i] = (dmem[SP]&0xFF);
      A[i] += (dmem[(SP+1)&0xFFFFFFFFL]&0xFF) << 8;
      A[i] += (dmem[(SP+2)&0xFFFFFFFFL]&0xFF) << 16;
      A[i] += (dmem[(SP+3)&0xFFFFFFFFL]&0xFF) << 24;
      SP = (SP + 4)&0xFFFFFFFFL;
      pe_ssetarith(i,A[i],0);
      T = 0;
      break;
    case 0x0E: // POPPN
      while (T) {
        // wait
      }
      T = 1;
      X = (dmem[SP]&0xFF);
      X += (dmem[(SP+1)&0xFFFFFFFFL]&0xFF) << 8;
      SP = (SP + 4)&0xFFFFFFFFL; // ignore 0
      cu_setGuards(X);
      for (j = eta - 1; j >= 0; j--) {
        U[j] = dmem[SP] & 0xFF;
        SP = (SP + 1)&0xFFFFFFFFL;
      }
      T = 0;
      break;
    case 0x0F: // ADD
      A[i] = A[i] + B[i];
      pe_setarith(i,A[i]);
      A[i] = (A[i] & 0xFFFFFFFFL);
      break;
    case 0x10: // SUB
      A[i] = A[i] - B[i];
      pe_setarith(i,A[i]);
      A[i] = (A[i] & 0xFFFFFFFFL);
      break;
    case 0x11: // AND
      A[i] &= B[i];
      pe_setlogical(i,A[i]);
      A[i] &= 0xFFFFFFFFL;
      break;
    case 0x12: // OR
      A[i] |= B[i];
      pe_setlogical(i,A[i]);
      A[i] &= 0xFFFFFFFFL;
      break;
    case 0x13: // XOR
      A[i] ^= B[i];
      pe_setlogical(i,A[i]);
      A[i] &= 0xFFFFFFFFL;
      break;
    case 0x14: // NOT
      A[i] = ~A[i];
      pe_setlogical(i,A[i]);
      A[i] &= 0xFFFFFFFFL;
      break;
    case 0x15: // SHR
      A[i] >>= 1;
      if ((flags[i] & FLAG_CARRY) != 0)
        A[i] |= 0x8000;
      A[i] &= 0xFFFFFFFF;
      break;
    case 0x16: // SHL
      if ((A[i] & 0x8000) == 0x8000)
        flags[i] |= FLAG_CARRY;
      else 
        flags[i] &= (~FLAG_CARRY);
      A[i] <<= 1;
      A[i] &= 0xFFFFFFFF;
      break;
    case 0x17: // RET
      while (T) {
        // wait
      }
      T = 1;
      X = dmem[SP] & 0xFF;
      X += (dmem[(SP+1)&0xFFFFFFFFL] & 0xFF) << 8;
      SP = (SP + 4)&0xFFFFFFFFL;
      cu_setGuards(X);

      tmp = dmem[SP] & 0xFF;
      tmp += (dmem[(SP+1)&0xFFFFFFFFL] & 0xFF) << 8;
      tmp += (dmem[(SP+2)&0xFFFFFFFFL] & 0xFF) << 16;
      tmp += (dmem[(SP+3)&0xFFFFFFFFL] & 0xFF) << 24;

      SP = (SP + 4)&0xFFFFFFFFL;
      if (Aps != tmp) {
        Aps = tmp;
        cu_mapSeta();
        eta = cu_getEta();
        for (j = 0; j < eta; j++)
          cu_mapSw(j);
        cu_clearMapTable(0);
      }
      for (j = eta - 1; j >= 0; j--) {
        U[j] = dmem[SP] & 0xFF;
        SP = (SP + 1)&0xFFFFFFFFL;
      }
      cu_clearMapTable(1); // force to not update marking
      T = 0;
      break;
    case 0x18: // CAS
      while (T) {
        // wait
      }
      T = 1;
      X = dmem[M[i]] & 0xFF;
      X += (dmem[M[i]+1] & 0xFF) << 8;
      X += (dmem[M[i]+2] & 0xFF) << 16;
      X += (dmem[M[i]+3] & 0xFF) << 24;
      if (X == A[i]) {
        dmem[M[i]] = B[i] & 0xFF;
        dmem[M[i]+1] = (B[i] >> 8) & 0xFF;
        dmem[M[i]+2] = (B[i] >> 16) & 0xFF;
        dmem[M[i]+3] = (B[i] >> 24) & 0xFF;
      }
      T = 0;
      break;
    case 0x19: // SETG0
      G[0] = 1;
      break;
    case 0x1A: // SETG1
      G[1] = 1;
      break;
    case 0x1B: // SETG2
      G[2] = 1;
      break;
    case 0x1C: // CLRG0
      G[0] = 0;
      break;
    case 0x1D: // CLRG1
      G[1] = 0;
      break;
    case 0x1E: // CLRG2
      G[2] = 0;
      break;
    case 0x1F: // CG0S
      G[0] = ((flags[i] & FLAG_SIGN) != 0);
      break;
    case 0x20: // CG0Z
      G[0] = ((flags[i] & FLAG_ZERO) != 0);
      break;
    case 0x21: // CG0P
      G[0] = ((flags[i] & FLAG_PARITY) != 0);
      break;
    case 0x22: // CG0C
      G[0] = ((flags[i] & FLAG_CARRY) != 0);
      break;
    case 0x23: // CG1S
      G[1] = ((flags[i] & FLAG_SIGN) != 0);
      break;
    case 0x24: // CG1Z
      G[1] = ((flags[i] & FLAG_ZERO) != 0);
      break;
    case 0x25: // CG1P
      G[1] = ((flags[i] & FLAG_PARITY) != 0);
      break;
    case 0x26: // CG1C
      G[1] = ((flags[i] & FLAG_CARRY) != 0);
      break;
    case 0x27: // CG2S
      G[2] = ((flags[i] & FLAG_SIGN) != 0);
      break;
    case 0x28: // CG2Z
      G[2] = ((flags[i] & FLAG_ZERO) != 0);
      break;
    case 0x29: // CG2P
      G[2] = ((flags[i] & FLAG_PARITY) != 0);
      break;
    case 0x2A: // CG2C
      G[2] = ((flags[i] & FLAG_CARRY) != 0);
      break;
    case 0x2B: // TEST
      pe_setlogical(i,A[i] & B[i]);
      break;
    case 0x2C: // CMP
      X = A[i] - B[i];
      pe_setarith(i,X);
      break;
    case 0x2D: // MUL
      A[i] = A[i] * B[i];
      pe_setarith(i,A[i]);
      A[i] = (A[i] & 0xFFFFFFFFL);
      break;
    case 0x2E: // DIV
      A[i] = A[i] / B[i];
      pe_setarith(i,A[i]);
      A[i] = (A[i] & 0xFFFFFFFFL);
      break;
    case 0x2F: // LOAD
      while (T) {
        // wait
      }
      T = 1;
      A[i] = dmem[M[i]] & 0xFF;
      A[i] += (dmem[M[i]+1] & 0xFF) << 8;
      A[i] += (dmem[M[i]+2] & 0xFF) << 16;
      A[i] += (dmem[M[i]+3] & 0xFF) << 24;
      pe_ssetarith(i,A[i],0);
      T = 0;
      break;
    case 0x30: // INC
      A[i]++;
      pe_setarith(i,A[i]);
      A[i] = (A[i] & 0xFFFFFFFFL);
      break;
    case 0x31: // DEC
      A[i]--;
      pe_setarith(i,A[i]);
      A[i] = (A[i] & 0xFFFFFFFFL);
      break;
    case 0x05: // LOADI NN
      opcode = PC[i]++;
      A[i] = memory[i][opcode];
      opcode = PC[i]++;
      A[i] += (memory[i][opcode] << 8);
      opcode = PC[i]++;
      A[i] += (memory[i][opcode] << 16);
      opcode = PC[i]++;
      A[i] += (memory[i][opcode] << 24);
      A[i] &= 0xFFFFFFFFL;
      break;
    case 0x32: // CALL NN
      while (T) {
        // wait
      }
      T = 1;
      opcode = PC[i]++;
      tmp = memory[i][opcode];
      opcode = PC[i]++;
      tmp += (memory[i][opcode] << 8);
      opcode = PC[i]++;
      tmp += (memory[i][opcode] << 16);
      opcode = PC[i]++;
      tmp += (memory[i][opcode] << 24);
      tmp &= 0xFFFFFFFFL;
      cu_updateMarking();
      for (j = 0; j < eta; j++) {
        dmem[(SP-1)&0xFFFFFFFFL] = cu_getU(j) & 0xFF;
        SP = (SP - 1)&0xFFFFFFFFL;
      }
      X = Aps;
      dmem[(SP-4)&0xFFFFFFFFL] = X & 0xFF;
      dmem[(SP-3)&0xFFFFFFFFL] = (X >> 8) & 0xFF;
      dmem[(SP-2)&0xFFFFFFFFL] = (X >> 16) & 0xFF;
      dmem[(SP-1)&0xFFFFFFFFL] = (X >> 24) & 0xFF;
      SP = (SP - 4)&0xFFFFFFFFL;

      dmem[(SP-4)&0xFFFFFFFFL] = cu_getGuards() & 0xFF;
      dmem[(SP-3)&0xFFFFFFFFL] = (cu_getGuards() >> 8) & 0xFF;
      dmem[(SP-2)&0xFFFFFFFFL] = 0;
      dmem[(SP-1)&0xFFFFFFFFL] = 0;
      SP = (SP - 4)&0xFFFFFFFFL;

      if (X != tmp) {
        Aps = tmp;
        cu_mapSeta();
        eta = cu_getEta();
        for (j = 0; j < eta; j++) 
          cu_mapSw(j);
        cu_clearMapTable(0);
      }
      cu_mapU(); // set initial marking
      cu_clearMapTable(1); // force to not update marking
      T = 0;
      break;
    case 0x33: // SQRT
      A[i] = (unsigned long)sqrt(A[i]);
      pe_setarith(i,A[i]);
      A[i] &= 0xFFFFFFFFL;
      break;
    case 0: // EXIT
      PC[i] = 0;
      pe_run_state[i] = STATE_STOPPED_NORMAL;
      break;
    default:
      pe_run_state[i] = STATE_STOPPED_BAD_INSTR;
      break;
    }
}

