/**
 * apna.h
 *
 * (c) Copyright 2011, P. Jakubčo
 *
 * KISS, YAGNI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __APNA_H__
#define __APNA_H__

#include <pthread.h>

/**
 * Initializes the APNA emulator library. This procedure should be called first, before other function calls.
 *
 * @param program_memory Allocated program memory
 * @param data_memory Allocated data memory
 */
void apna_init(unsigned char *program_memory, unsigned char*data_memory);

/**
 * Destroys the APNA emulator library. This should be called when finishing program.
 */
void apna_destroy();

/**
 * Get title of the APNA emulator.
 *
 * @return string representation of title
 */
const char *apna_get_title();

/**
 * Get version of the APNA emulator.
 *
 * @return string representation of version
 */
const char *apna_get_version();

/**
 * Get copytight of the APNA emulator.
 *
 * @return string representation of copyright
 */
const char *apna_get_copyright();

/**
 * Get APNA emulator thread.
 *
 * @return thread address if APNA emulator is running, NULL otherwise
 */
pthread_t *apna_get_thread();

/**
 * Force to stop APNA emulator.
 */
void apna_stop();

/**
 * Starts APNA emulator in separate thread.
 *
 * If the emulator is not in the breakpoint state, nothing will be performed.
 */
void apna_execute();

/**
 * Pause APNA emulator (set to breakpoint state).
 */
void apna_pause();

/**
 * Perform single step of APNA emulator.
 *
 * If the emulator is not in the breakpoint state, nothing will be performed.
 */
void apna_step();

/**
 * Reset the APNA emulator. Set it to the breakpoint state.
 */
void apna_reset();

#endif
