/**
 * cunit.h
 *
 * (c) Copyright 2011, P. Jakubčo
 *
 * KISS, YAGNI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __CUNIT_H__
#define __CUNIT_H__

#define ETA_MAX 64
#define PE_MAX 8

#define STATE_CU 0
#define STATE_PE 1

extern volatile unsigned char Seta;
extern volatile unsigned long Aps;
extern volatile unsigned long SP;
extern volatile unsigned char G[3];
extern volatile unsigned char T;
extern volatile unsigned char U[ETA_MAX]; // actual state vector

/**
 * Initializes control unit. Should be called first, before other function calls.
 */
void cu_init();

/**
 * Resets control unit. Does not clear data memory.
 */
void cu_reset();

/**
 * Perform 1 step of the control unit.
 *
 * @param old     Previous running state
 * @param running 1 if emulation is executed, 0 if it is just stepping
 * @return New running state: STOPPED_BREAK, STOPPED_NORMAL, STOPPED_BAD_INSTR, STOPPED_ADDR_FALLOUT, RUNNING
 */
int cu_step(int old, unsigned char running);

/**
 * Force stop of all process elements (PEs).
 */
void cu_stop();

/**
 * Get all guard flags as a byte.
 *
 * @return byte representing guard flags.
 */
unsigned char cu_getGuards();

/**
 * Set all guard flags from a byte.
 *
 * @param byte representing guard flags.
 */
void cu_setGuards(unsigned char guards);

/**
 * Convert a number into string with specified radix.
 *
 * @param val the number
 * @param base the radix (from 1 to 16)
 * @return string representation of the number in specified radix
 */
char* itoa(int val, int base);

#endif
