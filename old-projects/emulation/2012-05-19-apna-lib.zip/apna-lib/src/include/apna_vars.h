/**
 * apna_vars.h
 *
 * (c) Copyright 2011, P. Jakubčo
 *
 * KISS, YAGNI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __APNA_VARS_H__
#define __APNA_VARS_H__

#define TITLE_STRING "APNA emulator library"
#define VERSION_STRING "0.1b"
#define COPY_STRING "(c) Copyright 2011, P. Jakubco"

/* Running state of the processor */
#define STATE_STOPPED_NORMAL 0
#define STATE_STOPPED_BREAK 1
#define STATE_STOPPED_ADDR_FALLOUT 2
#define STATE_STOPPED_BAD_INSTR 3
#define STATE_RUNNING 4

extern volatile unsigned char *pmem; // program memory
extern volatile unsigned char *dmem; // data memory

#endif
