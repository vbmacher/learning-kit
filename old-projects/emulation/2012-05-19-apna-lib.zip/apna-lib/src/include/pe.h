/**
 * pe.h
 *
 * (c) Copyright 2011, P. Jakubčo
 *
 * KISS, YAGNI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef __PE_H__
#define __PE_H__

  #define PRIVATE_MEMORY_SIZE 32 // in bytes
  #define FLAG_SIGN   0x80
  #define FLAG_ZERO   0x40
  #define FLAG_PARITY 0x20
  #define FLAG_CARRY  0x10

  extern volatile unsigned char memory[PE_MAX][PRIVATE_MEMORY_SIZE];
  extern volatile unsigned char pe_run_state[PE_MAX];

  /**
   * Initializes all PEs. Should be called first, before other functions call.
   */
  void pe_init();

  /**
   * Resets this PE. Should be run before execution, or after marking update.
   *
   * @param i index of PE
   * @param clear_memory 1 if private memory should be cleared, 0 otherwise.
   */
  void pe_reset(int i, unsigned char clear_memory);

  /**
   * Starts a PE in a thread.
   *
   * @param i index of the PE
   */
  void pe_start(int i);

  /**
   * Stops a PE.
   *
   * @param i index of PE
   * @param force 1 if a stop should be forced, 0 otherwise
   */
  void pe_stop(int i, unsigned char force);

  /**
   * Get a run state of a PE.
   *
   * @param i index of the PE
   * @return STOPPED_BREAK, STOPPED_NORMAL, STOPPED_BAD_INSTR, STOPPED_ADDR_FALLOUT, RUNNING
   */
  unsigned char pe_get_run_state(int i);

#endif

