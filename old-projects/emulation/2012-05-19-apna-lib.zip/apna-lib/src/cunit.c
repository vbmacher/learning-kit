/**
 * cunit.c
 *
 * (c) Copyright 2011, P. Jakubčo
 *
 * KISS, YAGNI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "include/apna_vars.h"
#include "include/cunit.h"
#include "include/pe.h"

volatile unsigned char Seta;

volatile unsigned long Aps;
volatile unsigned long SP;
volatile unsigned char G[3];
volatile unsigned char T;
volatile unsigned char U[ETA_MAX]; // actual state vector


static unsigned char Uk[ETA_MAX];     // for actual state vector (number of tokens)
static unsigned char Ul[ETA_MAX];     // for actual state vector (number of free tokens)
static unsigned char SW[ETA_MAX][17]; // rules with guards

static unsigned char mapTable[PE_MAX];
static unsigned char mapIndex;
    
static unsigned char stepState; // State of Control unit. What to do in step() call.

// prototypes
unsigned char cu_getEta();
void cu_mapSw(int i);
void cu_mapSeta();
void cu_mapU();
void cu_clearMapTable(unsigned char onlyMi);
void resetUkl();
const char* cu_getMarking();
unsigned char getU(int index);
unsigned char cu_checkGuards(int i);
unsigned char cu_checkFireable(unsigned char eta, int i);
void cu_mapPE(unsigned char running);
unsigned char cu_runPE();
void cu_updateMarking();

/**
 * Initializes control unit. Should be called first, before other function calls.
 */
void cu_init() {
  stepState = STATE_CU;
}

/**
 * Resets control unit. Does not clear data memory.
 */
void cu_reset() {
  G[0] = 0;
  G[1] = 0;
  G[2] = 0;
  T = 0;
  SP = 0;

  int i,j;
  for (i = 0; i < ETA_MAX; i++) {
    U[i] = 0;
    Uk[i] = 1;
    Ul[i] = 0x7F;
  }
  for (i = 0; i < ETA_MAX; i++)
    for (j = 0; j < 17; j++)
      SW[i][j] = 0;
  Seta = 0;
  Aps = 0;
  mapIndex = 0;

  pe_init();
  for (i=0; i < PE_MAX; i++) {
    pe_reset(i, 1);
    mapTable[i] = 0;
  }        

  // map first procedure
  cu_mapSeta();

  unsigned char eta = cu_getEta();

  for (i = 0; i < eta; i++)
    cu_mapSw(i);

  cu_clearMapTable(0);
  cu_mapU(); // set initial marking

  stepState = STATE_CU;
}

/**
 * Get all guard flags as a byte.
 *
 * @return byte representing guard flags.
 */
unsigned char cu_getGuards() {
  return ((G[2]?1:0) << 2) 
         | ((G[1]?1:0) << 1)
         | (G[0]?1:0);
}

/**
 * Set all guard flags from a byte.
 *
 * @param byte representing guard flags.
 */
void cu_setGuards(unsigned char guards) {
  G[2] = ((guards & 4) == 4);
  G[1] = ((guards & 2) == 2);
  G[0] = ((guards & 1) == 1);
}

/**
 * Maps Seta from the memory, based on actual procedure address.
 */
void cu_mapSeta() {
  Seta = pmem[Aps];
}

/**
 * Get eta, based on Seta.
 *
 * @return eta
 */
unsigned char cu_getEta() {
  switch (Seta) {
    case 1: return 4;
    case 3: return 8;
    case 7: return 16;
    case 15: return 32;
    case 31: return 64;
    default: return -1;
  }
}

/**
 * Maps a rule w_i from the memory into internal register Sw_i.
 *
 * @param i index of the rule
 */
void cu_mapSw(int i) {
  unsigned char eta = cu_getEta();
  unsigned char etaDiv4 = eta/4;

  unsigned long addr = Aps + 1 + eta + (1 + etaDiv4) * i;
  unsigned char exit = 1 + etaDiv4;
  unsigned char k = 16;

  unsigned char j;
  for (j = 0; j < exit; j++, k--) {
    unsigned char val = pmem[addr+j] & 0xFF;
    SW[i][k] = val;
  }
}

/**
 * Clears mapping table. If parameter is true, only M_i bit is
 * cleared for all items.
 * 
 * @param onlyMi 1 if only M_i bits should be cleared, 0 otherwise
 */
void cu_clearMapTable(unsigned char onlyMi) {
  int i;
  for (i = 0; i < PE_MAX; i++)
    if (onlyMi)
      mapTable[i] = mapTable[i] & (~0x40);
    else
      mapTable[i] = 0;
  mapIndex = 0;
}

/**
 * Map actual state vector U from the memory, based on actual procedure address.
 */
void cu_mapU() {
  unsigned char eta = cu_getEta();
  int j;
  for (j = 0; j < eta; j++) {
    U[j] = pmem[Aps + j + 1] & 0xF;
  }
}

/**
 * Force stop of all process elements (PEs).
 */
void cu_stop() {
  int i;
  for (i = 0; i < PE_MAX; i++)
    pe_stop(i, 1);
}

/**
 * Reset Uk and Ul vectors.
 */
void cu_resetUkl() {
  int i;
  for (i = 0; i < ETA_MAX; i++) {
    Uk[i] = 1;
    Ul[i] = 0x7F;
  }        
}

/**
 * Get actual state vector item.
 *
 * @param item index
 * @return actual state vector item
 */
unsigned char cu_getU(int index) {
  if ((index < 0) || (index >= ETA_MAX))
    return 0;
  return U[index];
}

/**
 * Convert a number into string with specified radix.
 *
 * @param val the number
 * @param base the radix (from 1 to 16)
 * @return string representation of the number in specified radix
 */
char* itoa(int val, int base){
 static char buf[32] = {0};
 int i = 30;
 if (!val) {
   buf[30] = '0';
   buf[31] = 0;
   return &buf[30];
 }
 for(; val && i ; --i, val /= base)
   buf[i] = "0123456789abcdef"[val % base];
 return &buf[i+1];
}

/**
 * Get string representation of actual marking, in the form: '(x,x,...,x)', where x is number from 0-8.
 *
 * @return string representation of actual marking
 */
const char* cu_getMarking() {
  char* s = NULL;
  unsigned char eta = cu_getEta();
  int si = 0;

  s = (char *)malloc(sizeof(char) * (2+eta * 2));
  s[si++] = '(';

  unsigned char i,u,mark,k;
  for (i = 0; i < eta; i++) {
    u = cu_getU(i);
    mark = 0;
    for (k = 0; k < 8; k++ ) {
      if ((u & 1) != 0) {
        u >>= 1;
        mark++;
      } else
        break;
    }
    char *sm = itoa(mark,10);
    strcpy((unsigned char *)(s+si), sm);
    si += strlen(sm);
    s[si++] = ',';
  }
  if (s[si-1] == ',')
    si--;
  s[si++] = ')';
  s[si] = 0;
  return s;
}

/**
 * Get string representation of guards of a rule w_i in the form '[GX=xx,...,GZ=zz]', where X,Z,xx,zz are binary numbers.
 *
 * @param index index of the rule w_i
 * @return string representation of guards of a rule w_i
 */
const char* cu_getGuard(int index) {
  if ((index < 0) || (index >= ETA_MAX))
    return NULL;

  static char *gs = NULL;

  if (gs != NULL)
    free(gs);
  gs = (unsigned char*)malloc(sizeof(unsigned char) * 20);

  int gsp = 0;

  gs[gsp++] = '[';
  unsigned char guard = SW[index][16] & 0xFF;

  if ((guard & 2) == 2) {
    gs[gsp++] = 'G';
    gs[gsp++] = '0';
    gs[gsp++] = '=';
    gs[gsp++] = (guard & 1) + '0';
  }
  if ((guard & 8) == 8) {
    if (gs[gsp-1] != '[') {
      gs[gsp++] = ';';
      gs[gsp++] = ' ';
    }
    gs[gsp++] = 'G';
    gs[gsp++] = '1';
    gs[gsp++] = '=';
    gs[gsp++] = ((guard & 4) >> 2) + '0';
  }
  if ((guard & 32) == 32) {
    if (gs[gsp-1] != '[') {
      gs[gsp++] = ';';
      gs[gsp++] = ' ';
    }
    gs[gsp++] = 'G';
    gs[gsp++] = '1';
    gs[gsp++] = '=';
    gs[gsp++] = ((guard & 16) >> 4) + '0';
  }
  gs[gsp++] = ']';
  gs[gsp++] = 0;
  return gs;
}

/**
 * Get string representation of a rule w_i in the form 'xxx...xxx (x,x,x,...,x,x,x)', where x is a binary number.
 *
 * @param index index of the rule w_i
 * @return string representation of w_i
 */
const char *cu_getWi(int index) {
  unsigned char etaDiv4 = (cu_getEta() / 4);
  static char ws[17 * 3 + 5 + 130];
  char *xs, xxs[17*3];
  unsigned char i,j;

  int wsp = 0;
  for (i = 15; i >= 16-etaDiv4; i--) {
    xs = itoa(SW[index][i] & 0xFF, 2);
    for (j = strlen(xs); j <= 8; j++)
      xxs[8-j] = '0';
    strcpy((char*)(xxs+(8-strlen(xs))), xs);
    strcpy((char *)(ws+wsp), xxs);
    wsp += 8;
  }

  // search the string sw
  ws[wsp++] = ' ';
  ws[wsp++] = '(';
  j = 2 * cu_getEta();
  int k,l;
  for (i = 0; i < j; i+=2) {
    k = ws[i];
    l = ws[i+1];
    if (k == '1' && l == '0') {
      ws[wsp++] = '-';
      ws[wsp++] = '1';
      ws[wsp++] = ',';
    } else if (k == '0' && l == '1') {
      ws[wsp++] = '1';
      ws[wsp++] = ',';
    } else {
      ws[wsp++] = '0';
      ws[wsp++] = ',';
    }
  }
  if (ws[wsp-1] == ',')
    wsp--;
  ws[wsp++] = ')';
  ws[wsp] = 0;

  return ws;
}


/**
 * Phase 1. Check guards.
 * @param i - rule index
 * @return 1 if guards are satisfied, 0 otherwise
 */
unsigned char cu_checkGuards(int i) {
  unsigned char ga, gb, M;

//printf("  G[0] = %d\n", (int)G[0]);
  ga = ((SW[i][16] & 2) == 2);
  gb = ((SW[i][16] & 1) == 1);
  M = (ga && gb && G[0]) || (ga && (!gb) && (!G[0])) || (!ga);
//printf("  M[0] = %d\n", (int)M);

  ga = ((SW[i][16] & 8) == 8);
  gb = ((SW[i][16] & 4) == 4);
  M = M && ((ga && gb && G[1]) || (ga && (!gb) && (!G[1])) || (!ga));

  ga = ((SW[i][16] & 32) == 32);
  gb = ((SW[i][16] & 16) == 16);
  M = M && ((ga && gb && G[2]) || (ga && (!gb) && (!G[2])) || (!ga));
  return M;
}

/**
 * Phase 2a. Checks if a rule is fireable.
 * 
 * @param eta - Eta- number of places, or number of transitions.
 * @param i - rule index
 * @return 1 if the rule is fireable, 0 otherwise
 */
unsigned char cu_checkFireable(unsigned char eta, int i) {
  unsigned char wb, wa,uk,ul, M;
  unsigned char ukls[ETA_MAX];
  int j;

  for (j = 0; j < ETA_MAX; j++)
    ukls[j] = 0;  


  // nemoze byt odpalitelny prechod ktory nema pre-miesto
  M = 0;
  for (j = 0; j < 16; j++) {
    if ((SW[i][j] & 0xFF) != 0) {
      M = 1;
      break;
    }
  }
  if (M == 0)
    return 0;

  for (j = 0; j < eta; j++) {
    int bajt = 1 + j/4;
    int k = 1 << (7- (2 * j)%8);
    int l = (k >> 1);
 
    wa = (SW[i][16-bajt] & k) == k;
    wb = (SW[i][16-bajt] & l) == l;
    uk = ((Uk[j] & U[j]) != 0);
            
    ul = ((~(Ul[j] | U[j])) != 0);
    M = M && (((!wb) && uk) || ((!wa) && ul) || ((!wa) && (!wb)));
    if (uk && wa && (!wb)) // len ak sa meni marking
      ukls[j] |= 1;
    if (ul && (!wa) && (wb))
      ukls[j] |= 2;
  }
  if (M) {
    for (j = 0; j < ETA_MAX; j++) {
      int g = ukls[j];
      if (g & 1) {
        Uk[j] <<= 1;
        Uk[j] &= 0xFE;
      }
      if (g & 2) {
        Ul[j] >>= 1;
        Ul[j] &= 0x7F;
      }
    }
  }
  return M;
}

/**
 * Phase 2b. Procedure maps code segments to PE according to mapTable
 * @param running whether the emulation is running or just stepping
 */
void cu_mapPE(unsigned char running) {
  unsigned char eta = cu_getEta();
  unsigned long base_addr = Aps + 1 + 2* eta + (eta * eta)/4;

  int i,j;
  for (i = 0; i < PE_MAX; i++) {
    unsigned char map = mapTable[i];
    if ((mapTable[i] & 0xC0) == 0xC0) {// mapped already
      pe_reset(i, 0);
      continue;            
    }
    if ((mapTable[i] & 0x40) != 0x40) // Mi
      continue;
    unsigned long addr = base_addr + (map & 0x3F) * PRIVATE_MEMORY_SIZE;

    for (j = 0; j < PRIVATE_MEMORY_SIZE; j++)
      memory[i][j] = pmem[addr+j];
      mapTable[i] = map | 0xC0; // Pi
  }
}

/**
 * Phase 3. Executes all mapped PEs.
 * @return 1 if marking was updated, 0 otherwise.
 */
unsigned char cu_runPE() {
  int rs = STATE_STOPPED_NORMAL;
  int i;
//  printf("Im gonna run PEs...\n");

  for (i = 0; i < PE_MAX; i++) {
    unsigned char map = mapTable[i];
    if ((map & 0xC0) != 0xC0)
      continue;
    pe_start(i);
  }
  for (i = 0; i < PE_MAX; i++) {
    pe_stop(i, 0);
    if (pe_get_run_state(i) == STATE_STOPPED_BREAK) {
      rs = STATE_STOPPED_BREAK;
      break;
    }
  }
  if (rs != STATE_STOPPED_BREAK) {
    cu_updateMarking();
    for (i = 0; i < PE_MAX; i++)
      mapTable[i] &= ~(0x40); // Clear Mi, this should be recreated
    return 1;
  }
  return 0;
}
        
/**
 * Phase 4. Update marking.
 */
void cu_updateMarking() {
  unsigned char eta = cu_getEta();
  unsigned char wa,wb;
  int i,j;

  for (i = 0; i < PE_MAX; i++) {
    unsigned char Mi = ((mapTable[i] & 0x40) == 0x40);
    if (!Mi)
      continue;
    int index = mapTable[i] & 0x3F;
    for (j = 0; j < eta; j++) {
      int bajt = 1 + j/4;
      int k = 1 << (7- (2 * j)%8);
      int l = (k >> 1);

      wa = (SW[index][16-bajt] & k) == k;
      wb = (SW[index][16-bajt] & l) == l;

      if (!wa && wb) {
          U[j] <<= 1;
          U[j] |= 1;
      } else if (wa && !wb) {
          U[j] >>= 1;
      }
    }
  }
}

/**
 * Perform 1 step of the control unit.
 *
 * @param old     Previous running state
 * @param running 1 if emulation is executed, 0 if it is just stepping
 * @return New running state: STOPPED_BREAK, STOPPED_NORMAL, STOPPED_BAD_INSTR, STOPPED_ADDR_FALLOUT, RUNNING
 */
int cu_step(int old, unsigned char running) {
  unsigned char eta = cu_getEta();
  unsigned char done, error=0;

  if (!running) {
    printf("Start of step. State: %s\n", ((stepState == STATE_CU) ? "Control unit" : "Process elements"));
  }
  if (stepState == STATE_CU) {
    cu_resetUkl();
    if (!running) {
      char *s = (char*)cu_getMarking();
      printf("Marking: %s\n", s);
      free(s);
    }

    unsigned char mapped = 0;
    unsigned char i;
    for (i = 0; i < eta; i++) {
      if (!running)
        printf("Checking w_%d=%s %s\n", i, cu_getGuard(i), cu_getWi(i));
      if (!cu_checkGuards(i))
        continue;
      if (!cu_checkFireable(eta, i))
        continue;
      mapped = 1;
      // check if PE is already mapped
      done = 0;
      for (mapIndex = 0; mapIndex < PE_MAX; mapIndex++) {
        if (((mapTable[mapIndex] & 0xC0) == 0)) // if P=0 and M=0
          break;
        if (((mapTable[mapIndex] & 0x80) == 0x80) && // if P=1
            ((mapTable[mapIndex] & 0x3F) == i)) {
          mapTable[mapIndex] |= 0x40; // let M=1
          if (!running)
           printf("  Sw[%d] already mapped to PE %d\n", i,mapIndex);
          done = 1;
          break;
        }
      }                
      if (!done) {
        if (mapIndex == PE_MAX) {
          for (mapIndex =0; mapIndex < PE_MAX; mapIndex++){
            if ((mapTable[mapIndex] & 0x40) == 0) {
              if (!running)
                printf("Warning: mapTable is full. PE %d will be remapped.\n", mapIndex);
              done = 1;
              break;
            }
          }
        } else
          done = 1;
        if (done) {
          mapTable[mapIndex] = 0x40 + (i & 0x3F);
          if (!running)
            printf("  Sw[%d] mapped to PE %d\n", i, mapIndex);
        } else {
          error = 1; // there is no place in the mapTable
          break;
        }
      }
    }
    if (!mapped) {
      if (eta == -1)
        old = STATE_STOPPED_BAD_INSTR;
      else if (error) 
        old = STATE_STOPPED_ADDR_FALLOUT;
      else
        old = STATE_STOPPED_NORMAL;
    } else {
        cu_mapPE(running);
      stepState = STATE_PE;
    }
  } else if (stepState == STATE_PE) {
    if (!running)
      printf("Executing PEs...\n");
    unsigned char updated;
    updated = cu_runPE();
    if (updated && (!running)) {
      char *s = (char*)cu_getMarking();
      printf("New marking: %s\n", s);
      free(s);
    }
        
    if (!updated) {
      old = STATE_STOPPED_BREAK;
    } else {
      stepState = STATE_CU;
    }
  }
  if (!running)
    printf("End of step.\n");
  return old;
}

