/**
 * test.c
 *
 * Test for executing program in APNA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "apna.h"


int main() {
  FILE *fin;
  FILE *fout;
  unsigned char *pmem;
  unsigned char *dmem;
  pthread_t *apna;

  fin = fopen("fact.bin","rb");
  if (fin == NULL) {
    printf("Error: Cannot open file fact!\n");
    return 2;
  }

  pmem = (unsigned char *)malloc(sizeof(unsigned char) * 65536);
  dmem = (unsigned char *)malloc(sizeof(unsigned char) * 65536);

  if ((pmem == NULL) || (dmem == NULL)) {
    printf("Error: Out of memory!\n");
    return 1;
  }

  int i = 0;
  while (!feof(fin)) {
    pmem[i++] = (unsigned char)(fgetc(fin)& 0xFF);
  }
  fclose(fin);

  for (i = 0; i < 65536; i++)
    dmem[i] = 0;

  printf("Initializing APNA library...\n");
  apna_init(pmem, dmem);

  printf("Title: %s\nVersion: %s\nCopyright: %s\n", apna_get_title(), apna_get_version(), apna_get_copyright());

  printf("Reseting...\n");
  apna_reset();

  printf("Executing code...\n");

//while (getc(stdin) != 'a') {
  apna_execute();
 // apna_step();

//}

  apna = apna_get_thread();
  int r = pthread_join(*apna, NULL);
  if (r) {
    printf("Error: thread cannot be joined (%d)\n", r );
  } else {
    printf("Saving data memory...\n");
    fout = fopen("fact.out","wb");
    for (i = 0; i < 65536; i++)
      fputc(dmem[i], fout);
    fclose(fout);
  }

  free(dmem);
  free(pmem);

  apna_destroy();

  return 0;
}
