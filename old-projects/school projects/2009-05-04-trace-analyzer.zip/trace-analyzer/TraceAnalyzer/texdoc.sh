#!/bin/bash
javadoc -docletpath ~/dev/school\ projects/emu8/main_module/texdoclet.jar -doclet org.wonderly.doclets.TexDoclet -title "Systémová príručka" -sourcepath src/ -source 1.6 -noinherited -author "Matej Garaj" -output ~/dev/specific/Matej\ Garaj/texdoc.tex flowanalyzer flowanalyzer.gui

