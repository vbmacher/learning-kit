/*
 * Main.java
 *
 * (c) Copyright 2009, M. Garaj
 *
 */
package flowanalyzer;

import flowanalyzer.gui.MainFrame;


/**
 * Táto hlavná trieda obsahuje statickú metódu main, ktorá
 * je volaná ako prvá hneď pri spustení programu.
 */
public class Main {

    /**
     * Hlavná metóda volaná po spustení programu ako prvá.
     * Zobrazí hlavné okno aplikácie.
     * 
     * @param args parametre príkazového riadku, ignorujú sa.
     */
    public static void main(String[] args) {
        try { javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName()); }
        catch (javax.swing.UnsupportedLookAndFeelException e) {}
        catch (ClassNotFoundException e) {}
        catch (InstantiationException e) {}
        catch (IllegalAccessException e) {}

        new MainFrame().setVisible(true);

//                File in = new File(dialog.getFileName());
//                try {
//                    Lexer lex = new Lexer(new FileReader(in));
//                    lex.reset();
//
//                    FlowToken token;
//                    while ((token = lex.next_token()).getID() != FlowToken.EOF) {
//                        System.out.println(token.getID() + ": " + token.getText());
//                    }
//                } catch(Exception e) {
//
//                }
    }

}
