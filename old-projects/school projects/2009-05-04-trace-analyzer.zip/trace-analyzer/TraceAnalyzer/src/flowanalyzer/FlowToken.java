/*
 * FlowToken.java
 *
 * (c) Copyright 2009, M. Garaj
 * 
 * KEEP IT SIMPLE, STUPID
 * some things just: YOU AREN'T GONNA NEED IT
 */

package flowanalyzer;

/**
 * Táto trieda reprezentuje jeden token (lexikálny symbol) zo súboru
 * call-flow. Lexikálny analyzátor vracia ako lexikálne symboly objekty typu
 * FlowToken.
 */
public class FlowToken { 
    public final static int error = 255;
    public final static int TIME = 1;
    public final static int RIGHT = 2;
    public final static int LEFT = 4;
    public final static int STATUS = 8;
    public final static int DESCR = 16;
    public final static int REQUEST = 32;
    public final static int IP = 64;
    public final static int EOF = 0;

    private String text; // hodnota tokenu
    private int row;     // číslo riadka
    private int col;     // číslo stĺpca
    private int offset;  // pozícia tokenu
    private int length;  // dĺžka tokenu
    private int sym;     // ID tokenu

    /**
     * Konštruktor vytvorí objekt typu FlowToken.
     * @param ID     ID tokenu (typ)
     * @param text   Textová hodnota tokenu
     * @param line   číslo riadku, kde sa token v súbore nachádza
     * @param column číslo stĺpca v súbore
     * @param offset pozícia v súbore
     * @param val    hodnota tokenu
     */
    public FlowToken(int ID, String text,
    		int line, int column, int offset) {
        this.sym = ID;
        this.text = text;
        this.row = line;
        this.col = column;
        this.offset = offset;
        this.length = (text==null)?0:text.length();
    }

    /**
     * Vráti ID tokenu
     * @return ID
     */
    public int getID() { return sym; }

    /**
     * Vráti textovú hodnotu tokenu.
     * @return hodnota tokenu
     */
    public String getText() { return text; }

    /**
     * Vráti číslo riadku súboru, v ktorom sa token nachádza
     * @return číslo riadku
     */
    public int getLine() { return row; }
    /**
     * Vráti číslo stĺpca v súbore, v ktorom sa token nachádza
     * @return číslo stĺpca
     */
    public int getColumn() { return col; }
    /**
     * Vráti pozíciu v súbore, v ktorom sa token nachádza
     * @return pozícia v súbore
     */
    public int getOffset() { return offset; }
    /**
     * Vráti dĺžku hodnoty tokenu
     * @return dĺžka tokenu
     */
    public int getLength() { return length; }
}
