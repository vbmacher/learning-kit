/**
 * FlowPanel.java
 *
 * (c) Copyright 2009, M. Garaj
 */

package flowanalyzer;

import flowanalyzer.Flow.FlowItem;
import flowanalyzer.gui.UDPDialog;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * Táto trieda reprezentuje GUI panel zobrazujúci call-flow.
 * Tento call-flow je uložený v objekte typu Flow. Panel
 * podporuje prehľadné zobrazenie call-flow, zmenu názvu jednotlivých
 * strán komunikácie a zobrazenie okna s UDP informáciami.
 */
public class FlowPanel extends JPanel {
    /* double buffering */
    private Image dbImage;   // second buffer
    private Graphics2D dbg;  // graphics for double buffering

    private int height; // vyska flowu, pocita sa v resizePanel-i
    private final static int width = 250;
    private final static float line_width = 3;
    private final static float arrow_width = 1.5f;
    private final static int gap_between = 40;
    private final static int gap_top = 40;
    private final static int gap_top_arrows = 20;
    private final static int gap_left = 100;

    private BasicStroke lineStroke;
    private BasicStroke arrowStroke;
    
    private Font boldFont;
    private Font italicFont;
    private Font normalFont;

    private Flow flow;
    private String side1 = "Side 1";
    private Rectangle side1Rect = null;
    private String side2 = "Side 2";
    private Rectangle side2Rect = null;
    private boolean side1Set = false;
    private boolean side2Set = false;

    private class FlowMouseMotion implements MouseMotionListener {
        private JComponent targetComponent;

        public FlowMouseMotion(JComponent com) {
            this.targetComponent = com;
        }

        public void mouseDragged(MouseEvent e) {}
        public void mouseMoved(MouseEvent e) {
            // je mys na nejakom message-i?
            int j = flow.getFlow().size();
            int x = e.getX();
            int y = e.getY();
            for (int i = 0; i < j; i++) {
                int yline = gap_between*i;
                int ytop = (i==0) ? 0 :gap_between*(i-1);

                if (((x >= gap_left) && (x <= gap_left+width))
                        && (y <= (gap_top+gap_top_arrows+yline))
                            && (y > (gap_top+ytop))) {
                    FlowItem item = flow.getFlow().get(i);
                    targetComponent.setToolTipText(item.getDescription());

          //          ToolTipManager.sharedInstance().mouseMoved(
            //            new MouseEvent(targetComponent, 0, 0, 0,
              //                 gap_left, gap_top+gap_top_arrows+yline-10, // X-Y of the mouse for the tool tip
                //                0, false));
                    return;
                }
            }
            targetComponent.setToolTipText(null);
        }
        
    }

    private class FlowMouse implements MouseListener {
        public void mouseClicked(MouseEvent e) {
            // klikol pouzivatel na nejaky Side?
            if (side1Set && side2Set) {
                changeSide(e.getPoint());
            }
            int j = flow.getFlow().size();
            int x = e.getX();
            int y = e.getY();

            for (int i = 0; i < j; i++) {
                int yline = gap_between*i;
                int ytop = (i==0) ? 0 :gap_between*(i-1);

                if (((x >= gap_left) && (x <= gap_left+width))
                        && (y <= (gap_top+gap_top_arrows+yline))
                            && (y > (gap_top+ytop))) {
                    FlowItem item = flow.getFlow().get(i);
                    new UDPDialog(null,true,item.getUDP()).setVisible(true);
                    break;
                }

            }
        }
        public void mousePressed(MouseEvent e) {}
        public void mouseReleased(MouseEvent e) {}
        public void mouseEntered(MouseEvent e) {}
        public void mouseExited(MouseEvent e) {}
    }

    /**
     * Konštruktor vytvorí objekt typu FlowPanel. Ako parameter
     * dostane samotný call-flow.
     * @param flow Call-flow reprezentovaný objektom typu Flow
     */
    public FlowPanel(Flow flow) {
        this.flow = flow;
        this.setBackground(Color.WHITE);// Color.decode("0xC0C0C0"));
        lineStroke = new BasicStroke(line_width);
        arrowStroke = new BasicStroke(arrow_width);

        normalFont = this.getFont();
        italicFont = normalFont.deriveFont(Font.ITALIC);
        boldFont = normalFont.deriveFont(Font.BOLD);
        if (flow != null)
            measurePanel();
        this.addMouseMotionListener(new FlowMouseMotion(this));
        this.addMouseListener(new FlowMouse());
    }

    /**
     * V prípade, že používateľ počas behu programu zmení komunikačný
     * prúd (otvorením nových súborov jeho popisu), touto metódou
     * sa informuje panel, že sa zmenil call-flow. Metóda následne
     * panel prekreslí.
     * @param flow nový call-flow
     */
    public void setNewFlow(Flow flow) {
        this.flow = flow;
        measurePanel();
    }

    private void changeSide(Point p) {
        if (side1Rect.contains(p)) {
            String n = JOptionPane.showInputDialog("Enter name for Side 1:",side1);
            if (n != null) side1 = n;
        } else if (side2Rect.contains(p)) {
            String n = JOptionPane.showInputDialog("Enter name for Side 2:",side2);
            if (n != null) side2 = n;
        }
        this.repaint();
    }

     /**
      * Metóda prepisuje pôvodnú update metódu, z dôvodu implementácie
      * double-bufferingu. Ako druhý buffer je použitý objekt typu Image.
      * @param g objekt typu Graphics, ktorý sa použije na vykreslenie na obrazovku
      */
    public void update(Graphics g) {
        // initialize buffer if needed
        if (dbImage == null) {
            dbImage = createImage (this.getSize().width,
                    this.getSize().height);
            dbg = (Graphics2D)dbImage.getGraphics();
        }
        // clear screen in background
        dbg.setColor(getBackground());
        dbg.fillRect (0, 0, this.getSize().width,
                this.getSize().height);

        // draw elements in background
        dbg.setColor(getForeground());
        paint(dbg);

        // draw image on the screen
        g.drawImage(dbImage, 0, 0, this);
    }

   private void measurePanel() {
       // vypocet vysky flow-u
      // height = (int)(flow.getMaxTime() * 200);
       height = gap_between * flow.getFlow().size();

      this.setSize(100+width,100+height);
      this.setPreferredSize(this.getSize());
      this.setMinimumSize(this.getSize());
      this.revalidate();
    }


    /**
     * Metóda preťažuje pôvodnú metódu. Vykresľuje celý panel aj
     * s informáciami.
     * @param g Objekt typu Graphics použitý na vykreslenie panelu.
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D gr = (Graphics2D)g;
        FontMetrics fm = gr.getFontMetrics();
        gr.setFont(normalFont);

        // najprv 2 ciary
        gr.setStroke(lineStroke);
        gr.drawLine(gap_left, gap_top, gap_left, gap_top+height);
        gr.drawLine(gap_left+width, gap_top, gap_left+width, gap_top+height);

        // teraz sipky a text
        gr.setStroke(arrowStroke);
        int j = flow.getFlow().size();
        for (int i = 0; i< j; i++) {
            FlowItem item = flow.getFlow().get(i);
          //  int y = (int)(item.getTime() * 200);
            int y = gap_between * i;
            gr.drawLine(gap_left, gap_top+y+gap_top_arrows, gap_left+width, gap_top+y+gap_top_arrows);
            
            if (item.isLeft()) {
                gr.drawLine(gap_left, gap_top+y+gap_top_arrows, gap_left+10, gap_top-3+y+gap_top_arrows);
                gr.drawLine(gap_left, gap_top+y+gap_top_arrows, gap_left+10, gap_top+3+y+gap_top_arrows);
            } else {
                gr.drawLine(gap_left+width, gap_top+y+gap_top_arrows, gap_left-10+width, gap_top-3+y+gap_top_arrows);
                gr.drawLine(gap_left+width, gap_top+y+gap_top_arrows, gap_left-10+width, gap_top+3+y+gap_top_arrows);
            }

            // teraz text
            String mes = item.getMessage();
            int tw = fm.stringWidth(mes);
            float text_x = (float)gap_left + ((float)width - (float)tw)/2.0f;
            gr.drawString(mes, text_x,gap_top+y+gap_top_arrows - fm.getHeight()/2);
        }

        // IP adresy
        gr.setFont(italicFont);
        String mes = flow.getIPLeft();
        int tw = fm.stringWidth(mes);
        gr.drawString(mes, gap_left-tw/2, gap_top - fm.getHeight()/2);
        mes = flow.getIPRight();
        tw = fm.stringWidth(mes);
        gr.drawString(mes, gap_left+width-tw/2, gap_top - fm.getHeight()/2);

        // Nazvy stran
        gr.setFont(boldFont);
        tw = fm.stringWidth(side1);
        gr.drawString(side1, gap_left-tw/2, gap_top - fm.getHeight()*1.5f);
        if (!side1Set) {
            side1Rect = new Rectangle(gap_left-tw/2,(int)(gap_top - fm.getHeight()*1.5f - fm.getHeight()),
                tw,fm.getHeight());
            side1Set = true;
        }
        tw = fm.stringWidth(side2);
        gr.drawString(side2, gap_left+width-tw/2, gap_top - fm.getHeight()*1.5f);
        if (!side2Set) {
            side2Rect = new Rectangle(gap_left+width-tw/2,(int)(gap_top - fm.getHeight()*1.5f - fm.getHeight()),
                tw,fm.getHeight());
            side2Set = true;
        }
    }

}
