/*
 * Flow.java
 *
 * (c) Copyright 2009, M.Garaj
 */

package flowanalyzer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JOptionPane;

/**
 * Táto trieda uchováva prúd call-flow ako objekt.
 * V konštruktore v spolupráci s lexikálnym analyzátorom
 * prejde súbormi s popisom call-flow a naplní potrebné atribúty,
 * ako IP adresy oboch strán a jednotlivé správy komunikácie.
 * Každá komunikačná správa je uložená ako objekt triedy FlowItem.
 *
 */
public class Flow implements Serializable {
    private String IPLeft ="";
    private String IPRight = "";
    private ArrayList<FlowItem> flow;

    /**
     * Trieda reprezentuje jednu správu v SIP komunikácii,
     * medzi známymi stranami komunikácie. Uchováva
     * atribúty ako čas, kedy prišla správa; krátky popis;
     * celý popis; ďalej či išlo o požiadavku alebo odpoveď
     * a smer komunikácie.
     */
    public class FlowItem implements Serializable {
        private double time;
        private String message;
        private String description;
        private boolean request;
        private boolean left;
        private ArrayList<String> udp;

        /**
         * Konštruktor vytvorí objekt triedy FlowItem, reprezentujúcej
         * jednu správu komunikácie.
         *
         * @param time         Čas v sekundách, kedy prišila správa
         * @param message      Krátky popis správy
         * @param description  Celý popis správy
         * @param request      <code>true</code>, ak ide o požiadavku,
         *                     <code>false</code>, ak o odpoveď
         * @param left         <code>true</code>, ak je smer komunikácie
         *                     od druhého klienta k prvému, <code>false</code>
         *                     ak opačne
         */
        public FlowItem(double time, String message,
                String description, boolean request,
                boolean left) {
            this.time = time;
            this.message = message;
            this.description = description;
            this.request = request;
            this.left = left;
            udp = new ArrayList<String>();
        }

        /**
         * Vráti čas, kedy prišla správa.
         * @return čas v sekundách
         */
        public double getTime() { return time; }
        /**
         * Vráti krátky popis správy aj s označením, či ide
         * o požiadavku (request) alebo odpoveď (status).
         * @return krátky popis
         */
        public String getMessage() {
            return ((request) ? "Request: " : "Status: " )+
                       message;
        }
        /**
         * Vráti krátky popis správy.
         * @return krátky popis
         */
        public String getMessageRAW() { return message; }
        /**
         * Vráti celý popis správy.
         * @return celý popis správy
         */
        public String getDescription() { return description; }
        /**
         * Vráti <code>true</code>, ak sa jedná o požiadavku,
         * <code>false</code>, ak o odpoveď.
         * @return informácia, či sa jedná o požiadavku alebo odpoveď.
         */
        public boolean isRequest() { return request; }

        /**
         * Vráti smer komunikácie.
         * @return <code>true</code>, ak je správa od druhého klienta k prvému,
         *         <code>false</code>, ak v opačnom smere.
         */
        public boolean isLeft() { return left; }
        /**
         * Vráti pole UDP informácií patriacich k tejto správe.
         * @return UDP informácie, každý prvok poľa reprezentuje jeden riadok
         */
        public ArrayList<String> getUDP() { return udp; }

        /**
         * Pridá jeden riadok UDP informácie, patriacej k tejto správe.
         * @param line Riadok UDP informácie
         */
        public void addUDPLine(String line) {
            udp.add(line);
        }
    }

    /**
     * Konštruktor vytvorí objekt typu Flow. Najprv však v spolupráci
     * s lexikálnym analyzátorom rozparsuje súbory s daným call-flow
     * (samotný call-flow a popis UDP prúdu).
     *
     * @param fileName    Súbor s call-flow komunikácie
     * @param udpFileName Súbor s popisom UDP prúdu
     */
    public Flow(String fileName, String udpFileName) {
        File in = new File(fileName);
        File udp = new File(udpFileName);
        ArrayList<String> udpLines = new ArrayList<String>();

        if (udp.canRead()) {
            try {
                FileReader fr = new FileReader(udp);
                BufferedReader br = new BufferedReader(fr);
                String rec;
                while((rec = br.readLine()) != null)
                    udpLines.add(rec);
                br.close();
            }
            catch(Exception e) {
                JOptionPane.showMessageDialog(null,
                        "ERROR: Can not parse udp-stream file",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        flow = new ArrayList<FlowItem>();        
        try {
            FlowLexer lex = new FlowLexer(new FileReader(in));
            lex.reset();

            FlowToken token;
            token = lex.yylex();
            if (token.getID() == FlowToken.IP)
                IPLeft = token.getText();
            token = lex.yylex();
            if (token.getID() == FlowToken.IP)
                IPRight = token.getText();

            while ((token = lex.yylex()).getID() != FlowToken.EOF) {
                if (token.getID() == FlowToken.TIME) {
                    double time = Double.parseDouble(token.getText().replace(",", "."));

                    token = lex.yylex();
                    if (token.getID() == FlowToken.REQUEST ||
                            token.getID() == FlowToken.STATUS) {
                        boolean request;
                        String message = "";
                        if (token.getID() == FlowToken.REQUEST) {
                            request = true;
                            message = token.getText().substring(9);
                        } else {
                            request = false;
                            message = token.getText().substring(8);
                        }
                        token = lex.yylex();
                        if (token.getID() == FlowToken.DESCR) {
                            String descr = token.getText();
                            token = lex.yylex();
                            if (token.getID() == FlowToken.LEFT ||
                                    token.getID() == FlowToken.RIGHT) {
                                boolean left;
                                if (token.getID() == FlowToken.LEFT)
                                    left = true;
                                else
                                    left = false;
                                // vytvorenie FlowItem
                                flow.add(new FlowItem(time,message,descr,
                                        request,left));
                            }
                        }
                    }
                }
            }
        } catch (Error e) {
            JOptionPane.showMessageDialog(null, "ERROR: Can't parse call-flow file",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: Can not parse call-flow file",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // hladanie popisu
        int j = flow.size();
        int i = 0;
        int k = 0;
        boolean was = false;
        while ((i < j) && (k < udpLines.size())) {
            String rrawMessage = flow.get(i).getMessageRAW();
            String line = udpLines.get(k);

            String rawMessage = "";
            boolean wasSpace = false;
            for (int e = 0; e < rrawMessage.length(); e++) {
                String w = rrawMessage.substring(e, e+1);
                if (w.equals(" ") && !wasSpace) {
                    wasSpace = true;
                } else if (w.equals(".") || w.equals(",") || w.equals(" "))
                    break;
                rawMessage += w;
            }
            if (line.indexOf(rawMessage) != -1) {
                i++;
                was = true;
            }
            if (was) {
                flow.get(i-1).addUDPLine(line);
                udpLines.remove(k);
            } else k++;
        }
        if ((i == j) && was && (k < udpLines.size())) {
            while (k < udpLines.size()) {
                String line = udpLines.get(k);
                udpLines.remove(k);
                flow.get(i-1).addUDPLine(line);
            }
        }

    }

    /**
     * Vráti pole objektov typu FlowItem, teda pole komunikačných
     * správ. Pole je reprezentované v objekte typu ArrayList.
     * @return pole komunikačných správ
     */
    public ArrayList<FlowItem> getFlow() { return flow; }

    /**
     * Vráti IP adresu prvej strany komunikácie.
     * @return Reťazec IP adresy prvej strany komunikácie
     */
    public String getIPLeft() { return IPLeft; }
    /**
     * Vráti IP adresu druhej strany komunikácie.
     * @return Reťazec IP adresy druhej strany komunikácie
     */
    public String getIPRight() { return IPRight; }

    /**
     * Metóda serializuje (uloží do súboru) tento objekt typu Flow.
     * Využíva pritom štandardné (knižničné) operácie a triedy,
     * ako je napr. ObjectOutputStream.
     * @param fileName Názov súboru, do ktorého sa má call-flow serializovať
     */
    public void serialize(String fileName) {
        File f = new File(fileName);
        try {
            FileOutputStream fout = new FileOutputStream(f);
            ObjectOutputStream out = new ObjectOutputStream(fout);
            out.writeObject(this);
            out.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: Can't save flow",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Metóda deserializuje (vytvorí) objekt typu Flow zo súboru.
     * Inými slovami otvorí súbor s uloženým call-flow.
     * @param f Súbor, ktorý sa má deserializovať
     * @return objekt typu Flow ak sa deserializácia podarila, null ak nie
     */
    public static Flow deserialize(File f) {
        try {
            FileInputStream fin = new FileInputStream(f);
            ObjectInputStream in = new ObjectInputStream(fin);
            Flow fl = (Flow)in.readObject();
            in.close();
            return fl;
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: Can't open flow",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    /**
     * Metóda zistí úroveň interoperability medzi jednotlivými komunikujúcimi
     * stranami.
     *
     * 1. úroveň je postupnosť SIP správ:
     *    "INVITE","*", "180", "200","ACK","BYE","200"
     *
     * 2. úroveň je, ak sa ľubovoľná správa aspoň raz
     *    v postupnosti opakuje
     *
     * 3. úroveň je:
     *    ak sú prijaté SIP správy nie v takom poradí, ako
     *    v úrovni 1, resp. ak sa vyskytnú neočakávané správy.
     *
     * Značka "*" znamená, že môžu nasledovať ľubovoľné SIP správy,
     * okrem nasledujúcej v postupnosti.
     *
     * @return úroveň interoperability (1,2,3)
     */
    public int getInteroperabilityLevel() {
        Iterator<FlowItem> i = flow.iterator();

        // spravy v postupnosti v akej maju byt
        String[] messages = {"INVITE","*", "180", "200","ACK","BYE","200"};

        // povinnost sprav
        int[] duties      = {1       , 0 , 1    , 1    , 1   , 1   , 1   };
        int j = 0;
        int level = 1;

        boolean was = false;
        while (i.hasNext()) {
            FlowItem f = i.next();
            String m = f.getMessageRAW().trim().toUpperCase();

            while (true) {
                // ignorovanie lubovolnych sprav az po nasledujucu
                if (messages[j].equals("*") && ((j+1) < messages.length)) {
                    j++;
                    System.out.println("got *, ignoring till: " + messages[j]
                          + " (" + m + ")");
                    was = false;
                    // retazec do prvej medzery sa odchyti pre dalsiu kontrolu
                    String lstr;
                    int tt = m.indexOf(" "); // index prvej medzery
                    lstr = (tt >= 0) ? m.substring(0, tt) : m;
                    
                    while (i.hasNext() && !m.startsWith(messages[j])) {
                        f = i.next();
                        m = f.getMessageRAW().trim().toUpperCase();

                        tt = m.indexOf(" ");
                        String cmp = (tt >= 0) ? m.substring(0, tt) : m;
                        if (lstr.equals(cmp)) {
                            // 2. vyskyt hocicoho => level 2
                            level = 2;
                        }
                        lstr = cmp;
                    }
                } else if (messages[j].equals("*"))
                    return level; // az dokonca moze byt hocico

                // ak sprava este nebola a ani teraz nie je
                if (!was && !m.startsWith(messages[j])) {
                    System.out.println("wasnt, expected: " + messages[j]
                            + " (and is " + m + ")");
                    // ak bola sprava povinna, koniec (3)
                    if (duties[j] != 0)
                        return 3;
                    // inak ignorujem spravu
                    j++;
                    was = false;
                    if (j >= messages.length)
                        return level;
                }
                // ak sprava uz bola a este stale je
                else if (was && m.startsWith(messages[j])) {
                    System.out.println("was already, expected: " + messages[j]
                            + " (and is " + m + ")");
                    level = 2;
                    break;
                }
                // ak sprava uz bola a uz nie je
                else if (was && !m.startsWith(messages[j])) {
                    System.out.println("end of cycle with expecting: " + messages[j]
                            + " (and is " + m + ")");
                    j++;
                    was = false;
                    if (j >= messages.length)
                        return level;
                }
                // ak sprava este nebola a je
                else if (!was && m.startsWith(messages[j])) {
                    System.out.println("is first time, expected: " + messages[j]
                            + " (and is " + m + ")");
                    was = true;
                    break;
                }
            }
        }
        return level;
    }

}
