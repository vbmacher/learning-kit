#!/bin/bash
~/bin/jflex-1.4.3/bin/jflex flowLexer.jflex
