/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package shortdijkstra;

/**
 *
 * @author vbmacher
 */
public class Transition {
    private Vertex v1;
    private Vertex v2;

    private int pathLength; // urcuje sa pri hladani cesty

    public Transition(Vertex v1, Vertex v2) {
        this.v1 = v1;
        this.v2 = v2;
        pathLength = -1;
    }

    public Vertex getV1() { return v1; }
    public Vertex getV2() { return v2; }

    // vahova funkcia.. implementacia je lubovolna
    // hodnotu vahy mozes dat dokonca ako parameter
    // konstruktora
    // teraz ma kazda hrana vahu 1
    public int getWeight() {
        return 1;
    }

    public int getPathLength() { 
        return pathLength; // (pathLength < 0)? 999999999: pathLength;
    }
    public void setPathLength(int l) { pathLength = l; }
}
