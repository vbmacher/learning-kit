/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package shortdijkstra;

/**
 *
 * @author vbmacher
 */
public class Vertex {
    public int znacka;

    public Vertex(int znacka) {
        this.znacka = znacka;
    }

    public String toString() {
        return String.valueOf(znacka);
    }

}