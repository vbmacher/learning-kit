/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package shortdijkstra;

import java.util.ArrayList;

/**
 *
 * @author vbmacher
 */
public class Main {

    public static void main(String[] args) {
        ArrayList<Transition> graph = new ArrayList<Transition>();
        ArrayList<Vertex> nodes = new ArrayList<Vertex>();
        
        // budeme mat graf:
        /*
         *        t1
         * 0------------1
         * |            |
         * |t2    t3    | t4
         * 2------------3
         * |
         * |t5
         * 4
         */

        // vrcholy
        nodes.add(new Vertex(0));
        nodes.add(new Vertex(1));
        nodes.add(new Vertex(2));
        nodes.add(new Vertex(3));
        nodes.add(new Vertex(4));

        // hrany
        graph.add(new Transition(nodes.get(0), nodes.get(1)));
        graph.add(new Transition(nodes.get(0), nodes.get(2)));
        graph.add(new Transition(nodes.get(2), nodes.get(3)));
        graph.add(new Transition(nodes.get(1), nodes.get(3)));
        graph.add(new Transition(nodes.get(2), nodes.get(4)));

        // hladanie cesty
        Vertex start = nodes.get(4);
        Vertex end = nodes.get(1);

        // cesta je ulozena ako postupnost vrcholov
        ArrayList<Vertex> path = new ArrayList<Vertex>();
        Vertex tmp = start; // pomocny vrchol, v ktorom sme

        path.add(start);
        Transition old = null; // odkaz na predch. prechod
        Vertex oldVertex = null; // odkaz na predch. vrchol

        int min; // minimalna vzdialenost od vrcholu tmp po nejakeho jeho suseda
        Vertex nextVertex;
        Transition nextTransition;

        while (tmp != end) {
            min = 999999999;
            nextVertex = null;
            nextTransition = null;
            // zistim nasledujuci vrchol
            for (int i = 0; i < graph.size(); i++) {
                Transition t = graph.get(i);
                // ak prechod patri vrcholu tmp a nema urcenu vzdialenost
                if (((t.getV1().equals(tmp)) || (t.getV2().equals(tmp)))
                        && (t.getPathLength() == -1)) {
                    if (old != null)
                        t.setPathLength(old.getPathLength() + t.getWeight());
                    else
                        t.setPathLength(t.getWeight());
                }
                if ((t.getV1().equals(end) && t.getV2().equals(tmp)) ||
                        (t.getV2().equals(end) && t.getV1().equals(tmp))) {
                    // sme na konci
                    nextVertex = end;
                    nextTransition = t;
                    break;
                } else if ((t.getPathLength() != -1)
                        && (min > t.getPathLength())) {
                    // nie sme na konci, ideme dalej ale nesmieme sa vracat
                    if (!t.getV1().equals(oldVertex) && !t.getV2().equals(oldVertex)) {
                        min = t.getPathLength();
                        nextVertex = (t.getV1().equals(tmp))? t.getV2(): t.getV1();
                        nextTransition = t;
                    }
                }
            }
            if (nextVertex != null) {
                oldVertex = tmp;
                tmp = nextVertex;
                old = nextTransition;
                path.add(tmp);
            }
        }

        // vypis cesty
        for (int i = 0; i < path.size(); i++) {
            System.out.println(path.get(i));
        }
        
    }

}
